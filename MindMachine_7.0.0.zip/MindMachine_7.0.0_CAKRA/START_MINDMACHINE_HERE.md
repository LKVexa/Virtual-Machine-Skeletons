# MindMachine 7.0.0 — Start Here

MindMachine 7.0.0 is a hosted-reference cognitive simulation with a meaning-centered extension.

Run:
- Windows: `RUN_MINDMACHINE.cmd`
- Unix-like: `./RUN_MINDMACHINE.sh`

The canonical cognitive loop remains WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING.

7.0.0 adds plural care, explicit commitments, agent-relative significance, autobiographical narrative continuity, symbolic meaning-as-use, life projects, and reflective-equilibrium diagnostics. It does not claim consciousness, sentience, clinical validity, or access to an objective universal meaning of life.
