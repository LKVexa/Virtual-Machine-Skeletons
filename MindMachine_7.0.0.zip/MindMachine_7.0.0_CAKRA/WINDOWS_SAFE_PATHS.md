# Windows-safe extraction

The release was checked for path length before packaging. Longest repository-relative file path before the final archive prefix: **213 characters**.

Longest path: `vm/workflow_application/input_workflows/09_4_8_0_independent_verification_security_qualification/09_4_8_0_independent_verification_security_qualification/03_BR-480-03_differential_arithmetic_PROMPT_AND_WORKFLOW.md`

For conservative Windows extraction, extract the archive to a short location such as `C:\MM7` rather than deeply nested folders.
