# VM / MindMachine Changelog

## MindMachine 7.0.0 meaning-centered hosted-reference
- Preserved QVM and RC-PW WORLD authority.
- Expanded QVM Mind ABI from 48–63 to 48–71.
- Added plural care, commitment, significance, narrative, symbolic-practice, life-project, reflective-equilibrium, and meaning-debt state.
- Added bounded care-alignment influence to deliberation.
- Added meaning integration after learning.
- Added 6.x→7.x state migration.
- Added 20 new meaning-centered tests; Mind tests now 60/60 PASS.
- Expanded mind qualification to 61 gates: 58 OPERATIONAL hosted-reference, 3 PARTIAL production/external claims.

## MindMachine 6.0.0 hosted-reference
- Added hosted-reference cognitive runtime and QVM Mind services 48–63.
- Integrated QUORUM Cognitive-Psychological + Later-Wittgenstein Workflow Series 6.0.0.
