#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
python3 "$ROOT/toolchain/quorum_vm.py" compile "$ROOT/src/MIND_DEMO.lctlc" "$ROOT/mind/evidence/MIND_DEMO.payload.json" --brir "$ROOT/mind/evidence/MIND_DEMO.brir.json"
python3 "$ROOT/toolchain/quorum_vm.py" sign "$ROOT/mind/evidence/MIND_DEMO.payload.json" --key "$ROOT/keys/DEV_ONLY_private_seed.hex" --key-id dev-root --out "$ROOT/mind/evidence/MIND_DEMO.signed.brimg"
exec python3 "$ROOT/toolchain/quorum_vm.py" run "$ROOT/mind/evidence/MIND_DEMO.signed.brimg" --trust "$ROOT/keys/TRUST_STORE.json" --snapshot "$ROOT/mind/evidence/MIND_DEMO.snapshot.json" --trace "$ROOT/mind/evidence/MIND_DEMO.trace.json"
