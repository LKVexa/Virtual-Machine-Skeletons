# MindMachine 7.0.0 — QVM + RC-PW + Meaning-Centered Cognitive Runtime

This repository preserves QVM 5.0.0-candidate and RC-PW 7.0 WORLD authority while extending the hosted-reference MIND runtime to MindMachine 7.0.0.

Run `make mind-test`, `make mind-demo`, and `make mind-qualify` from this directory.

WORLD services: 16–47. Cognitive Mind services: 48–63. Meaning-centered Mind services: 64–71.

Meaning is modeled as plural agent-relative care, commitments, significance, narrative continuity, symbolic practice, and life projects—not a single universal scalar.
