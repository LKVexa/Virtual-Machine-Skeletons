# Symbolic Meaning as Use — 7.0.0

A symbol stores token, practice context, use history, associations, and language-game context. MindMachine explicitly rejects a universal-essence interpretation. Translation may be partial or fail when practices do not align.
