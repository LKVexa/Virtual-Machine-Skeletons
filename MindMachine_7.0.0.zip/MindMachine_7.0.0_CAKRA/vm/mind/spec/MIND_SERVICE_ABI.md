# MindMachine 7.0.0 Cakra-Integrated Mind Service ABI

WORLD services remain 16–47. All Mind services are capability-gated and require `WORLD_INIT` followed by `MIND_INIT`.

## Cognitive services 48–63
48 MIND_INIT; 49 PERCEIVE; 50 ATTEND; 51 APPRAISE; 52 MEMORY_QUERY; 53 BELIEF_UPDATE; 54 AFFECT; 55 MOTIVATION; 56 MEMORY_SELF_GOALS; 57 DELIBERATE; 58 SOCIAL_MODEL; 59 DECIDE; 60 ACT; 61 LEARN; 62 SNAPSHOT; 63 DIGEST.

## Meaning services 64–71
64 meaning integrate; 65 commit active goal; 66 narrative; 67 significance; 68 symbolic-practice use; 69 life project; 70 reflective equilibrium; 71 meaning digest.

## Cakra / sacred-cognition services 72–86
- 72 `MIND_CAKRA_FEDERATE` — execute all 12 nodes and return federation digest/convergence.
- 73 `MIND_CAKRA_NODE_STEP` — step one node selected by code 1..12.
- 74 `MIND_SPIRITUAL_SESSION_BEGIN` — open voluntary CSE/1.1 session with spiritual mode/profile.
- 75 `MIND_SPIRITUAL_SESSION_END` — close session and create return-to-world path.
- 76 `MIND_SPIRITUAL_PROFILE_SET` — select GROUNDED, OPEN, or MYSTICAL.
- 77 `MIND_SPIRITUAL_RECEIVE` — record intuition, vision, dream, prayer-response, lineage, nondual, or related insight.
- 78 `MIND_SPIRITUAL_SYNCHRONICITY` — record meaningful coincidence relation without mandatory causal verdict.
- 79 `MIND_SACRED_INTEGRATE` — run federation, update sacred confidence, and bridge spiritual meaning.
- 80 `MIND_SACRED_CONFIDENCE` — return compact sacred-confidence vector.
- 81 `MIND_RETURN_TO_WORLD` — create descent/embodiment/service proposal without direct WORLD mutation.
- 82 `MIND_SPIRITUAL_EXTERNALIZE` — apply the 3.1 light-touch externalization membrane.
- 83 `MIND_CAKRA_DIGEST` — digest/counts for cakra spiritual state.
- 84 `MIND_SPIRITUAL_ASCENT` — governed 12-stage ascent/opening pass.
- 85 `MIND_SPIRITUAL_ONTOLOGY` — add/hold a live spiritual ontology frame.
- 86 `MIND_SPIRITUAL_MYSTERY` — preserve a first-class `MYSTERY_HELD` state.

All cakra nodes remain proposal-only. The Mind retains Mind-local commit authority; canonical WORLD changes continue to use existing WORLD-authorized action paths.
