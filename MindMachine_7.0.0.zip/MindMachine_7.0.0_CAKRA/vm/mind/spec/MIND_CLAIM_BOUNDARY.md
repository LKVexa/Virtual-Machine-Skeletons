# MindMachine Claim Boundary

## Demonstrated locally

- deterministic host-reference mind state;
- agent-local perception and beliefs;
- bounded attention/workspace;
- appraisal, affect, motivation, memory, self, goals, deliberation and decisions;
- counterfactual separation;
- WORLD-authorized actions;
- learning and replay;
- save/load integrity;
- self/other boundary;
- semantic bridge and later-Wittgenstein use/practice metadata;
- capability-gated QVM Mind ABI 48–63;
- automated regression and mind-runtime tests.

## Not claimed

- consciousness or sentience;
- human-equivalent cognition;
- clinical diagnosis/treatment validity;
- neuroscientific fidelity;
- native/self-hosted LCTL mind primitives;
- production-scale population fidelity;
- long-duration production soak;
- independent third-party certification;
- exhaustive validation of all contemporary psychological theories.

Advanced workflow mechanisms are explicitly marked PARTIAL when they are represented by architecture/contracts but lack broad empirical scenario evidence.
