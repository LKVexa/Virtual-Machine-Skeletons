# MindMachine Meaning Architecture 7.0.0

## Principle
Meaning is not represented by one scalar. It is modeled through a plural structure of care, commitment, significance, narrative continuity, symbolic/practice use, relationships, projects, and reflective tensions.

## Surfaces
1. **Care map** — what matters to this agent, with domain-specific strength.
2. **Commitments** — what the agent has undertaken and why.
3. **Significance** — why an event matters relative to goals, emotion, relationships, values, novelty, and life history.
4. **Narrative** — how the agent links events, roles, projects, and turning points across time.
5. **Symbols/practices** — learned use and personal association embedded in language-games/forms of life.
6. **Life projects** — durable purposive structures spanning more than one immediate plan.
7. **Reflective equilibrium** — explicit tensions among care, goals, actions, commitments, and practice, with revision proposals rather than automatic value rewrite.

## Later-Wittgenstein constraint
Symbolic meaning derives from use in practice. A word, role, promise, sign, or object does not obtain a universal inner essence because it appears in the mind state. Context, correction, language-game, form of life, and use history remain authoritative for interpretation.

## Authority boundary
All meaning state is agent-relative cognitive state. It is not canonical WORLD truth and does not establish objective metaphysical meaning.
