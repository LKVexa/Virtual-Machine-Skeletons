# Narrative Continuity and Life Projects — 7.0.0

Narrative is a bounded reconstruction linking roles, goals, commitments, significant events, and autobiographical anchors. Life projects extend purpose beyond one immediate plan. Narrative continuity can contain tensions and uncertainty; it does not rewrite canonical history.
