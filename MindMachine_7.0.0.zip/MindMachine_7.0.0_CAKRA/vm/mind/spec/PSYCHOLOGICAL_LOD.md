# Psychological LOD

Profiles are selected by actor kind and importance. Major actors retain fuller state; minor actors have smaller attention/memory/planning budgets; wildlife uses ecological state and disables human semantic bridging by default.

Compression must label summarized state and must not fabricate exact lost history. The current hosted reference demonstrates profile differentiation and bounded memory; population-scale cohort promotion/demotion equivalence remains PARTIAL.
