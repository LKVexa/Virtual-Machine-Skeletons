# Later-Wittgenstein Runtime Mapping

MindMachine operationalizes later-Wittgenstein primarily as semantic discipline rather than as a claim that philosophy is a psychological mechanism.

- Meaning-as-use: semantic-use records are context/practice keyed.
- Language-games: interpretations carry semantic contexts; bridges may be partial or fail.
- Forms of life: profile/context metadata constrains semantic competence.
- Rule-following: workflow contracts require examples, correction, practice and transfer.
- Public criteria: social/psychological predicates are evidence-bearing, never mind-reading.
- Family resemblance: workflow schemas support graded/open categories rather than mandatory essences.
- Aspect seeing: reinterpretation must not rewrite percept evidence.
- Grammar vs empirical fact: proposition typing remains a first-class qualification requirement.
- Hinge commitments: slow, high-stability background commitments are stored separately from ordinary belief updates.
- Reasons vs causes: decision reasons are stored as the agent's practical reasons and are not asserted to be the runtime's complete causal explanation.

The semantic bridge can explicitly return `NO_GOOD_EQUIVALENT`, preventing fabricated cross-language-game equivalence.
