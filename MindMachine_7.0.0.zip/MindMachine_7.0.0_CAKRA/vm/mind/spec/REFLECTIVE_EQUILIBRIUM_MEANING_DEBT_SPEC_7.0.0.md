# Reflective Equilibrium and Meaning Debt — 7.0.0

Reflective equilibrium compares care, commitments, active goals, action history, and practices. It may produce tensions and revision proposals, but does not automatically rewrite values. Meaning debt records unresolved gaps such as a strong commitment paired with failed or abandoned execution.
