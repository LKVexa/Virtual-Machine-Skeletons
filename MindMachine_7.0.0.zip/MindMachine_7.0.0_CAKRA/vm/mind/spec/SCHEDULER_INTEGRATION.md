# MindMachine Scheduler Integration

Hosted reference order per cognitive cycle:

1. WORLD snapshot/digest
2. PERCEPTION
3. ATTENTION
4. BELIEF + coherence reconciliation
5. APPRAISAL
6. EMOTION / regulation
7. MOTIVATION
8. MEMORY
9. SELF
10. GOALS
11. DELIBERATION / counterfactuals
12. DECISION / intention / commitment
13. ACTION request
14. WORLD result
15. LEARNING

Recurrent influences occur only through state available at declared boundaries. The current hosted implementation is single-process deterministic reference execution; production concurrent scheduling remains a qualification boundary.
