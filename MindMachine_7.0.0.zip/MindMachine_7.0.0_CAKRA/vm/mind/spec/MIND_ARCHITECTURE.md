# MindMachine Architecture

## Core

`MindRuntime` is durable host-reference state linked one-to-one to persistent WORLD entities. Guest QVM code holds handles/IDs and invokes capability-gated services; the 4 KiB guest memory is not used as the complete psychological store.

## State

Each mind contains perception, bounded attention, provenance-bearing beliefs, appraisal, affect/regulation, motives/needs, reconstructive memory, self-model, goals, deliberation/counterfactuals, decision/intention/commitment, social models, language-game state, workspace, coherence debt, metacognition, policy, and learning.

## Coordination

- Cognitive Workspace: bounded relevance bus, agent-local only.
- World-Model Reconciliation: preserves contradictions and coherence debt.
- Temporal Horizons: H0 immediate through H5 social-historical.
- Agency lifecycle: desire → goal → intention → commitment → plan → attempt → WORLD result → learning.
- Semantic bridge: use/practice-aware language-game mapping; may return NO_GOOD_EQUIVALENT.
- Remediation: cannot weaken immutable authority or epistemic gates.

## Runtime profiles

MAJOR_ACTOR_FULL, MINOR_ACTOR_COMPACT, WILDLIFE_ECOLOGICAL, COHORT_AGGREGATE, INSTITUTIONAL_ACTOR.
