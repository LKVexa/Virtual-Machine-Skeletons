# Care, Commitment, and Significance — 7.0.0

Care is plural and domain-specific. Commitments are explicit, provenance-bearing undertakings. Significance is agent-relative and calculated from goal relevance, affective intensity, social relevance, values/care, novelty, and life-history context. None is canonical WORLD truth.
