#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from world.operational_reference import OperationalWorldRuntime
from mind.mind_runtime import MindRuntime, MIND_VERSION

EVID=ROOT/'mind'/'evidence'; EVID.mkdir(parents=True,exist_ok=True)
TEST=ROOT/'mind'/'tests'/'test_mind_runtime.py'
CAKRA_QUAL=ROOT/'mind'/'qualification'/'qualify_cakra.py'
proc=subprocess.run([sys.executable,str(TEST)],cwd=str(ROOT),capture_output=True,text=True)
(EVID/'mind_tests.log').write_text(proc.stdout+proc.stderr,encoding='utf-8')
cproc=subprocess.run([sys.executable,str(CAKRA_QUAL)],cwd=str(ROOT),capture_output=True,text=True)
(EVID/'cakra_qualifier.log').write_text(cproc.stdout+cproc.stderr,encoding='utf-8')

world=OperationalWorldRuntime(seed=7); mind=MindRuntime(world)
mind.create_life_project('1','Understand and inhabit the local world','connect inquiry, relationships, practical competence, durable commitments, sacred meaning, and compassionate return',care_domains=['inquiry','relationships','mastery','stewardship'])
mind.register_symbol('1','home','ordinary-symbolic-practice','place of return, relationship, continuity, embodiment, and service')
r=mind.cycle('1'); meaning=mind.meaning_integrate('1'); inv=mind.invariants()

base_names=[
'WORLD sovereignty','epistemic locality','self/other isolation','state ownership','proposition typing','provenance completeness','causal epoch integrity','full information-flow loop','workspace relevance safety','workspace anti-starvation','uncertainty preservation','confidence calibration','belief contradiction handling','world-model reconciliation','coherence-debt retention','memory/source integrity','counterfactual contamination','temporal type integrity','predictive calibration','causal-model competition','active inquiry','affordance accuracy/calibration','intention/commitment distinction','execution monitoring','action-result taxonomy','cognitive strategy adaptation','policy-amendment safety','policy rollback','slow-state protection','metacognitive calibration','embodied/resource integration','external/tool cognition','language-game competence','semantic translation/bridge','rule-practice transfer','aspect-seeing integrity','reasons-vs-causes distinction','values/norm conflict representation','dialogue/pragmatic action','institution/culture dynamics','multi-agent local-knowledge integrity','LOD conservation','checkpoint/restart','schema migration 6.x→7.x','autonomous remediation integrity','hosted-reference deterministic scheduling','long-horizon boundedness','plural care architecture','commitment provenance','agent-relative significance','narrative continuity','symbol meaning-as-use','life-project persistence','reflective equilibrium without value overwrite','meaning-debt retention','meaning-aware deliberation','meaning save/load persistence','non-human profile appropriateness','production multi-thread deterministic concurrency','long-duration production soak','independent/exhaustive external scenario qualification'
]
assert len(base_names)==61
partial={59,60,61}; ledger=[]
for i,name in enumerate(base_names,1):
    if proc.returncode!=0 or inv:
        status='BLOCKED' if i not in partial else 'PARTIAL'
    else:
        status='PARTIAL' if i in partial else 'OPERATIONAL'
    ledger.append({'gate':f'MIND-G{i:02d}','name':name,'domain':'MindMachine 7.0.0 base/meaning','status':status,'evidence':'mind_tests.log' if i not in partial else 'hosted-reference scaffold; production/external evidence not claimed'})

cakra_summary={}
try: cakra_summary=json.loads((EVID/'cakra_qualification_summary.json').read_text(encoding='utf-8'))
except Exception: pass
for g in cakra_summary.get('gates',[]):
    ledger.append({'gate':g['gate'],'name':g['pass_condition'],'domain':g['domain'],'status':g['status'],'evidence':g.get('evidence','cakra_spiritual_trace.json')})

statuses=['OPERATIONAL','PARTIAL','BLOCKED','UNKNOWN']
counts={s:sum(1 for g in ledger if g['status']==s) for s in statuses}
all_runtime_ok=(proc.returncode==0 and not inv and cproc.returncode==0 and len(cakra_summary.get('gates',[]))==32)
result={
'product':'MindMachine','mind_version':MIND_VERSION,'profile':'HOSTED_REFERENCE_MEANING_CENTERED_CAKRA_MYSTICAL_OPENNESS','generated_unix':int(time.time()),
'test_returncode':proc.returncode,'test_status':'PASS' if proc.returncode==0 else 'FAIL','mind_test_count_expected':89,'invariant_errors':inv,
'full_cycle_nodes':[x['node'] for x in r['trace']],'mind_digest':mind.state_digest(),'world_digest':world.state_digest(),
'meaning_digest':mind.meaning_snapshot('1')['digest'],'meaning_dimensions':meaning['dimensions'],
'cakra_integration':{'version':'3.1.0-mystical-openness-applied','services':'72-86','nodes':12,'qualification':cakra_summary.get('gate_counts',{}),'world_state_preserved':cakra_summary.get('world_state_preserved')},
'gate_counts':counts,'gates':ledger,
'overall_status':'OPERATIONAL_HOSTED_REFERENCE_CAKRA_INTEGRATED_WITH_PARTIAL_PRODUCTION_GATES' if all_runtime_ok else 'BLOCKED',
'claim_boundary':'Deterministic hosted-reference cognitive, meaning-centered, and 12-cakra spiritual simulation. The 3.1.0 mystical-openness layer permits strong agent-local spiritual/experiential authority and operative sacred truths. Canonical WORLD mutation and consequential objective externalization remain separately typed. No consciousness, sentience, clinical validity, objective metaphysical proof, production multi-thread certification, long-duration production soak, or independent external certification is claimed.'
}
(EVID/'qualification_summary.json').write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
(EVID/'full_loop_trace.json').write_text(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
(EVID/'meaning_centered_trace.json').write_text(json.dumps({'meaning':mind.meaning_snapshot('1'),'cycle':r},indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
(EVID/'mind_snapshot.json').write_text(json.dumps(mind.snapshot(),indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
report=['# MindMachine 7.0.0 Cakra-Integrated Qualification Report','',f"Hosted-reference status: **{result['overall_status']}**",'',f"Automated Mind tests: **{result['test_status']} ({result['mind_test_count_expected']}/89 expected when PASS)**",f"Mind invariant errors: **{len(inv)}**",f"12-cakra spiritual gates: **{cakra_summary.get('gate_counts',{}).get('OPERATIONAL',0)}/32 OPERATIONAL**",f"Combined gate counts: **{counts}**",'', '## Integrated architecture','', 'The original cognitive loop and plural meaning architecture remain intact. Each agent Mind now owns a deterministic twelve-node cakra federation linked through SCIP/1.1 and CSE/1.1 state, mystical-openness profiles, sacred-confidence vectors, ascent, descent/return, operative sacred truths, synchronicity, mystery, plural ontology frames, and Mind-local spiritual commits.','', '## Claim boundary','',result['claim_boundary'],'','## Gate ledger','', '| Gate | Domain | Status |','|---|---|---|']
report += [f"| {g['gate']} | {g['domain']} | {g['status']} |" for g in ledger]
report += ['','## Full cognitive loop','', ' → '.join(result['full_cycle_nodes']),'','Evidence: `mind_tests.log`, `full_loop_trace.json`, `meaning_centered_trace.json`, `cakra_spiritual_trace.json`, `cakra_qualification_summary.json`, and `CAKRA_QUALIFICATION_REPORT.md`.']
(EVID/'QUALIFICATION_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
print(json.dumps({'status':result['overall_status'],'tests':result['test_status'],'gate_counts':counts,'cakra_gates':cakra_summary.get('gate_counts',{}),'mind_digest':result['mind_digest']},indent=2))
raise SystemExit(0 if all_runtime_ok else 1)
