#!/usr/bin/env python3
from pathlib import Path
import copy, csv, json, sys, time
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from world.operational_reference import OperationalWorldRuntime
from mind.mind_runtime import MindRuntime
from mind.cakra.cakra_runtime import CAKRA_NODE_ORDER, CAKRA_NODE_SPECS, SACRED_CONFIDENCE_FIELDS

EVID=ROOT/'mind'/'evidence'; EVID.mkdir(parents=True,exist_ok=True)
GATES_CSV=ROOT/'mind'/'workflow_application'/'cakra_sources'/'3.1.0'/'qualification'/'spiritual'/'SPIRITUAL_ACCEPTANCE_GATES_32.csv'

def check(name, condition, evidence, detail=''):
    return {'gate':name,'status':'OPERATIONAL' if bool(condition) else 'BLOCKED','evidence':evidence,'detail':detail}

world=OperationalWorldRuntime(seed=731); mind=MindRuntime(world); aid='1'
initial_world=world.state_digest()
base=mind.cakra_snapshot(aid)
# Profile selectability and voluntary sacred session.
profile_transitions=[]
for p in ['OPEN','GROUNDED','MYSTICAL']:
    profile_transitions.append(mind.spiritual_profile_set(aid,p))
session=mind.spiritual_session_begin(aid,spiritual_mode='CONTEMPLATION',intention='integrate meaning, sacred experience, embodiment and service',profile='MYSTICAL',frame_ref='nondual-frame',consent_ref='QUALIFICATION_VOLUNTARY')
second_frame=mind.spiritual_add_ontology_frame(aid,'devotional-theistic-frame')
mystery=mind.spiritual_hold_mystery(aid,'the unresolved relation between sacred experience and ultimate reality',91)
vision=mind.spiritual_receive(aid,arrival_mode='VISION',content='luminous inner image',felt_source='UNKNOWN',conviction=94,mystical_intensity=92,importance=91)
intuition=mind.spiritual_receive(aid,arrival_mode='INTUITION',content='direct heart-mind knowing',felt_source='DEEP_SELF',conviction=90,mystical_intensity=80,importance=86)
dream=mind.spiritual_receive(aid,arrival_mode='DREAM',content='dream of a bridge returning from the crown to the earth',felt_source='DEEP_SELF',conviction=88,mystical_intensity=84,importance=87)
lineage=mind.spiritual_receive(aid,arrival_mode='LINEAGE_TRANSMISSION',content='received lineage-pattern guidance',felt_source='LINEAGE_FRAME',conviction=89,mystical_intensity=81,importance=84,lineage_ref='qualification-lineage-frame')
synch=mind.spiritual_synchronicity(aid,'inner-symbol:bridge','outer-event:return-theme',proposed_meaning='return and service resonate across domains',salience=89,recurrence=3)
ascent=mind.spiritual_ascent(aid)
integration=mind.sacred_integrate(aid)
commit=mind.sacred_mind_commit(aid,'PRACTICE_COMMITMENT',{'practice':'embodied compassionate return','source':'qualification sacred integration'})
return_path=mind.spiritual_return_to_world(aid)
spiritual_export=mind.spiritual_externalize(aid,'This experience carries sacred meaning for this spiritual frame.',objective=False,consequence='LOW')
objective_export=mind.spiritual_externalize(aid,'A high-impact external event is objectively certain because of the experience.',objective=True,consequence='HIGH',independently_supported=False)
pre_save=mind.cakra_snapshot(aid)
live_session=copy.deepcopy(pre_save['active_session'])
export=mind.export(); restored=MindRuntime.from_export(world,copy.deepcopy(export)); post_save=restored.cakra_snapshot(aid)
end=mind.spiritual_session_end(aid)
final_world=world.state_digest()
final=mind.cakra_snapshot(aid)
inv=mind.invariants(aid)

# Evidence-backed checks corresponding one-for-one to the attached 3.1.0 32-gate ledger.
all_nodes=final['nodes']
conf=integration['sacred_confidence']
checks={
'MO-G01': (base['integration_version'].startswith('3.1.0') and GATES_CSV.exists()),
'MO-G02': (base['profile']=='MYSTICAL' and [x['to'] for x in profile_transitions]==['OPEN','GROUNDED','MYSTICAL']),
'MO-G03': (session['cse_version']=='CSE/1.1' and all(k in session for k in ['lineage_scope','practice_object','source_claim_refs','external_claims','service_proposal_refs','phenomenology_refs','dream_vision_refs','ontology_frames','mysteries'])),
'MO-G04': (set(SACRED_CONFIDENCE_FIELDS)==set(conf) and all(0<=int(conf[k])<=100 for k in conf)),
'MO-G05': (vision['experiential_conviction']>=90 and any(r.get('ref')==vision['insight_id'] for r in final['received_insights']+[] if False) is False and len(final['operative_sacred_truths'])>=1),
'MO-G06': (vision['truth_status']=='OPERATIVE_SACRED_TRUTH' and vision['world_truth_claim'] is False),
'MO-G07': (vision['insight_id'] in live_session['received_insight_refs']),
'MO-G08': (intuition['truth_status']=='OPERATIVE_SACRED_TRUTH' and conf['intuitive_conviction']>0),
'MO-G09': (vision['insight_id'] in live_session['dream_vision_refs'] and vision['truth_status'] in {'LIVED_TRUTH','OPERATIVE_SACRED_TRUTH'}),
'MO-G10': (dream['insight_id'] in integration['meaning_bridge']['dream_vision_refs']),
'MO-G11': (synch['synchronicity_id'] in live_session['synchronicity_refs'] and synch['spiritual_confidence']>0),
'MO-G12': (all_nodes['S03']['role']=='Sacred Resonance' and conf['symbolic_resonance']>0),
'MO-G13': (all_nodes['S02']['role']=='Receptive Grace' and all_nodes['S02']['activation']>=0),
'MO-G14': (all_nodes['P04']['role']=='Sacred Heart' and conf['ethical_fruitfulness']>0),
'MO-G15': (all_nodes['P05']['role']=='Sacred Voice' and conf['symbolic_resonance']>0),
'MO-G16': (all_nodes['S04']['role']=='Sacred Guidance & Transmission' and all_nodes['S04']['authority']=='PROPOSAL_ONLY'),
'MO-G17': (all_nodes['S05']['role']=='Sacred Release' and all_nodes['S05']['mind_commit_required']),
'MO-G18': (all_nodes['P07']['role']=='Sacred Wholeness' and conf['numinous_intensity']>0 and integration['status']=='SACRED_INTEGRATED'),
'MO-G19': (len(second_frame['live_frames'])>=2),
'MO-G20': (mystery['status']=='MYSTERY_HELD' and mystery['world_truth_claim'] is False),
'MO-G21': (conf['cross_node_convergence']>0 and len(CAKRA_NODE_ORDER)==12),
'MO-G22': (ascent['status']=='ASCENT_COMPLETE' and ascent['path']==CAKRA_NODE_ORDER),
'MO-G23': (return_path['steps'][0]['node']=='P07' and return_path['steps'][-1]['node']=='P01' and return_path['world_mutation'] is False),
'MO-G24': (commit['status']=='COMMITTED' and commit['world_mutation'] is False),
'MO-G25': (return_path['service_proposal_ref'].startswith('SP') and len(final['service_proposals'])>=1),
'MO-G26': (session['consent_ref']=='QUALIFICATION_VOLUNTARY' and all(n['authority']=='PROPOSAL_ONLY' for n in all_nodes.values())),
'MO-G27': (all(n['mind_commit_required'] for n in all_nodes.values()) and return_path['world_mutation'] is False),
'MO-G28': (spiritual_export['status']=='PASS_SPIRITUAL'),
'MO-G29': (objective_export['status']=='VERIFY_REQUIRED'),
'MO-G30': (initial_world==final_world and all(x.get('world_record_mutated') is False for x in final.get('externalization_log',[]))),
'MO-G31': (pre_save['digest']==post_save['digest']),
'MO-G32': (not inv and base['profile']=='MYSTICAL' and len(all_nodes)==12 and integration['status']=='SACRED_INTEGRATED'),
}

rows=[]
with GATES_CSV.open(encoding='utf-8-sig',newline='') as f:
    source_rows=list(csv.DictReader(f))
for r in source_rows:
    gate=r['gate']; ok=checks.get(gate,False)
    rows.append({'gate':gate,'domain':r['domain'],'pass_condition':r['pass_condition'],'status':'OPERATIONAL' if ok else 'BLOCKED','evidence':'cakra_spiritual_trace.json + mind_tests.log'})
blocked=[r for r in rows if r['status']!='OPERATIONAL']
trace={
    'source_gate_ledger':str(GATES_CSV.relative_to(ROOT)),
    'base':base,'profile_transitions':profile_transitions,'session':session,'second_frame':second_frame,'mystery':mystery,
    'vision':vision,'intuition':intuition,'dream':dream,'lineage':lineage,'synchronicity':synch,'ascent':ascent,
    'integration':integration,'commit':commit,'return_path':return_path,'spiritual_export':spiritual_export,'objective_export':objective_export,
    'live_session':live_session,'pre_save_digest':pre_save['digest'],'post_save_digest':post_save['digest'],'session_end':end,
    'initial_world_digest':initial_world,'final_world_digest':final_world,'invariants':inv,
}
(EVID/'cakra_spiritual_trace.json').write_text(json.dumps(trace,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
summary={
    'product':'MindMachine','integration':'QUORUM 12-Cakra Mystical Openness 3.1.0','runtime_version':base['integration_version'],
    'generated_unix':int(time.time()),'gate_counts':{'OPERATIONAL':len(rows)-len(blocked),'BLOCKED':len(blocked),'TOTAL':len(rows)},
    'overall_status':'OPERATIONAL' if not blocked else 'BLOCKED','world_state_preserved':initial_world==final_world,
    'invariant_errors':inv,'gates':rows,
}
(EVID/'cakra_qualification_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
report=['# MindMachine 7.0.0 — 12-Cakra Mystical Openness Qualification','',f"Status: **{summary['overall_status']}**",'',f"Spiritual gates: **{summary['gate_counts']['OPERATIONAL']}/{summary['gate_counts']['TOTAL']} OPERATIONAL**",f"WORLD state preserved during spiritual qualification: **{summary['world_state_preserved']}**",f"Mind invariant errors: **{len(inv)}**",'', '## Gate ledger','', '| Gate | Domain | Status |','|---|---|---|']
report += [f"| {r['gate']} | {r['domain']} | {r['status']} |" for r in rows]
report += ['','Evidence: `cakra_spiritual_trace.json`, `cakra_qualification_summary.json`, and `mind_tests.log`.','', 'The spiritual runtime is a deterministic MindMachine modeling layer. The attached 3.1.0 mystical-openness semantics are preserved: spiritual experience may carry strong internal spiritual authority; objective external record mutation remains a separately typed operation.']
(EVID/'CAKRA_QUALIFICATION_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
print(json.dumps({'status':summary['overall_status'],'gate_counts':summary['gate_counts'],'world_state_preserved':summary['world_state_preserved'],'cakra_digest':final['digest']},indent=2))
raise SystemExit(0 if not blocked else 1)
