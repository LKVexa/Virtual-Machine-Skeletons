#!/usr/bin/env python3
"""MindMachine 7.0.0 hosted-reference meaning-centered + twelve-cakra cognitive runtime.

This module applies the QUORUM Cognitive-Psychological + Later-Wittgenstein
workflow series to the hosted QVM world runtime. It is a deterministic
simulation architecture, not a claim of consciousness, sentience, clinical
validity, or human psychological equivalence.

Authority law:
- WORLD owns canonical world facts and committed physical/social effects.
- MIND owns agent-local perceptions, beliefs, appraisals, affect, motives,
  memories, self-models, goals, deliberation, intentions, social models,
  semantic practice state, and learning.
- An ACTION is an intention/request until WORLD commits or rejects it.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from mind.cakra.cakra_runtime import CakraFederationRuntime, CAKRA_NODE_ORDER, SPIRITUAL_PROFILES

MIND_VERSION = "7.0.0-cakra-integrated-mystical-openness-hosted-reference"
MIND_SCHEMA = "MINDMACHINE-MIND/7"
MIND_SAVE_SCHEMA = "MINDMACHINE-SAVE/1"
MIND_LEDGER_SCHEMA = "MINDMACHINE-LEDGER/1"
CANONICAL_FLOW = [
    "WORLD","PERCEPTION","ATTENTION","BELIEF","APPRAISAL","EMOTION",
    "MOTIVATION","MEMORY","SELF","GOALS","DELIBERATION","DECISION",
    "ACTION","WORLD_RESULT","LEARNING",
]
PROFILES = {
    "MAJOR_ACTOR_FULL": {"attention": 8, "memory": 256, "deliberation": 6, "social_depth": 3, "semantic": True},
    "MINOR_ACTOR_COMPACT": {"attention": 4, "memory": 96, "deliberation": 4, "social_depth": 1, "semantic": True},
    "WILDLIFE_ECOLOGICAL": {"attention": 3, "memory": 64, "deliberation": 3, "social_depth": 1, "semantic": False},
    "COHORT_AGGREGATE": {"attention": 2, "memory": 32, "deliberation": 2, "social_depth": 0, "semantic": False},
    "INSTITUTIONAL_ACTOR": {"attention": 5, "memory": 128, "deliberation": 5, "social_depth": 2, "semantic": True},
}
GOAL_CODES = {"maintain": 1, "avoid_threat": 2, "seek_food": 3, "seek_information": 4, "social_repair": 5}
ACTION_CODES = {"WAIT": 0, "MOVE_AWAY": 1, "MOVE_TOWARD": 2, "SEEK_INFO": 3, "OBSERVE": 4}
ACTION_CODE_NAMES = {v:k for k,v in ACTION_CODES.items()}


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()


def named_u64(seed: int, *parts: Any) -> int:
    return int.from_bytes(hashlib.sha256(canonical_bytes([int(seed), *parts])).digest()[:8], "big")


def clamp(v: int, lo: int = 0, hi: int = 100) -> int:
    return max(lo, min(hi, int(v)))


def distance3(a: Iterable[int], b: Iterable[int]) -> int:
    av = [int(x) for x in a]; bv = [int(x) for x in b]
    return int(round(sum((x-y)*(x-y) for x,y in zip(av,bv)) ** 0.5))


def step_toward(src: List[int], dst: List[int], step: int = 50, away: bool = False) -> List[int]:
    dx = [int(dst[i]) - int(src[i]) for i in range(3)]
    if away:
        dx = [-x for x in dx]
    mag = max(1, distance3([0,0,0], dx))
    return [int(src[i]) + int(round(step * dx[i] / mag)) for i in range(3)]


class MindError(RuntimeError):
    pass


class MindRuntime:
    """Deterministic, persistent, agent-local cognitive runtime."""

    def __init__(self, world: Any, *, seed: Optional[int] = None, auto_initialize: bool = True):
        if world is None:
            raise MindError("MindRuntime requires an initialized WORLD runtime")
        self.world = world
        self.seed = int(seed if seed is not None else (int(getattr(world, "seed", 1)) ^ 0x4D494E444D414348))
        self.minds: Dict[str, Dict[str, Any]] = {}
        self.ledger: List[Dict[str, Any]] = []
        self.ledger_head = "0" * 64
        self.workspace_seq = 0
        self.policy_version = "mind-policy/7.0.0-cakra-integrated"
        self.semantic_version = "mind-semantics/wittgenstein-cakra-7"
        self.scheduler_version = "mind-scheduler/7-cakra"
        self.causal_epoch = 0
        self.recovery_log: List[Dict[str, Any]] = []
        self.remediation_log: List[Dict[str, Any]] = []
        self.cakra = CakraFederationRuntime(self)
        if auto_initialize:
            self.sync_agents()
            self._event("MIND_RUNTIME_INIT", {"agents": len(self.minds), "seed": self.seed})

    # ---------------- authority / identity ----------------
    def profile_for_entity(self, eid: str) -> str:
        ent = self.world.entities[str(eid)]
        kind = str(ent.get("kind", "generic")).lower()
        if kind in {"wolf", "deer", "wildlife", "animal"}:
            return "WILDLIFE_ECOLOGICAL"
        if kind in {"player", "agent", "sheriff"} or str(eid) == str(getattr(self.world, "reference_entity", "1")):
            return "MAJOR_ACTOR_FULL"
        if kind in {"institution"}:
            return "INSTITUTIONAL_ACTOR"
        return "MINOR_ACTOR_COMPACT"

    def sync_agents(self) -> None:
        for eid in sorted(self.world.entities, key=lambda x: int(x) if str(x).isdigit() else str(x)):
            if eid not in self.minds:
                self.minds[eid] = self._new_mind(eid, self.profile_for_entity(eid))
            self.cakra.ensure_state(self.minds[eid])
        for eid in list(self.minds):
            if eid not in self.world.entities:
                self.minds[eid]["lifecycle"] = "DETACHED_WORLD_ENTITY"

    def _new_mind(self, eid: str, profile: str) -> Dict[str, Any]:
        if profile not in PROFILES:
            raise MindError("unknown profile")
        ent = self.world.entities[str(eid)]
        trait = lambda name: 25 + named_u64(self.seed, "trait", eid, name) % 51
        values = {
            "care": 30 + named_u64(self.seed,"value",eid,"care") % 51,
            "duty": 30 + named_u64(self.seed,"value",eid,"duty") % 51,
            "autonomy": 30 + named_u64(self.seed,"value",eid,"autonomy") % 51,
            "achievement": 30 + named_u64(self.seed,"value",eid,"achievement") % 51,
        }
        if profile == "WILDLIFE_ECOLOGICAL":
            values = {}
        return {
            "schema": MIND_SCHEMA,
            "mind_version": MIND_VERSION,
            "agent_id": str(eid),
            "profile": profile,
            "lifecycle": "ACTIVE",
            "created_world_tick": int(self.world.tick),
            "cycle": 0,
            "causal_epoch": 0,
            "perception": {"items": [], "digest": None, "world_tick": self.world.tick},
            "attention": {"selected": [], "suppressed": [], "budget": PROFILES[profile]["attention"]},
            "beliefs": {},
            "appraisal": {"threat": 0, "opportunity": 0, "novelty": 0, "controllability": 50, "certainty": 50, "valence": 0},
            "emotion": {"fear": 0, "curiosity": 25, "contentment": 50, "anger": 0, "arousal": 20, "valence": 0, "regulation": "none"},
            "motivation": {"needs": {"safety": 50, "energy": 80, "hunger": 20, "belonging": 40, "curiosity": 35}, "top": "maintain", "strength": 50},
            "memory": {"episodes": [], "semantic_use": {}, "prospective": [], "summaries": []},
            "self_model": {
                "roles": [], "active_role": "self", "values": values,
                "traits": {"openness":trait("openness"),"conscientiousness":trait("conscientiousness"),"extraversion":trait("extraversion"),"agreeableness":trait("agreeableness"),"emotional_stability":trait("emotional_stability")},
                "competence": {"navigation": 50, "social": 50, "inquiry": 50},
                "self_efficacy": 50, "narrative_anchors": [], "reputation_as_believed": {},
            },
            "goals": [],
            "deliberation": {"options": [], "resource_budget": PROFILES[profile]["deliberation"], "counterfactuals": []},
            "decision": {"action": "WAIT", "target": None, "score": 0, "confidence": 50, "reasons": []},
            "agency": {"desire": None, "goal": None, "intention": None, "commitment": None, "plan": None, "attempt": None, "world_result": None},
            "learning": {"updates": 0, "prediction_error": 0, "strategy_success": {}, "calibration": 50},
            "relationships": {},
            "theory_of_mind": {},
            "workspace": {"active": [], "deferred": [], "starvation": {}},
            "coherence": {"status": "UNKNOWN", "debt": [], "last_reconcile": None},
            "temporal_horizons": {h: [] for h in ["H0_IMMEDIATE","H1_SHORT","H2_TACTICAL","H3_STRATEGIC","H4_DEVELOPMENTAL","H5_SOCIAL_HISTORICAL"]},
            "semantic": {"language_games": {}, "form_of_life": "ecological" if profile=="WILDLIFE_ECOLOGICAL" else "local-world-practice", "competence": {}, "hinges": {"world_persists": 90, "actions_have_consequences": 90}},
            "metacognition": {"confidence": 50, "uncertainty_burden": 0, "coherence_debt": 0, "attention_misses": 0, "recovery_count": 0},
            "policy": {"version": self.policy_version, "attention_policy": "relevance-fair/2", "strategy": "adaptive-meaning-aware/1", "amendments": []},
            "meaning": {
                "care_map": self._initial_care_map(profile, values, trait),
                "commitments": [],
                "significance": [],
                "narrative": {"chapters": [], "continuity": 50, "open_tensions": [], "current_theme": "orientation"},
                "symbols": {},
                "life_projects": [],
                "meaning_debt": [],
                "dimensions": {"coherence": 50, "purpose": 30, "belonging": 40, "agency": 50, "continuity": 50, "value_alignment": 50},
                "reflective_equilibrium": {"alignment": 50, "tensions": [], "revision_proposals": [], "last_review_tick": None},
                "last_integration_tick": None,
            },
            "last_trace": [],
        }

    def _initial_care_map(self, profile: str, values: Dict[str, Any], trait_fn: Any) -> Dict[str, int]:
        """Meaning is represented as a plural care structure, never one global scalar."""
        if profile == "WILDLIFE_ECOLOGICAL":
            return {"survival":85,"offspring_or_social_group":50,"territory":55,"resources":70,"exploration":35}
        return {
            "survival":70,
            "relationships":clamp(values.get("care",50)),
            "duty":clamp(values.get("duty",50)),
            "autonomy":clamp(values.get("autonomy",50)),
            "mastery":clamp(values.get("achievement",50)),
            "inquiry":clamp(trait_fn("openness")),
            "belonging":50,
            "stewardship":clamp((values.get("care",50)+values.get("duty",50))//2),
        }

    def _ensure_meaning_state(self, m: Dict[str, Any]) -> None:
        """Schema-safe migration hook for 6.x hosted-reference mind states."""
        if "meaning" in m:
            return
        values=m.get("self_model",{}).get("values",{})
        traits=m.get("self_model",{}).get("traits",{})
        profile=m.get("profile","MINOR_ACTOR_COMPACT")
        if profile=="WILDLIFE_ECOLOGICAL":
            care={"survival":85,"offspring_or_social_group":50,"territory":55,"resources":70,"exploration":35}
        else:
            care={"survival":70,"relationships":clamp(values.get("care",50)),"duty":clamp(values.get("duty",50)),"autonomy":clamp(values.get("autonomy",50)),"mastery":clamp(values.get("achievement",50)),"inquiry":clamp(traits.get("openness",50)),"belonging":50,"stewardship":clamp((values.get("care",50)+values.get("duty",50))//2)}
        m["meaning"]={"care_map":care,"commitments":[],"significance":[],"narrative":{"chapters":[],"continuity":50,"open_tensions":[],"current_theme":"migration"},"symbols":{},"life_projects":[],"meaning_debt":[],"dimensions":{"coherence":50,"purpose":30,"belonging":40,"agency":m.get("self_model",{}).get("self_efficacy",50),"continuity":50,"value_alignment":50},"reflective_equilibrium":{"alignment":50,"tensions":[],"revision_proposals":[],"last_review_tick":None},"last_integration_tick":None}
        m["schema"]=MIND_SCHEMA; m["mind_version"]=MIND_VERSION

    def require_agent(self, agent_id: str) -> Dict[str, Any]:
        self.sync_agents()
        aid = str(agent_id)
        if aid not in self.minds or aid not in self.world.entities:
            raise MindError(f"unknown agent {aid}")
        self._ensure_meaning_state(self.minds[aid])
        self.cakra.ensure_state(self.minds[aid])
        return self.minds[aid]

    # ---------------- ledger / digest / persistence ----------------
    def _event(self, kind: str, payload: Dict[str, Any], *, agent: Optional[str] = None, cause: Optional[List[str]] = None) -> str:
        event_id = f"M{len(self.ledger)+1:08d}"
        body = {
            "schema": MIND_LEDGER_SCHEMA,
            "event_id": event_id,
            "mind_tick": len(self.ledger),
            "world_tick": int(self.world.tick),
            "causal_epoch": int(self.causal_epoch),
            "agent": str(agent) if agent is not None else None,
            "kind": str(kind),
            "payload": copy.deepcopy(payload),
            "cause": list(cause or ([] if not self.ledger else [self.ledger[-1]["event_id"]])),
            "prev_hash": self.ledger_head,
        }
        body["event_hash"] = hashlib.sha256(bytes.fromhex(self.ledger_head) + canonical_bytes(body)).hexdigest()
        self.ledger_head = body["event_hash"]
        self.ledger.append(body)
        return event_id

    def verify_ledger(self) -> bool:
        prev = "0" * 64
        for idx, rec in enumerate(self.ledger, 1):
            if rec.get("event_id") != f"M{idx:08d}" or rec.get("prev_hash") != prev:
                return False
            body = {k: copy.deepcopy(v) for k,v in rec.items() if k != "event_hash"}
            expect = hashlib.sha256(bytes.fromhex(prev) + canonical_bytes(body)).hexdigest()
            if rec.get("event_hash") != expect:
                return False
            prev = expect
        return prev == self.ledger_head

    def canonical_state(self) -> Dict[str, Any]:
        return {
            "schema": MIND_SCHEMA,
            "version": MIND_VERSION,
            "seed": self.seed,
            "world_state_digest": self.world.state_digest(),
            "world_tick": self.world.tick,
            "policy_version": self.policy_version,
            "semantic_version": self.semantic_version,
            "scheduler_version": self.scheduler_version,
            "causal_epoch": self.causal_epoch,
            "minds": copy.deepcopy(self.minds),
            "ledger_head": self.ledger_head,
        }

    def state_digest(self) -> str:
        return sha256_obj(self.canonical_state())

    def export(self) -> Dict[str, Any]:
        obj = {"schema": MIND_SAVE_SCHEMA, "state": self.canonical_state(), "ledger": copy.deepcopy(self.ledger), "recovery_log": copy.deepcopy(self.recovery_log), "remediation_log": copy.deepcopy(self.remediation_log)}
        obj["integrity_sha256"] = sha256_obj(obj)
        return obj

    def save(self, path: Path) -> str:
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        obj = self.export(); path.write_bytes(canonical_bytes(obj) + b"\n")
        return obj["integrity_sha256"]

    @classmethod
    def from_export(cls, world: Any, obj: Dict[str, Any]) -> "MindRuntime":
        if obj.get("schema") != MIND_SAVE_SCHEMA:
            raise MindError("unsupported mind save schema")
        cp = copy.deepcopy(obj); given = cp.pop("integrity_sha256", None)
        if given != sha256_obj(cp):
            raise MindError("mind save integrity failure")
        state = cp["state"]
        m = cls(world, seed=int(state["seed"]), auto_initialize=False)
        m.policy_version = state["policy_version"]; m.semantic_version = state["semantic_version"]; m.scheduler_version = state["scheduler_version"]
        m.causal_epoch = int(state["causal_epoch"]); m.minds = copy.deepcopy(state["minds"]); m.ledger = copy.deepcopy(cp["ledger"]); m.ledger_head = state["ledger_head"]
        m.recovery_log = copy.deepcopy(cp.get("recovery_log", [])); m.remediation_log = copy.deepcopy(cp.get("remediation_log", []))
        for _aid,_mind in m.minds.items():
            m._ensure_meaning_state(_mind)
            m.cakra.ensure_state(_mind)
        if not m.verify_ledger():
            raise MindError("mind ledger integrity failure")
        return m

    # ---------------- workspace / semantics / coherence ----------------
    def _publish_workspace(self, m: Dict[str, Any], kind: str, content: Dict[str, Any], *, salience: int, urgency: int = 0, confidence: int = 50, semantic_context: Optional[str] = None) -> str:
        self.workspace_seq += 1
        rec = {
            "workspace_item_id": f"W{self.workspace_seq:08d}", "kind": kind, "content": copy.deepcopy(content),
            "salience": clamp(salience), "urgency": clamp(urgency), "confidence": clamp(confidence),
            "goal_relevance": clamp(content.get("goal_relevance", 0)), "social_relevance": clamp(content.get("social_relevance", 0)),
            "semantic_context": semantic_context or "ordinary-world-practice", "world_tick": self.world.tick,
            "ttl": 3, "privacy": "AGENT_LOCAL", "evidence_refs": list(content.get("evidence_refs", [])),
        }
        m["workspace"]["active"].append(rec)
        # bounded, deterministic, fair-ish: keep top 24 but preserve at least one item per kind
        items = m["workspace"]["active"]
        items.sort(key=lambda x: (-(x["urgency"]*2+x["salience"]+x["goal_relevance"]), x["workspace_item_id"]))
        if len(items) > 24:
            m["workspace"]["deferred"].extend(items[24:]); del items[24:]
        return rec["workspace_item_id"]

    def semantic_bridge(self, agent_id: str, expression: str, source_game: str, target_game: str) -> Dict[str, Any]:
        m = self.require_agent(agent_id)
        if not PROFILES[m["profile"]]["semantic"]:
            return {"status":"NO_GOOD_EQUIVALENT","confidence":0,"source_game":source_game,"target_game":target_game}
        key = f"{source_game}->{target_game}:{expression.lower()}"
        known = m["memory"]["semantic_use"].get(key)
        if known:
            return copy.deepcopy(known)
        same = source_game == target_game
        rep = {
            "status":"EQUIVALENT" if same else "PARTIAL",
            "source_game":source_game,"target_game":target_game,"expression":expression,
            "practical_move":expression.lower().strip(), "lost_distinctions":[] if same else ["community-context"],
            "confidence":90 if same else 45, "examples":[], "correction_history":[],
        }
        m["memory"]["semantic_use"][key] = copy.deepcopy(rep)
        return rep

    def reconcile_world_model(self, agent_id: str) -> Dict[str, Any]:
        m = self.require_agent(agent_id)
        conflicts = []
        for pid, belief in m["beliefs"].items():
            if belief.get("contradiction"):
                conflicts.append({"type":"CONTRADICTION","belief":pid,"confidence":belief.get("confidence",0)})
        # source conflicts with same proposition are retained as alternatives
        groups: Dict[str, set] = {}
        for pid, belief in m["beliefs"].items():
            base = belief.get("subject", pid)
            groups.setdefault(base, set()).add(json.dumps(belief.get("value"), sort_keys=True))
        for subj, vals in groups.items():
            if len(vals) > 1:
                conflicts.append({"type":"SOURCE_CONFLICT","subject":subj,"alternatives":len(vals)})
        debt = []
        for c in conflicts:
            debt.append({"debt_id":f"CD{named_u64(self.seed,agent_id,self.world.tick,c)%100000000:08d}","source":c,"risk":60,"age":0,"status":"OPEN"})
        m["coherence"]["status"] = "CONSISTENT" if not conflicts else "TENSION"
        # preserve existing unresolved debt plus new unique debt
        existing = {d["debt_id"]:d for d in m["coherence"]["debt"] if d.get("status") == "OPEN"}
        for d in debt: existing.setdefault(d["debt_id"], d)
        m["coherence"]["debt"] = list(existing.values())
        m["coherence"]["last_reconcile"] = self.world.tick
        m["metacognition"]["coherence_debt"] = len(m["coherence"]["debt"])
        return {"status":m["coherence"]["status"],"debt":len(m["coherence"]["debt"]),"conflicts":copy.deepcopy(conflicts)}

    # ---------------- cognitive information flow ----------------
    def perceive(self, agent_id: str) -> Dict[str, Any]:
        m = self.require_agent(agent_id); aid = str(agent_id); ent = self.world.entities[aid]
        radius = 6000 if m["profile"] == "MAJOR_ACTOR_FULL" else 2500 if m["profile"] == "MINOR_ACTOR_COMPACT" else 1800
        items = [{"type":"PERCEPT","modality":"interoceptive","subject":aid,"fact":"self_position","value":list(ent["pos"]),"confidence":100,"source":"body/world-interface","distance":0,"evidence_refs":[]}]
        for oid, other in sorted(self.world.entities.items(), key=lambda kv: int(kv[0]) if str(kv[0]).isdigit() else str(kv[0])):
            if oid == aid or not other.get("alive", True):
                continue
            d = distance3(ent["pos"], other["pos"])
            if d <= radius:
                conf = clamp(100 - int(d * 55 / max(1, radius)), 35, 100)
                items.append({"type":"PERCEPT","modality":"visual","subject":oid,"fact":"entity_present","value":True,"kind":other.get("kind","unknown"),"confidence":conf,"source":"direct_visual","distance":d,"evidence_refs":[]})
        # explicit observer-local knowledge provided by WORLD is lawful evidence
        for fact_id, rec in sorted(getattr(self.world, "knowledge", {}).get(aid, {}).items()):
            items.append({"type":"PERCEPT","modality":"testimony_memory","subject":fact_id,"fact":"known_fact","value":copy.deepcopy(rec.get("value")),"confidence":clamp(rec.get("confidence",50)),"source":rec.get("source","world_knowledge"),"distance":0,"evidence_refs":[]})
        m["perception"] = {"items":items,"digest":sha256_obj(items),"world_tick":self.world.tick}
        for it in items:
            threat = 95 if str(it.get("kind","")) == "wolf" and aid != it.get("subject") else 0
            self._publish_workspace(m,"PERCEPT",it,salience=max(20,threat,100-min(100,it.get("distance",0)//20)),urgency=threat,confidence=it["confidence"])
        self._event("PERCEPTION", {"count":len(items),"digest":m["perception"]["digest"]}, agent=aid)
        return copy.deepcopy(m["perception"])

    def attend(self, agent_id: str) -> Dict[str, Any]:
        m = self.require_agent(agent_id)
        candidates = copy.deepcopy(m["perception"]["items"])
        scored=[]
        current_goal = m["goals"][0]["kind"] if m["goals"] else "maintain"
        for idx,it in enumerate(candidates):
            sal = 20
            if it.get("kind") == "wolf": sal += 70
            if it.get("kind") == "merchant" and current_goal == "seek_food": sal += 40
            sal += max(0, 30 - int(it.get("distance",0)//100))
            novelty = 15 if f"entity:{it.get('subject')}:present" not in m["beliefs"] else 0
            scored.append((-(sal+novelty), idx, it))
        scored.sort(key=lambda x:(x[0],x[1]))
        budget = int(m["attention"]["budget"])
        selected=[x[2] for x in scored[:budget]]; suppressed=[x[2] for x in scored[budget:]]
        m["attention"]={"selected":selected,"suppressed":suppressed,"budget":budget}
        self._event("ATTENTION", {"selected":len(selected),"suppressed":len(suppressed),"digest":sha256_obj(selected)}, agent=str(agent_id))
        return copy.deepcopy(m["attention"])

    def update_beliefs(self, agent_id: str) -> Dict[str, Any]:
        m = self.require_agent(agent_id); updates=0
        for it in m["attention"]["selected"]:
            subj=str(it.get("subject")); fact=it.get("fact")
            pid=f"{subj}:{fact}"
            previous=m["beliefs"].get(pid)
            belief={
                "type":"BELIEF","subject":subj,"predicate":fact,"value":copy.deepcopy(it.get("value")),
                "kind":it.get("kind"),"confidence":clamp(it.get("confidence",50)),"source":it.get("source"),
                "provenance":{"percept_digest":m["perception"]["digest"],"world_tick":self.world.tick},
                "semantic_context":"observation-game","contradiction":False,"last_updated":self.world.tick,
            }
            if previous and previous.get("value") != belief["value"] and previous.get("confidence",0) >= 60:
                belief["contradiction"] = True
            m["beliefs"][pid]=belief; updates+=1
        rec=self.reconcile_world_model(agent_id)
        self._event("BELIEF", {"updates":updates,"beliefs":len(m["beliefs"]),"coherence":rec["status"]}, agent=str(agent_id))
        return {"updates":updates,"beliefs":copy.deepcopy(m["beliefs"]),"coherence":rec}

    def appraise(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        threat=0; opportunity=0; novelty=0; certainty=50
        for it in m["attention"]["selected"]:
            d=int(it.get("distance",0)); kind=str(it.get("kind",""))
            if kind=="wolf" and it.get("subject")!=aid:
                threat=max(threat, clamp(100-d//30))
            if kind=="merchant": opportunity=max(opportunity,clamp(80-d//50))
            if f"entity:{it.get('subject')}:present" not in m["beliefs"]: novelty=max(novelty,50)
            certainty=max(certainty,int(it.get("confidence",50)))
        health=int(self.world.entities[aid].get("health",100))
        if health < 50: threat=max(threat,70-health//2)
        valence=clamp(opportunity-threat,-100,100)
        app={"threat":threat,"opportunity":opportunity,"novelty":novelty,"controllability":clamp(70-threat//3),"certainty":clamp(certainty),"valence":valence,"role_context":m["self_model"].get("active_role","self")}
        m["appraisal"]=app
        self._publish_workspace(m,"APPRAISAL",app,salience=max(threat,opportunity,30),urgency=threat,confidence=certainty)
        self._event("APPRAISAL", app, agent=aid); return copy.deepcopy(app)

    def affect_step(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); a=m["appraisal"]
        fear=clamp(a["threat"]); curiosity=clamp(20+a["novelty"]//2); anger=clamp(max(0,a["threat"]-a["controllability"])//2)
        content=clamp(60 + a["valence"]//3 - fear//3); arousal=clamp(20+fear//2+a["novelty"]//3)
        # learned regulation: high fear + decent control -> reappraise; otherwise attentional deployment
        regulation="reappraise" if fear>60 and a["controllability"]>=45 else "attentional-deployment" if fear>70 else "none"
        if regulation=="reappraise": fear=clamp(fear-10)
        emo={"fear":fear,"curiosity":curiosity,"contentment":content,"anger":anger,"arousal":arousal,"valence":clamp(content-fear,-100,100),"regulation":regulation}
        m["emotion"]=emo
        self._publish_workspace(m,"EMOTION",emo,salience=max(fear,curiosity,30),urgency=fear,confidence=80)
        self._event("EMOTION", emo, agent=str(agent_id)); return copy.deepcopy(emo)

    def motivation_step(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); needs=m["motivation"]["needs"]
        needs["hunger"]=clamp(needs.get("hunger",20)+1); needs["energy"]=clamp(needs.get("energy",80)-1)
        needs["safety"]=clamp(100-m["emotion"]["fear"])
        needs["curiosity"]=clamp(25+m["emotion"]["curiosity"]//2)
        pressures={"avoid_threat":100-needs["safety"],"seek_food":needs["hunger"],"seek_information":needs["curiosity"],"maintain":50}
        top=sorted(pressures.items(),key=lambda kv:(-kv[1],kv[0]))[0]
        m["motivation"]={"needs":needs,"top":top[0],"strength":top[1],"pressures":pressures}
        self._event("MOTIVATION", {"top":top[0],"strength":top[1],"needs":copy.deepcopy(needs)}, agent=str(agent_id)); return copy.deepcopy(m["motivation"])

    def memory_step(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        episode={
            "memory_id":f"ME{named_u64(self.seed,aid,m['cycle'],self.world.tick,len(m['memory']['episodes']))%100000000:08d}",
            "type":"MEMORY_EXPERIENCED","world_tick":self.world.tick,"source":"experienced-perception-cycle",
            "content":{"attention":copy.deepcopy(m["attention"]["selected"]),"emotion":copy.deepcopy(m["emotion"]),"motivation":m["motivation"]["top"]},
            "confidence":80,"emotional_intensity":max(m["emotion"]["fear"],m["emotion"]["arousal"]),"provenance":{"perception_digest":m["perception"]["digest"]},
        }
        m["memory"]["episodes"].append(episode)
        limit=PROFILES[m["profile"]]["memory"]
        if len(m["memory"]["episodes"])>limit:
            old=m["memory"]["episodes"][:-limit]
            if old:
                m["memory"]["summaries"].append({"type":"COMPRESSED","count":len(old),"digest":sha256_obj(old),"provenance":"LOD_OR_BUDGET_COMPACTION"})
            m["memory"]["episodes"]=m["memory"]["episodes"][-limit:]
        self._event("MEMORY", {"memory_id":episode["memory_id"],"episodes":len(m["memory"]["episodes"])}, agent=aid)
        return copy.deepcopy(episode)

    def self_step(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        roles=[role for role,eid in getattr(self.world,"roles",{}).items() if str(eid)==aid]
        m["self_model"]["roles"]=sorted(roles)
        m["self_model"]["active_role"]=roles[0] if roles else "self"
        if not m["self_model"]["narrative_anchors"]:
            m["self_model"]["narrative_anchors"].append({"kind":"origin","world_tick":m["created_world_tick"],"entity":aid})
        # self-efficacy changes slowly from action results
        last=m["agency"].get("world_result")
        if last:
            delta=1 if last.get("status") in {"SUCCESS","NOOP_SUCCESS"} else -1
            m["self_model"]["self_efficacy"]=clamp(m["self_model"]["self_efficacy"]+delta)
        self._event("SELF", {"active_role":m["self_model"]["active_role"],"self_efficacy":m["self_model"]["self_efficacy"]}, agent=aid)
        return copy.deepcopy(m["self_model"])

    def goal_select(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); top=m["motivation"]["top"]
        kind=top if top in GOAL_CODES else "maintain"
        # preserve existing unresolved goal when still relevant; otherwise create a current goal
        active=[g for g in m["goals"] if g.get("status")=="ACTIVE"]
        if active and active[0]["kind"]==kind:
            goal=active[0]
        else:
            for g in active: g["status"]="SHELVED"
            goal={"goal_id":f"G{named_u64(self.seed,agent_id,m['cycle'],kind)%100000000:08d}","kind":kind,"status":"ACTIVE","priority":m["motivation"]["strength"],"created_tick":self.world.tick,"horizon":"H0_IMMEDIATE" if kind=="avoid_threat" else "H1_SHORT","source":"motivation","parent":None,"blocked":False}
            m["goals"].insert(0,goal)
        m["agency"]["desire"]={"kind":top,"strength":m["motivation"]["strength"]}; m["agency"]["goal"]=copy.deepcopy(goal)
        m["temporal_horizons"][goal["horizon"]]=[goal["goal_id"]]
        self._event("GOALS", {"goal":goal}, agent=str(agent_id)); return copy.deepcopy(goal)

    def _visible_targets(self, m: Dict[str, Any], kind: Optional[str] = None) -> List[Tuple[str,int,str]]:
        out=[]
        for it in m["attention"]["selected"]:
            if it.get("fact")!="entity_present": continue
            if kind and it.get("kind")!=kind: continue
            out.append((str(it["subject"]),int(it.get("distance",0)),str(it.get("kind","unknown"))))
        return sorted(out,key=lambda x:(x[1],x[0]))

    def affordances(self, agent_id: str) -> List[Dict[str, Any]]:
        m=self.require_agent(agent_id); aff=[{"action":"WAIT","target":None,"cost":0,"benefit":20,"risk":0,"confidence":100}]
        wolves=self._visible_targets(m,"wolf"); merchants=self._visible_targets(m,"merchant")
        if wolves:
            aff.append({"action":"MOVE_AWAY","target":wolves[0][0],"cost":15,"benefit":95,"risk":20,"confidence":90})
        if merchants:
            aff.append({"action":"MOVE_TOWARD","target":merchants[0][0],"cost":10,"benefit":55,"risk":10,"confidence":85})
        if m["coherence"]["debt"] or m["metacognition"]["uncertainty_burden"]>30:
            aff.append({"action":"SEEK_INFO","target":None,"cost":8,"benefit":60,"risk":5,"confidence":75})
        aff.append({"action":"OBSERVE","target":None,"cost":3,"benefit":35,"risk":0,"confidence":95})
        return aff

    def deliberate(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); goal=m["goals"][0] if m["goals"] else {"kind":"maintain"}
        opts=[]
        for aff in self.affordances(agent_id):
            meaning_alignment=self._care_alignment_for_action(m,aff["action"])
            score=aff["benefit"]-aff["cost"]-aff["risk"]+meaning_alignment["bonus"]
            if goal["kind"]=="avoid_threat" and aff["action"]=="MOVE_AWAY": score+=80
            if goal["kind"]=="seek_food" and aff["action"]=="MOVE_TOWARD": score+=40
            if goal["kind"]=="seek_information" and aff["action"] in {"SEEK_INFO","OBSERVE"}: score+=55
            opts.append({**aff,"score":score,"meaning_alignment":meaning_alignment,"counterfactual":{"type":"COUNTERFACTUAL","expected":"improve-goal-state","confidence":aff["confidence"],"world_tick":self.world.tick}})
        opts=sorted(opts,key=lambda x:(-x["score"],x["action"],str(x.get("target"))))[:PROFILES[m["profile"]]["deliberation"]]
        m["deliberation"]={"options":opts,"resource_budget":PROFILES[m["profile"]]["deliberation"],"counterfactuals":[o["counterfactual"] for o in opts]}
        self._event("DELIBERATION", {"options":len(opts),"digest":sha256_obj(opts)}, agent=str(agent_id)); return copy.deepcopy(m["deliberation"])

    def decide(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); opts=m["deliberation"]["options"] or [{"action":"WAIT","target":None,"score":0,"confidence":100}]
        choice=sorted(opts,key=lambda x:(-x["score"],x["action"],str(x.get("target"))))[0]
        reasons=[f"goal:{m['goals'][0]['kind'] if m['goals'] else 'maintain'}",f"expected_score:{choice['score']}"]
        for domain in choice.get("meaning_alignment",{}).get("domains",[]): reasons.append(f"care:{domain}")
        decision={"action":choice["action"],"target":choice.get("target"),"score":choice["score"],"confidence":clamp(choice.get("confidence",50)),"reasons":reasons,"type":"DECISION"}
        m["decision"]=decision
        m["agency"]["intention"]={"action":decision["action"],"target":decision["target"],"reasons":reasons,"confidence":decision["confidence"],"world_tick":self.world.tick}
        m["agency"]["commitment"]={"status":"COMMITTED","revocation":"precondition-change-or-higher-priority","strength":clamp(decision["confidence"])}
        m["agency"]["plan"]={"steps":[decision["action"]],"target":decision["target"],"horizon":"H0_IMMEDIATE"}
        self._event("DECISION", decision, agent=str(agent_id)); return copy.deepcopy(decision)

    # ---------------- WORLD action transaction ----------------
    def _move_agent_via_world(self, aid: str, new_pos: List[int], action: str, target: Optional[str]) -> Dict[str, Any]:
        old=list(self.world.entities[aid]["pos"]); new=[int(x) for x in new_pos]
        if aid == str(getattr(self.world,"reference_entity","1")):
            self.world.move_reference(new[0],new[1],new[2])
        elif hasattr(self.world,"event_with_state") and hasattr(self.world,"capability_mutate"):
            def mutator():
                self.world.capability_mutate(aid,"AI",lambda ent: ent.__setitem__("pos",list(new)))
            self.world.event_with_state("MIND_ACTION",aid,f"mind:{action}:target={target}",mutator=mutator)
        else:
            raise MindError("WORLD lacks an authority-safe agent movement service")
        return {"status":"SUCCESS","action":action,"target":target,"before":old,"after":list(self.world.entities[aid]["pos"]),"world_tick":self.world.tick,"world_digest":self.world.state_digest()}

    def act(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); d=m["decision"]; action=d["action"]; target=d.get("target")
        pre_world=self.world.state_digest(); result: Dict[str,Any]
        m["agency"]["attempt"]={"action":action,"target":target,"pre_world_digest":pre_world,"world_tick":self.world.tick}
        try:
            if action in {"WAIT","OBSERVE","SEEK_INFO"}:
                result={"status":"NOOP_SUCCESS","action":action,"target":target,"before":list(self.world.entities[aid]["pos"]),"after":list(self.world.entities[aid]["pos"]),"world_tick":self.world.tick,"world_digest":self.world.state_digest()}
                if action=="SEEK_INFO":
                    m["metacognition"]["uncertainty_burden"]=max(0,m["metacognition"]["uncertainty_burden"]-5)
            elif action in {"MOVE_AWAY","MOVE_TOWARD"}:
                if target is None or str(target) not in self.world.entities:
                    result={"status":"FAILED_PRECONDITION","action":action,"target":target,"world_tick":self.world.tick,"world_digest":self.world.state_digest()}
                else:
                    src=list(self.world.entities[aid]["pos"]); dst=list(self.world.entities[str(target)]["pos"])
                    result=self._move_agent_via_world(aid,step_toward(src,dst,step=50,away=(action=="MOVE_AWAY")),action,str(target))
            else:
                result={"status":"REJECTED_UNKNOWN_ACTION","action":action,"target":target,"world_tick":self.world.tick,"world_digest":self.world.state_digest()}
        except Exception as exc:
            result={"status":"WORLD_REJECTED","action":action,"target":target,"error":str(exc),"world_tick":self.world.tick,"world_digest":self.world.state_digest()}
        m["agency"]["world_result"]=copy.deepcopy(result)
        self._event("ACTION_WORLD_RESULT", result, agent=aid)
        return copy.deepcopy(result)

    def learn(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); result=m["agency"].get("world_result") or {"status":"UNKNOWN"}
        predicted=max([o.get("score",0) for o in m["deliberation"].get("options",[])],default=0)
        actual=80 if result.get("status") in {"SUCCESS","NOOP_SUCCESS"} else 10
        pe=int(actual-predicted)
        m["learning"]["prediction_error"]=pe; m["learning"]["updates"]+=1
        action=m["decision"].get("action","WAIT")
        stat=m["learning"]["strategy_success"].setdefault(action,{"success":0,"failure":0})
        if result.get("status") in {"SUCCESS","NOOP_SUCCESS"}: stat["success"]+=1
        else: stat["failure"]+=1
        m["learning"]["calibration"]=clamp(m["learning"]["calibration"] + (1 if abs(pe)<30 else -1))
        m["metacognition"]["confidence"]=m["learning"]["calibration"]
        m["learning"]["last_agency_outcome"]={"status":result.get("status"),"action":action,"world_tick":result.get("world_tick",self.world.tick)}
        meaning_rep=self.meaning_integrate(agent_id)
        m["learning"]["meaning_integration"]={"dimensions":meaning_rep["dimensions"],"meaning_debt":meaning_rep["meaning_debt"]}
        self._event("LEARNING", {"prediction_error":pe,"updates":m["learning"]["updates"],"action":action,"result":result.get("status"),"meaning_dimensions":meaning_rep["dimensions"]}, agent=str(agent_id))
        return copy.deepcopy(m["learning"])

    # ---------------- meaning / care / narrative / commitment ----------------
    def _care_alignment_for_action(self, m: Dict[str, Any], action: str) -> Dict[str, Any]:
        care=m["meaning"]["care_map"]
        domains=[]
        if action=="MOVE_AWAY": domains=["survival"]
        elif action in {"SEEK_INFO","OBSERVE"}: domains=["inquiry","autonomy"]
        elif action=="MOVE_TOWARD": domains=["relationships","mastery"]
        elif action=="WAIT": domains=["survival"]
        vals=[int(care[d]) for d in domains if d in care]
        bonus=0 if not vals else int(round((sum(vals)/len(vals)-50)/5))
        return {"domains":domains,"bonus":max(-10,min(10,bonus)),"evidence":"care-map/action-practice"}

    def create_commitment(self, agent_id: str, kind: str, object_ref: str, reason: str, *, strength: int=70, horizon: str="H3_STRATEGIC", source: str="self-endorsed") -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        allowed={"promise","relationship","role","project","value","inquiry","stewardship","self_commitment"}
        if kind not in allowed: raise MindError("unsupported commitment kind")
        rec={"commitment_id":f"CM{named_u64(self.seed,aid,kind,object_ref,self.world.tick,len(m['meaning']['commitments']))%100000000:08d}","kind":kind,"object":str(object_ref),"reason":str(reason),"strength":clamp(strength),"horizon":horizon,"source":source,"created_tick":self.world.tick,"status":"ACTIVE","provenance":{"agent":aid,"world_tick":self.world.tick,"type":"AGENT_COMMITMENT"}}
        m["meaning"]["commitments"].append(rec); m["meaning"]["commitments"]=m["meaning"]["commitments"][-64:]
        self._publish_workspace(m,"COMMITMENT",rec,salience=rec["strength"],urgency=max(0,rec["strength"]-30),confidence=90,semantic_context="commitment-practice")
        self._event("MEANING_COMMITMENT",rec,agent=aid); return copy.deepcopy(rec)

    def commit_active_goal(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); goal=m["goals"][0] if m["goals"] else self.goal_select(agent_id)
        existing=[c for c in m["meaning"]["commitments"] if c.get("status")=="ACTIVE" and c.get("object")==goal["goal_id"]]
        if existing: return copy.deepcopy(existing[0])
        return self.create_commitment(agent_id,"project",goal["goal_id"],f"endorsed goal:{goal['kind']}",strength=clamp(goal.get("priority",60)),horizon=goal.get("horizon","H1_SHORT"),source="goal-endorsement")

    def evaluate_significance(self, agent_id: str, event: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        if event is None:
            event=m["memory"]["episodes"][-1] if m["memory"]["episodes"] else {"memory_id":"none","content":{},"emotional_intensity":0}
        emo=int(event.get("emotional_intensity",0)); goal_rel=40 if m["goals"] else 0
        social_rel=0
        content=event.get("content",{})
        for it in content.get("attention",[]) if isinstance(content,dict) else []:
            if it.get("kind") in {"agent","merchant","sheriff"}: social_rel=max(social_rel,40)
        value_rel=max(m["meaning"]["care_map"].values(), default=50)//2
        novelty=20 if event.get("world_tick")==self.world.tick else 5
        score=clamp(int(round(0.30*emo+0.25*goal_rel+0.20*social_rel+0.15*value_rel+0.10*novelty)))
        domains=[]
        if emo>60: domains.append("felt-importance")
        if goal_rel: domains.append("project-relevance")
        if social_rel: domains.append("relationship-relevance")
        rec={"significance_id":f"SG{named_u64(self.seed,aid,event.get('memory_id'),self.world.tick)%100000000:08d}","event_ref":event.get("memory_id"),"score":score,"domains":domains or ["ordinary-continuity"],"agent_relative":True,"world_truth_claim":False,"world_tick":self.world.tick}
        m["meaning"]["significance"].append(rec); m["meaning"]["significance"]=m["meaning"]["significance"][-128:]
        if score>=55 and event.get("memory_id"):
            anchor={"kind":"meaningful_event","world_tick":event.get("world_tick",self.world.tick),"memory_id":event.get("memory_id"),"significance":score,"domains":domains}
            if anchor not in m["self_model"]["narrative_anchors"]: m["self_model"]["narrative_anchors"].append(anchor)
        return copy.deepcopy(rec)

    def narrative_update(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); meaning=m["meaning"]
        active=[c for c in meaning["commitments"] if c.get("status")=="ACTIVE"]
        goal=m["goals"][0] if m["goals"] else None
        latest=meaning["significance"][-1] if meaning["significance"] else None
        role=m["self_model"].get("active_role","self")
        theme=(active[0]["kind"] if active else (goal["kind"] if goal else "orientation"))
        chapter={"chapter_id":f"N{named_u64(self.seed,aid,m['cycle'],theme)%100000000:08d}","world_tick":self.world.tick,"role":role,"theme":theme,"goal_ref":goal.get("goal_id") if goal else None,"commitment_refs":[c["commitment_id"] for c in active[:4]],"significance_ref":latest.get("significance_id") if latest else None,"provenance":"agent-narrative-construction"}
        chapters=meaning["narrative"]["chapters"]
        if not chapters or chapters[-1].get("theme")!=theme or chapters[-1].get("role")!=role:
            chapters.append(chapter); del chapters[:-64]
        continuity=clamp(40+min(30,len(m["self_model"]["narrative_anchors"])*5)+min(20,len(active)*4)-min(30,len(meaning["meaning_debt"])*5))
        meaning["narrative"].update({"continuity":continuity,"current_theme":theme,"open_tensions":[d["debt_id"] for d in meaning["meaning_debt"] if d.get("status")=="OPEN"][:16]})
        self._event("MEANING_NARRATIVE",{"theme":theme,"continuity":continuity,"chapters":len(chapters)},agent=aid)
        return copy.deepcopy(meaning["narrative"])

    def register_symbol(self, agent_id: str, token: str, practice_context: str, association: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        key=f"{practice_context}:{token}"
        rec=m["meaning"]["symbols"].setdefault(key,{"token":str(token),"practice_context":str(practice_context),"uses":[],"associations":[],"public_or_private":"agent-learned-use","universal_essence":False})
        use={"world_tick":self.world.tick,"association":str(association),"language_game":practice_context}
        rec["uses"].append(use); rec["uses"]=rec["uses"][-32:]
        if association not in rec["associations"]: rec["associations"].append(str(association))
        self._event("MEANING_SYMBOL_USE",{"key":key,"association":association},agent=aid); return copy.deepcopy(rec)

    def create_life_project(self, agent_id: str, title: str, purpose: str, *, care_domains: Optional[List[str]]=None, horizon: str="H4_DEVELOPMENTAL") -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); care_domains=list(care_domains or [])
        valid=[d for d in care_domains if d in m["meaning"]["care_map"]]
        rec={"project_id":f"LP{named_u64(self.seed,aid,title,purpose,len(m['meaning']['life_projects']))%100000000:08d}","title":str(title),"purpose":str(purpose),"care_domains":valid,"horizon":horizon,"status":"ACTIVE","created_tick":self.world.tick,"progress":0,"provenance":"agent-project-construction"}
        m["meaning"]["life_projects"].append(rec); m["meaning"]["life_projects"]=m["meaning"]["life_projects"][-32:]
        self.create_commitment(agent_id,"project",rec["project_id"],purpose,strength=70,horizon=horizon,source="life-project")
        return copy.deepcopy(rec)

    def reflective_equilibrium(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); meaning=m["meaning"]; tensions=[]; proposals=[]
        active_goal=m["goals"][0] if m["goals"] else None
        duty=int(meaning["care_map"].get("duty",50)); survival=int(meaning["care_map"].get("survival",50))
        if active_goal and active_goal.get("kind")=="avoid_threat" and duty>=75:
            tensions.append({"type":"CARE_CONFLICT","between":["survival","duty"],"goal":active_goal["goal_id"]})
            proposals.append({"type":"DELIBERATION_REVIEW","instruction":"preserve safety while checking outstanding duty commitments"})
        for c in meaning["commitments"]:
            if c.get("status")=="ACTIVE" and c.get("strength",0)>=80 and c.get("object") not in [g.get("goal_id") for g in m["goals"] if g.get("status")=="ACTIVE"]:
                tensions.append({"type":"COMMITMENT_GOAL_GAP","commitment":c["commitment_id"]})
                proposals.append({"type":"GOAL_REVIEW","commitment":c["commitment_id"]})
        alignment=clamp(80-len(tensions)*12-len(meaning["meaning_debt"])*6)
        eq={"alignment":alignment,"tensions":tensions,"revision_proposals":proposals,"last_review_tick":self.world.tick,"automatic_value_rewrite":False}
        meaning["reflective_equilibrium"]=eq
        return copy.deepcopy(eq)

    def meaning_integrate(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); meaning=m["meaning"]
        sig=self.evaluate_significance(aid)
        narrative=self.narrative_update(aid)
        eq=self.reflective_equilibrium(aid)
        result=m["agency"].get("world_result") or {}
        active_commitments=[c for c in meaning["commitments"] if c.get("status")=="ACTIVE"]
        if result.get("status") not in {None,"SUCCESS","NOOP_SUCCESS"} and active_commitments:
            key=f"action-failure:{m['cycle']}:{active_commitments[0]['commitment_id']}"
            if not any(d.get("key")==key for d in meaning["meaning_debt"]):
                meaning["meaning_debt"].append({"debt_id":f"MD{named_u64(self.seed,aid,key)%100000000:08d}","key":key,"type":"COMMITMENT_EXECUTION_GAP","commitment":active_commitments[0]["commitment_id"],"status":"OPEN","world_tick":self.world.tick,"repair_options":["replan","revise commitment","seek help","accept limitation"]})
        rels=m.get("relationships",{})
        trust=[]
        for r in rels.values():
            if isinstance(r,dict) and isinstance(r.get("trust"),int): trust.append(r["trust"])
        belonging=clamp(sum(trust)//len(trust) if trust else m["motivation"]["needs"].get("belonging",40))
        purpose=clamp(30+min(40,len(active_commitments)*10)+min(25,len([p for p in meaning["life_projects"] if p.get("status")=="ACTIVE"])*12))
        coherence=clamp(100-len(m["coherence"]["debt"])*8-len(meaning["meaning_debt"])*8)
        agency=clamp(m["self_model"].get("self_efficacy",50))
        continuity=clamp(narrative["continuity"])
        value_alignment=clamp(eq["alignment"])
        meaning["dimensions"]={"coherence":coherence,"purpose":purpose,"belonging":belonging,"agency":agency,"continuity":continuity,"value_alignment":value_alignment}
        meaning["last_integration_tick"]=self.world.tick
        sacred=self.cakra.integrate(aid)
        rep={"dimensions":copy.deepcopy(meaning["dimensions"]),"significance":sig,"narrative_theme":narrative["current_theme"],"active_commitments":len(active_commitments),"active_projects":len([p for p in meaning["life_projects"] if p.get("status")=="ACTIVE"]),"meaning_debt":len([d for d in meaning["meaning_debt"] if d.get("status")=="OPEN"]),"plural_not_global_scalar":True,"world_truth_claim":False,"sacred_integration":sacred}
        self._event("MEANING_INTEGRATION",rep,agent=aid); return rep

    def meaning_snapshot(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); return {"agent":str(agent_id),"care_map":copy.deepcopy(m["meaning"]["care_map"]),"dimensions":copy.deepcopy(m["meaning"]["dimensions"]),"commitments":copy.deepcopy(m["meaning"]["commitments"]),"narrative":copy.deepcopy(m["meaning"]["narrative"]),"symbols":copy.deepcopy(m["meaning"]["symbols"]),"life_projects":copy.deepcopy(m["meaning"]["life_projects"]),"meaning_debt":copy.deepcopy(m["meaning"]["meaning_debt"]),"reflective_equilibrium":copy.deepcopy(m["meaning"]["reflective_equilibrium"]),"digest":sha256_obj(m["meaning"]),"world_truth_claim":False}

    # ---------------- twelve-cakra / sacred cognition federation ----------------
    def cakra_federate(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.federate(str(agent_id))

    def cakra_node_step(self, agent_id: str, node_id: str) -> Dict[str, Any]:
        return self.cakra.node_step(str(agent_id), str(node_id))

    def spiritual_ascent(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.ascent(str(agent_id))

    def spiritual_add_ontology_frame(self, agent_id: str, frame: str) -> Dict[str, Any]:
        return self.cakra.add_ontology_frame(str(agent_id), frame)

    def spiritual_hold_mystery(self, agent_id: str, description: str, sacred_weight: int=75) -> Dict[str, Any]:
        return self.cakra.hold_mystery(str(agent_id), description, sacred_weight=sacred_weight)

    def spiritual_session_begin(self, agent_id: str, *, spiritual_mode: str="CONTEMPLATION", intention: str="presence", profile: Optional[str]=None, frame_ref: str="user-defined", consent_ref: str="VOLUNTARY_SESSION") -> Dict[str, Any]:
        return self.cakra.begin_session(str(agent_id), spiritual_mode=spiritual_mode, intention=intention, profile=profile, frame_ref=frame_ref, consent_ref=consent_ref)

    def spiritual_session_end(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.end_session(str(agent_id))

    def spiritual_profile_set(self, agent_id: str, profile: str) -> Dict[str, Any]:
        return self.cakra.set_profile(str(agent_id), profile)

    def spiritual_receive(self, agent_id: str, *, arrival_mode: str="INTUITION", content: str="received insight", felt_source: str="UNKNOWN", conviction: int=80, mystical_intensity: int=75, importance: int=75, lineage_ref: Optional[str]=None) -> Dict[str, Any]:
        return self.cakra.record_insight(str(agent_id), arrival_mode=arrival_mode, content=content, felt_source=felt_source, conviction=conviction, mystical_intensity=mystical_intensity, importance=importance, lineage_ref=lineage_ref)

    def spiritual_synchronicity(self, agent_id: str, event_a: str, event_b: str, *, proposed_meaning: str="meaningful coincidence", salience: int=75, recurrence: int=1) -> Dict[str, Any]:
        return self.cakra.record_synchronicity(str(agent_id), event_a, event_b, proposed_meaning=proposed_meaning, salience=salience, recurrence=recurrence)

    def sacred_integrate(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.integrate(str(agent_id))

    def sacred_confidence(self, agent_id: str) -> Dict[str, int]:
        self.cakra.federate(str(agent_id))
        return copy.deepcopy(self.require_agent(str(agent_id))["cakra"]["sacred_confidence"])

    def spiritual_return_to_world(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.return_to_world(str(agent_id))

    def spiritual_externalize(self, agent_id: str, proposition: str, *, objective: bool=False, consequence: str="LOW", independently_supported: bool=False) -> Dict[str, Any]:
        return self.cakra.externalize(str(agent_id), proposition, objective=objective, consequence=consequence, independently_supported=independently_supported)

    def sacred_mind_commit(self, agent_id: str, proposal_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.cakra.mind_commit(str(agent_id), proposal_type, payload)

    def cakra_snapshot(self, agent_id: str) -> Dict[str, Any]:
        return self.cakra.snapshot(str(agent_id))

    # ---------------- social / metacognitive / remediation ----------------
    def social_model(self, agent_id: str, target_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); tid=str(target_id)
        if tid not in self.world.entities:
            raise MindError("unknown social target")
        key=tid
        if key not in m["theory_of_mind"]:
            visible=any(str(it.get("subject"))==tid for it in m["perception"].get("items",[]))
            m["theory_of_mind"][key]={"target":tid,"believed_goals":[],"believed_emotion":"unknown","trust":50,"uncertainty":40 if visible else 80,"source":"inference","private_state_access":False}
        return copy.deepcopy(m["theory_of_mind"][key])

    def projection_check(self, agent_id: str, target_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); sm=self.social_model(agent_id,target_id)
        flags=[]
        if sm.get("believed_goals") == [g.get("kind") for g in m.get("goals",[]) if g.get("status")=="ACTIVE"] and sm.get("believed_goals"):
            flags.append("POSSIBLE_GOAL_PROJECTION")
        return {"flags":flags,"confidence_adjustment":-10 if flags else 0}

    def remediate(self, gate: str, root_cause: str, candidate: str) -> Dict[str, Any]:
        immutable={"WORLD_SOVEREIGNTY","EPISTEMIC_LOCALITY","COUNTERFACTUAL_SEPARATION","AGENT_ISOLATION","REPLAY_ACCOUNTABILITY"}
        if gate in immutable and candidate.startswith("weaken-"):
            rep={"status":"REJECTED","reason":"immutable gate cannot be weakened","gate":gate,"root_cause":root_cause}
        else:
            rep={"status":"SANDBOXED","gate":gate,"root_cause":root_cause,"candidate":candidate,"rollback":True,"promoted":False}
        self.remediation_log.append(copy.deepcopy(rep)); self._event("REMEDIATION",rep)
        return rep

    # ---------------- embodied / tools / practice / institutions / LOD ----------------
    def embodied_state(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); ent=self.world.entities[aid]
        rep={"agent":aid,"health":int(ent.get("health",100)),"energy":int(m["motivation"]["needs"].get("energy",50)),"hunger":int(m["motivation"]["needs"].get("hunger",0)),"source":"agent-local-body-interface","type":"INTEROCEPTIVE_STATE"}
        return rep

    def read_external_artifact(self, agent_id: str, artifact: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); artifact=str(artifact)
        if artifact=="semantic_graph":
            value=copy.deepcopy(getattr(self.world,"semantic_graph",{})); public=True
        elif artifact.startswith("institution:"):
            iid=artifact.split(":",1)[1]
            inst=getattr(self.world,"institutions",{}).get(iid)
            if inst is None: raise MindError("external artifact not found")
            # hosted reference treats institution records as public only to agents in-region
            public=str(self.world.entities[aid].get("region"))==str(inst.get("region"))
            if not public: raise MindError("external artifact not lawfully accessible")
            value=copy.deepcopy(inst)
        else:
            raise MindError("external artifact not found")
        rec={"type":"EXTERNAL_RECORD","artifact":artifact,"value":value,"world_tick":self.world.tick,"confidence":80,"provenance":"WORLD_PUBLIC_ARTIFACT"}
        m["memory"]["semantic_use"][f"artifact:{artifact}"]=copy.deepcopy(rec)
        self._event("EXTERNAL_COGNITION_READ",{"artifact":artifact,"digest":sha256_obj(value)},agent=aid)
        return rec

    def learn_language_game(self, agent_id: str, game_id: str, *, examples: Optional[List[str]]=None, criteria: Optional[List[str]]=None) -> Dict[str, Any]:
        m=self.require_agent(agent_id)
        if not PROFILES[m["profile"]]["semantic"]: raise MindError("profile has no human semantic language-game runtime")
        gid=str(game_id); games=m["semantic"]["language_games"]
        game=games.setdefault(gid,{"language_game_id":gid,"examples":[],"criteria":[],"corrections":[],"successful_uses":0,"failed_uses":0,"novel_transfer":0,"competence":20})
        for x in examples or []:
            if x not in game["examples"]: game["examples"].append(str(x))
        for x in criteria or []:
            if x not in game["criteria"]: game["criteria"].append(str(x))
        game["competence"]=clamp(20+5*len(game["examples"])+5*len(game["criteria"]))
        self._event("LANGUAGE_GAME_LEARN",{"game":gid,"competence":game["competence"]},agent=str(agent_id)); return copy.deepcopy(game)

    def practice_language_game(self, agent_id: str, game_id: str, *, success: bool, novel: bool=False, correction: Optional[str]=None) -> Dict[str, Any]:
        m=self.require_agent(agent_id); gid=str(game_id)
        if gid not in m["semantic"]["language_games"]: raise MindError("unknown language game")
        g=m["semantic"]["language_games"][gid]
        g["successful_uses" if success else "failed_uses"]+=1
        if novel and success: g["novel_transfer"]+=1
        if correction: g["corrections"].append(str(correction))
        g["competence"]=clamp(g["competence"]+(4 if success else -3)+(4 if novel and success else 0))
        self._event("LANGUAGE_GAME_PRACTICE",{"game":gid,"success":bool(success),"novel":bool(novel),"competence":g["competence"]},agent=str(agent_id)); return copy.deepcopy(g)

    def aspect_shift(self, agent_id: str, evidence_digest: str, before: str, after: str, trigger: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id)
        rec={"type":"ASPECT_SHIFT","evidence_digest":str(evidence_digest),"aspect_before":str(before),"aspect_after":str(after),"trigger":str(trigger),"world_tick":self.world.tick,"evidence_rewritten":False}
        m["semantic"]["aspect_frame"]=copy.deepcopy(rec); self._event("ASPECT_SHIFT",rec,agent=str(agent_id)); return rec

    def reasons_vs_causes(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id)
        return {"agent_reasons":copy.deepcopy(m["decision"].get("reasons",[])),"runtime_causes":["active_goal","attended_evidence","appraisal","motivation","deliberation_score"],"collapsed":False,"language_game":"reason-giving"}

    def practical_reason_matrix(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); ent=self.world.entities[aid]
        rows=[]
        rows.append({"source":"preference","claim":m["motivation"]["top"],"authority":30,"personal_endorsement":70})
        for k,v in m["self_model"].get("values",{}).items(): rows.append({"source":"personal_value","claim":k,"authority":int(v),"personal_endorsement":int(v)})
        for role in m["self_model"].get("roles",[]): rows.append({"source":"role_obligation","claim":role,"authority":70,"personal_endorsement":50})
        for iid,inst in getattr(self.world,"institutions",{}).items():
            if str(inst.get("region"))==str(ent.get("region")): rows.append({"source":"institution_rule","claim":iid,"authority":int(inst.get("legitimacy",50)),"personal_endorsement":50})
        return {"rows":rows,"collapsed_to_global_scalar":False,"conflicts_possible":len({r['source'] for r in rows})>1}

    def dialogue_act(self, agent_id: str, target_id: str, act: str, content: str, *, language_game: str="ordinary-dialogue") -> Dict[str, Any]:
        m=self.require_agent(agent_id); self.social_model(agent_id,target_id)
        allowed={"assert","ask","request","command","promise","warn","offer","refuse","concede","correct","teach","joke","accuse","apologize","negotiate","testify","challenge","clarify"}
        if act not in allowed: raise MindError("unsupported dialogue act")
        rec={"type":"DIALOGUE_ACT","speaker":str(agent_id),"target":str(target_id),"act":act,"content":str(content),"language_game":language_game,"world_tick":self.world.tick,"private_state_access":False}
        m["relationships"].setdefault(str(target_id),{}).setdefault("dialogue",[]).append(copy.deepcopy(rec))
        self._event("DIALOGUE_ACT",rec,agent=str(agent_id)); return rec

    def institution_model(self, agent_id: str, institution_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); iid=str(institution_id)
        inst=getattr(self.world,"institutions",{}).get(iid)
        if inst is None: raise MindError("unknown institution")
        local=str(self.world.entities[aid].get("region"))==str(inst.get("region"))
        confidence=80 if local else 30
        model={"institution":iid,"believed_kind":inst.get("kind","unknown") if local else "unknown","believed_legitimacy":int(inst.get("legitimacy",50)) if local else 50,"confidence":confidence,"source":"local-public-practice" if local else "limited-inference","canonical_private_access":False}
        m["beliefs"][f"institution:{iid}"]={"type":"BELIEF","subject":iid,"predicate":"institution_model","value":copy.deepcopy(model),"confidence":confidence,"source":model["source"],"provenance":{"world_tick":self.world.tick},"semantic_context":"institution-practice","contradiction":False,"last_updated":self.world.tick}
        return model

    def transition_profile(self, agent_id: str, target_profile: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id)
        if target_profile not in PROFILES: raise MindError("unknown profile")
        old=m["profile"]; anchors=copy.deepcopy(m["self_model"]["narrative_anchors"]); active_goals=[copy.deepcopy(g) for g in m["goals"] if g.get("status")=="ACTIVE"]
        m["profile"]=target_profile; m["attention"]["budget"]=PROFILES[target_profile]["attention"]
        limit=PROFILES[target_profile]["memory"]
        if len(m["memory"]["episodes"])>limit:
            removed=m["memory"]["episodes"][:-limit]; m["memory"]["summaries"].append({"type":"COMPRESSED","count":len(removed),"digest":sha256_obj(removed),"provenance":"PROFILE_TRANSITION"}); m["memory"]["episodes"]=m["memory"]["episodes"][-limit:]
        rec={"from":old,"to":target_profile,"identity_preserved":m["agent_id"]==aid,"anchors_preserved":anchors==m["self_model"]["narrative_anchors"],"active_goal_ids":[g["goal_id"] for g in active_goals],"provenance":"EXACT_PROFILE_CHANGE_WITH_COMPRESSED_MEMORY_IF_REQUIRED"}
        self._event("MIND_PROFILE_TRANSITION",rec,agent=aid); return rec

    def long_horizon_probe(self, agent_id: str, cycles: int=32) -> Dict[str, Any]:
        cycles=max(1,min(128,int(cycles))); aid=str(agent_id)
        start=self.agent_digest(aid)
        for _ in range(cycles): self.cycle(aid)
        m=self.require_agent(aid); limit=PROFILES[m["profile"]]["memory"]
        return {"cycles":cycles,"start_digest":start,"end_digest":self.agent_digest(aid),"memory_bounded":len(m["memory"]["episodes"])<=limit,"workspace_bounded":len(m["workspace"]["active"])<=24,"invariants":self.invariants(aid)}

    # ---------------- cycle / snapshots ----------------
    def cycle(self, agent_id: str) -> Dict[str, Any]:
        m=self.require_agent(agent_id); aid=str(agent_id); self.causal_epoch+=1; m["causal_epoch"]=self.causal_epoch; m["cycle"]+=1
        trace=[]
        trace.append({"node":"WORLD","world_digest":self.world.state_digest(),"world_tick":self.world.tick})
        trace.append({"node":"PERCEPTION","result":self.perceive(aid)})
        trace.append({"node":"ATTENTION","result":self.attend(aid)})
        trace.append({"node":"BELIEF","result":self.update_beliefs(aid)})
        trace.append({"node":"APPRAISAL","result":self.appraise(aid)})
        trace.append({"node":"EMOTION","result":self.affect_step(aid)})
        trace.append({"node":"MOTIVATION","result":self.motivation_step(aid)})
        trace.append({"node":"MEMORY","result":self.memory_step(aid)})
        trace.append({"node":"SELF","result":self.self_step(aid)})
        trace.append({"node":"GOALS","result":self.goal_select(aid)})
        trace.append({"node":"DELIBERATION","result":self.deliberate(aid)})
        trace.append({"node":"DECISION","result":self.decide(aid)})
        trace.append({"node":"ACTION","result":copy.deepcopy(m["agency"]["attempt"])})
        wr=self.act(aid); trace.append({"node":"WORLD_RESULT","result":wr})
        lr=self.learn(aid); trace.append({"node":"LEARNING","result":lr})
        m["last_trace"]=trace
        self._event("FULL_COGNITIVE_CYCLE", {"trace_digest":sha256_obj(trace),"decision":m["decision"],"world_result":wr.get("status")}, agent=aid)
        return {"agent":aid,"cycle":m["cycle"],"trace":copy.deepcopy(trace),"mind_digest":self.agent_digest(aid),"world_digest":self.world.state_digest()}

    def cycle_all(self) -> Dict[str, Any]:
        self.sync_agents(); results=[]
        for aid in sorted(self.minds,key=lambda x:int(x) if str(x).isdigit() else str(x)):
            if aid in self.world.entities and self.world.entities[aid].get("alive",True): results.append(self.cycle(aid))
        return {"agents":len(results),"results":results,"digest":self.state_digest()}

    def agent_digest(self, agent_id: str) -> str:
        return sha256_obj(self.require_agent(agent_id))

    def snapshot(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        if agent_id is None:
            return {"version":MIND_VERSION,"agents":len(self.minds),"state_digest":self.state_digest(),"ledger_head":self.ledger_head,"ledger_events":len(self.ledger),"invariants":self.invariants()}
        m=self.require_agent(agent_id)
        return {"version":MIND_VERSION,"agent":str(agent_id),"profile":m["profile"],"cycle":m["cycle"],"digest":self.agent_digest(agent_id),"decision":copy.deepcopy(m["decision"]),"goal":copy.deepcopy(m["goals"][0] if m["goals"] else None),"emotion":copy.deepcopy(m["emotion"]),"coherence_debt":len(m["coherence"]["debt"]),"meaning_dimensions":copy.deepcopy(m["meaning"]["dimensions"]),"meaning_debt":len(m["meaning"]["meaning_debt"]),"meaning_digest":sha256_obj(m["meaning"]),"cakra_profile":m["cakra"]["openness_profile"],"cakra_digest":sha256_obj(m["cakra"]),"spiritual_session_active":bool(m["cakra"].get("active_session")),"invariants":self.invariants(str(agent_id))}

    def invariants(self, agent_id: Optional[str] = None) -> List[str]:
        errors=[]
        if not self.verify_ledger(): errors.append("mind ledger integrity")
        ids=[str(agent_id)] if agent_id is not None else list(self.minds)
        for aid in ids:
            if aid not in self.minds: errors.append(f"missing mind {aid}"); continue
            m=self.minds[aid]
            if aid not in self.world.entities: errors.append(f"mind {aid} lacks world entity")
            if m.get("agent_id")!=aid: errors.append(f"mind identity mismatch {aid}")
            if m.get("profile") not in PROFILES: errors.append(f"bad profile {aid}")
            for mem in m.get("memory",{}).get("episodes",[]):
                if mem.get("type")=="MEMORY_EXPERIENCED":
                    content=mem.get("content",{})
                    if content.get("type")=="COUNTERFACTUAL": errors.append(f"counterfactual contamination {aid}")
            for tid,sm in m.get("theory_of_mind",{}).items():
                if sm.get("private_state_access"): errors.append(f"private-state leak {aid}->{tid}")
            if m.get("attention",{}).get("budget",0) > 16: errors.append(f"attention budget {aid}")
            if len(m.get("workspace",{}).get("active",[])) > 24: errors.append(f"workspace bound {aid}")
            self._ensure_meaning_state(m)
            for c in m["meaning"].get("commitments",[]):
                if c.get("strength",0)<0 or c.get("strength",0)>100: errors.append(f"commitment strength {aid}")
                if not c.get("provenance"): errors.append(f"commitment provenance {aid}")
            if m["meaning"].get("plural_not_global_scalar") is True: errors.append(f"invalid meaning schema {aid}")
            for s in m["meaning"].get("significance",[]):
                if s.get("world_truth_claim") is not False: errors.append(f"significance world-truth confusion {aid}")
            if len(m["meaning"].get("narrative",{}).get("chapters",[]))>64: errors.append(f"narrative bound {aid}")
            if len(m["meaning"].get("commitments",[]))>64: errors.append(f"commitment bound {aid}")
            for ce in self.cakra.invariants(aid):
                errors.append(f"{ce} {aid}")
        return errors

    def qualification_summary(self) -> Dict[str, Any]:
        return {
            "product":"MindMachine","mind_version":MIND_VERSION,"profile":"HOSTED_REFERENCE",
            "world_version":getattr(self.world,"WORLD_VERSION",None) or getattr(self.world,"version",None),
            "agents":len(self.minds),"mind_digest":self.state_digest(),"world_digest":self.world.state_digest(),
            "invariant_errors":self.invariants(),"ledger_ok":self.verify_ledger(),"meaning_architecture":"plural care/commitment/significance/narrative/symbol/practice/life-project model + twelve-cakra sacred-cognition federation","cakra_integration":"12-node SCIP/1.1 + CSE/1.1 Mystical Openness","claim_boundary":"hosted reference cognitive, meaning-centered, and spiritual-model simulation; not consciousness, sentience, clinical validation, or objective meaning-of-life authority; operative sacred truths remain Mind-local unless separately externalized",
        }
