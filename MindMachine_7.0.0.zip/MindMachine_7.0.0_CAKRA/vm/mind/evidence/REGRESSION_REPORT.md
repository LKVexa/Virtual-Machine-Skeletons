# MindMachine 7.0.0 Regression Report

Fresh focused regression evidence:

- QVM core tests: **20/20 PASS**
- RC-PW WORLD runtime tests: **25/25 PASS**
- RC-PW WORLD remediation tests: **15/15 PASS**
- MindMachine cognitive + meaning runtime tests: **60/60 PASS**
- Total focused automated tests: **120/120 PASS**
- MindMachine 7.0 guest demo: **PASS**

The legacy repository-wide base qualification command was not used as a release blocker in this upgrade because its longer-running phase exceeded the execution window; pre-existing base qualification evidence remains preserved. The 7.0 mind qualification is independently captured in `vm/mind/evidence/QUALIFICATION_REPORT.md`.
