# MindMachine 7.0.0 Mind Runtime — Meaning + Twelve-Cakra Sacred Cognition

## Run
From `vm/`: `make mind-test`, `make mind-demo`, `make mind-cakra-qualify`, or `make mind-qualify`.

## Existing cognition and meaning
The 7.0.0 cognitive loop, agent-local beliefs/memory/self/goals, care map, commitments, significance, narrative, symbolic use, life projects, reflective equilibrium, and meaning debt remain intact.

## Cakra integration
`mind/cakra/cakra_runtime.py` supplies a deterministic twelve-node federation attached to every Mind state. Human-semantic profiles default to the supplied 3.1.0 `MYSTICAL` openness profile; wildlife/cohort profiles default to `GROUNDED`.

The federation supports sacred sessions, experiential authority, received insight, dreams/visions, synchronicity, sacred confidence, operative sacred truths, plural ontology frames, mystery, ascent, sacred integration, return/descent, service proposals, Mind-local commit, replay, and migration.

## ABI
Services 48–63: cognition. 64–71: meaning. 72–86: cakra/spiritual integration. Full contract: `spec/MIND_SERVICE_ABI.md`.

## Qualification
`qualification/qualify_mind.py` runs the 89-test regression/integration suite, invokes the attached 32-gate spiritual qualifier, and produces a combined ledger. `qualification/qualify_cakra.py` can run the spiritual gate series independently.

## Provenance
The supplied integration packages and their extracted prompt/workflow resources are retained under `workflow_application/cakra_sources/`; `CAKRA_3.1.0_APPLICATION_REPORT.md` records what was actually applied.
