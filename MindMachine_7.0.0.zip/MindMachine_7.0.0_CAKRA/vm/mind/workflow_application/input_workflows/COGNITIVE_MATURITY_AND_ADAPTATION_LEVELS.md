# Cognitive Maturity and Adaptation Levels — 4.0.0

These are computational capability levels, not human developmental diagnoses.

- `C0_REACTIVE`: immediate cue-response, minimal memory.
- `C1_ROUTINE`: habits, schedules, simple needs.
- `C2_CONTEXTUAL`: goals, basic belief updating, context-sensitive action.
- `C3_REFLECTIVE`: counterfactual planning, uncertainty, regulation.
- `C4_SOCIAL`: relationships, language-games, bounded theory of mind.
- `C5_INSTITUTIONAL`: roles, norms, conventions, institution participation.
- `C6_METACOGNITIVE`: strategy learning, calibration, reflective review.
- `C7_ADAPTIVE_ECOLOGY`: long-horizon self/social/semantic adaptation with governance.

Agents may have heterogeneous levels by domain. Do not force a single global maturity score.
