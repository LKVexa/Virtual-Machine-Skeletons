# Interoceptive / Embodied State — 5.0.0

## QUORUM 5.0.0 Embodied / Interoceptive State Integration

Where the simulated entity has a body or body-like resource state, integrate internal signals into cognition.

Possible state:
- energy;
- fatigue;
- pain;
- hunger/thirst;
- arousal;
- injury;
- temperature stress;
- sleep pressure;
- motor readiness;
- illness-like functional burden only where explicitly modeled.

Rules:
- internal bodily state is not a synonym for emotion;
- emotion may appraise bodily state;
- bodily state can modulate attention, memory accessibility, effort, risk, and planning depth;
- an agent can misinterpret bodily signals;
- body-state access is limited to what the agent can lawfully sense;
- no clinical diagnosis is inferred merely from simulated internal variables.

For non-biological agents, substitute appropriate resource/homeostatic signals rather than anthropomorphizing.
