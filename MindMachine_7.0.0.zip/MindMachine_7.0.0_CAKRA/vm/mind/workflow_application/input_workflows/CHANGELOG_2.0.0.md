# CHANGELOG — 2.0.0

## Major
- Converted linear workflows to dynamic recurrent workflows.
- Added multi-rate orchestration and event interrupts.
- Added adaptive cognitive modes.
- Added first-class uncertainty, contradiction, counterfactuals, and recovery.
- Promoted later-Wittgenstein concepts into runtime semantics and qualification.
- Added semantic drift, rule-practice learning, family resemblance, aspect-seeing, grammar/empirical boundaries, hinge disturbance, and philosophical-therapy gates.
- Added multi-agent emergence and adaptive psychological LOD.
- Added causal ablation and long-horizon qualification.
- Added cross-stage orchestration and machine-readable evidence requirements.

## Compatibility
The twelve stage identifiers remain 5.1.0–5.12.0. The package version is 2.0.0. Existing 1.0.0 content is preserved conceptually and extended; implementers should rerun all gates after applying the 2.0.0 dynamic layer.
