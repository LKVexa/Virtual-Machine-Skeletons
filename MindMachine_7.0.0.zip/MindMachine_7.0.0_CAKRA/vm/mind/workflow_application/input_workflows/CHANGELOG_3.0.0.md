# CHANGELOG — 3.0.0

## Architecture
- Upgraded recurrent pipeline into adaptive cognitive ecology.
- Added five interacting architecture planes.
- Added multi-timescale state bands.
- Added predictive world-models and active information seeking.
- Added learnable cognitive-strategy arbitration.
- Added cognitive homeostasis and anti-instability safeguards.
- Added causal dependency graphs and state lineage.
- Added multi-agent semantic ecology and community-specific practice evolution.
- Added intervention/ablation qualification.
- Added long-horizon continuity and reproducibility bundles.

## Later-Wittgenstein
- Versioned language-game evolution.
- Dynamic forms-of-life participation.
- Use-history lineage.
- Practice-based rule competence.
- Public-criteria contextual evidence.
- Open-textured family-resemblance categories.
- Controlled aspect-seeing.
- Hinge dependency networks.
- Continuous philosophical-therapy diagnostics.

## Compatibility
The twelve workflow stage identifiers remain 5.1.0–5.12.0. This package version is 3.0.0 and requires full requalification after migration from 2.0.0.
