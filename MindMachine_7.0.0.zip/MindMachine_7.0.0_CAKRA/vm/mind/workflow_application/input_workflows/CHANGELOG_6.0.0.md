# CHANGELOG — 6.0.0

## Major
- Added cognitive workspace/relevance bus.
- Added world-model coherence and reconciliation with explicit coherence debt.
- Added multi-horizon temporal control.
- Added explicit desire→goal→intention→commitment→plan→attempt→result lifecycle.
- Added execution monitoring and differentiated agency failures.
- Hardened self/other boundary and projection detection.
- Added values/norms/roles practical-reason conflict typing.
- Deepened later-Wittgenstein integration around reasons, agreement in practice, semantic repair, translation, and aspect negotiation.
- Added LanguageGameBridge.
- Added affordance/action-opportunity model.
- Added autonomous qualification remediation loop.
- Added scenario compiler and multidimensional coverage engine.
- Added operational impact scorecards.
- Added runtime cognitive profiles.
- Expanded release qualification to 48 gates.
- Added master orchestration prompt, cross-stage contract matrix, release-debt ledger, and new red-team suite.

## Compatibility
The twelve workflow stage identifiers remain 5.1.0–5.12.0. Package version advances to 6.0.0. Every inherited OPERATIONAL claim must be requalified after integration.
