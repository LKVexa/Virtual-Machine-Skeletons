# CHANGELOG — 4.0.0

## Major
- Added cognitive constitution and invariant monitoring.
- Added proposal-based adaptive governance and arbitration.
- Added cognitive transaction journal with rollback/quarantine semantics.
- Added bounded counterfactual/prospective sandbox.
- Added psychological model federation with explicit assumptions and conflicts.
- Added stronger later-Wittgenstein normative practice governance.
- Added institution/norm/common-ground ecology.
- Added proposition type system.
- Added recovery modes and fault-class recovery proofs.
- Added cognitive capability/maturity levels by domain.
- Added red-team scenario catalog.
- Expanded qualification to 24 mandatory evidence gates.

## Compatibility
The twelve stage identifiers remain 5.1.0–5.12.0. Package version advances to 4.0.0. All inherited gates require requalification after migration.
