# Dynamic Information Flow Contract — QUORUM 2.0.0

**Canonical causal spine:** WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING

For each edge A → B define:
- data types;
- authority owner;
- read/write permissions;
- time semantics;
- confidence/uncertainty;
- provenance;
- semantic/practice context;
- persistence;
- LOD behavior;
- retry/failure policy;
- replay encoding;
- causal checksum contribution.

## Universal prohibition

No edge may:
- expose hidden WORLD truth to an agent;
- convert an imagined counterfactual into an observed event;
- convert an agent belief into canonical state;
- convert a grammar/rule declaration into an empirical fact without an explicit WORLD relation;
- silently erase contradictions;
- silently invent semantic context;
- skip ACTION transaction validation.

## Action transaction

`DECISION → ACTION_INTENT → WORLD_PRECONDITION → WORLD_MUTATION_REQUEST → WORLD_COMMIT_RESULT → EXPERIENCE → LEARNING`

WORLD may accept, reject, partially fulfill, transform, delay, or supersede an intent. The mind learns from the committed result available to it.
