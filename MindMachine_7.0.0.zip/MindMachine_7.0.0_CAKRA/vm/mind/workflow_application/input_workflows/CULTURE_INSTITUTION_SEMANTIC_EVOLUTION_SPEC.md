# Culture, Institution, and Semantic Community Evolution — 5.0.0

## QUORUM 5.0.0 Culture, Institution, and Semantic Community Evolution

Represent community-level dynamics through local interaction.

### Community State
Track aggregate or public:
- recurring practices;
- language-game variants;
- role structures;
- institutions;
- public records;
- norm distributions;
- convention prevalence;
- recognized authorities;
- inter-community translation practices.

### Individual Acquisition
Individuals acquire culture through:
- participation;
- observation;
- teaching;
- correction;
- imitation;
- institutional training;
- public artifacts;
- repeated interaction.

Never copy aggregate culture state directly into individual minds without an acquisition path.

### Co-Evolution
Allow:
`individual innovations → local uptake → convention → institutionalization`
and:
`institutional change → altered practice → altered semantic competence → altered individual goals/identity`.

Both directions require explicit causal traces.
