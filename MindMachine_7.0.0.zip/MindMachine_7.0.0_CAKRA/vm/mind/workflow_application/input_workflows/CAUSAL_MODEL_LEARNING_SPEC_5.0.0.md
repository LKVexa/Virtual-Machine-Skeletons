# Causal Model Learning — 5.0.0

## QUORUM 5.0.0 Causal Model Learning and Model Competition

Agents may learn **fallible causal hypotheses** from experience.

Represent:
- candidate causal graph;
- evidence history;
- temporal ordering;
- intervention/observation distinction;
- confound uncertainty;
- domain/context;
- confidence;
- predictive performance;
- competing models.

### Model Competition
Permit multiple candidate explanations:
`M1`, `M2`, `M3` may coexist until evidence discriminates them.

### Causal Discipline
The system must distinguish:
- correlation;
- temporal succession;
- agent-attributed causation;
- intervention evidence;
- institutional rule consequence;
- semantic/grammatical relation;
- canonical WORLD causation when directly exposed by the simulation.

An agent must not infer privileged simulator causality merely because the runtime internally has it.

### Learning Loop
`prediction → observation → error → causal-hypothesis update → possible information seeking/intervention → revised prediction`

Causal learning may change action policy, but all real interventions remain ordinary ACTION requests subject to WORLD authority.
