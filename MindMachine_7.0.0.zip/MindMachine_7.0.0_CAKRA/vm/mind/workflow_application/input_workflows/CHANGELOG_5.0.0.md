# CHANGELOG — 5.0.0

## Major
- Added immutable constitutional core vs governed adaptive policy.
- Added metacognitive self-governance and policy amendment/rollback.
- Added causal-model learning and competing causal hypotheses.
- Added explicit inquiry planning and information-seeking.
- Added embodied/interoceptive or resource-state integration.
- Added distributed/tool-mediated cognition.
- Added developmental/life-history transitions.
- Expanded later-Wittgenstein integration to inquiry games, reasons-vs-causes, novel rule transfer, and evolving forms of life.
- Added culture/institution/semantic co-evolution.
- Added pragmatic dialogue actions.
- Added deterministic concurrency and scale qualification.
- Added formal invariants and scenario coverage.
- Expanded qualification to 36 gates.
- Added autonomous cognition red-team suite.

## Compatibility
The twelve workflow stage identifiers remain 5.1.0–5.12.0. Package version advances from 4.0.0 to 5.0.0. All inherited OPERATIONAL claims must be requalified.
