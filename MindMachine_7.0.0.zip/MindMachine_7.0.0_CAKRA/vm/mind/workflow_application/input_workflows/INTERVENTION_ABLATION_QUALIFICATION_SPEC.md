# Intervention and Ablation Qualification — 3.0.0

For each primary mechanism:
1. establish baseline;
2. perturb upstream cause;
3. measure mechanism response;
4. measure downstream decision/action response;
5. ablate or neutralize mechanism;
6. rerun paired scenario;
7. verify predicted causal signature changes;
8. record confounds and uncertainty.

Decorative state with no measurable behavioral effect cannot receive OPERATIONAL status.
