# Adaptive Cognitive Governance — 4.0.0

## QUORUM 4.0.0 Adaptive Cognitive Governance

### Cognitive Arbitration Council

Create a deterministic arbitration layer for conflicts that span modules. It receives typed proposals rather than raw mutable state.

Proposal classes include:
- belief revision;
- attention reprioritization;
- emotion-regulation intervention;
- motive escalation;
- goal creation/abandonment;
- self-model revision;
- relationship revision;
- rule/practice revision;
- semantic-context revision;
- strategy switch;
- resource-budget escalation;
- LOD promotion/demotion.

Each proposal carries:
- proposer subsystem;
- evidence;
- confidence;
- urgency;
- reversibility;
- affected timescale bands;
- downstream risk;
- resource cost;
- semantic context;
- authority requirements;
- competing proposals;
- rollback plan.

The arbiter may:
`ACCEPT`, `REJECT`, `DEFER`, `MERGE`, `REQUEST_EVIDENCE`, `ESCALATE_REFLECTION`, `ENTER_RECOVERY`.

### Policy Hierarchy

Policies are ordered:
1. WORLD/authority invariants;
2. state-integrity invariants;
3. resource/fault containment;
4. long-term commitments/hinges;
5. active goals and social obligations;
6. cognitive strategy preferences;
7. local heuristics.

Lower-level policy may not override a higher-level invariant.

### Governance Is Not Omniscience

The arbitration layer does not gain hidden WORLD facts or direct access to another agent's true mind. It only arbitrates the lawful state available to the current mind.
