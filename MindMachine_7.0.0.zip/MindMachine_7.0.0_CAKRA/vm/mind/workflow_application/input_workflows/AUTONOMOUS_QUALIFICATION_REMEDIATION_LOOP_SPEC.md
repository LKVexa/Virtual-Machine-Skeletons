# Autonomous Qualification Remediation Loop — 6.0.0

## QUORUM 6.0.0 Autonomous Remediation Loop

Introduce a bounded `QualificationRemediationController`.

When a gate fails:

`DETECT FAIL`
→ `CLASSIFY ROOT CAUSE`
→ `MAP AFFECTED INVARIANTS`
→ `GENERATE REMEDIATION CANDIDATES`
→ `RISK-RANK`
→ `SANDBOX`
→ `APPLY MINIMAL CHANGE`
→ `RETEST LOCAL GATE`
→ `RETEST DEPENDENCIES`
→ `REPLAY REGRESSION CORPUS`
→ `PROMOTE / ROLLBACK / QUARANTINE`

### Root-Cause Classes
- missing implementation;
- authority violation;
- schema mismatch;
- provenance gap;
- semantic-context failure;
- determinism failure;
- resource overload;
- causal ineffectiveness;
- migration issue;
- LOD information loss;
- policy instability;
- concurrency race;
- test insufficiency;
- model-assumption conflict.

### Guardrail
The remediation controller may modify governed implementation/policy only.
It cannot weaken a failed invariant merely to make a test pass.
