# Adaptive Cognitive Ecology Architecture — 3.0.0

## Canonical Spine
**WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING**

## Planes
- Causal
- Epistemic
- Regulatory
- Social-Semantic
- Developmental

## Core Runtime Services
- MindSupervisor
- CausalGraphRegistry
- StateLineageLedger
- CognitiveBudgetManager
- PredictiveWorldModel
- CognitiveStrategyArbiter
- SemanticPracticeRuntime
- ContradictionManager
- RecoverySupervisor
- EvidenceRecorder

## Rule
Recurrent influence is permitted only through typed, replay-visible, authority-safe edges. Every committed WORLD mutation remains under WORLD authority.
