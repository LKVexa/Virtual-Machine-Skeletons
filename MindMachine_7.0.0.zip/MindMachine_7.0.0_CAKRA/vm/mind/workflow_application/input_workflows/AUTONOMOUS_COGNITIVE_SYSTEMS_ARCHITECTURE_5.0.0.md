# Autonomous Cognitive Systems Architecture — 5.0.0

## QUORUM 5.0.0 Autonomous Cognitive Systems Layer

Version 5.0.0 upgrades the governed 4.0.0 architecture into a **boundedly self-adaptive autonomous cognitive system**.

The mandatory causal spine remains:

**WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING**

5.0.0 adds adaptation *around* this spine without granting any subsystem the authority to bypass it.

### Three classes of architecture rule

#### A. Immutable Constitutional Core
These rules are not self-amendable by an agent:
- WORLD sovereignty;
- epistemic locality;
- counterfactual/observed separation;
- provenance requirements;
- action transactionality;
- replay accountability;
- cross-agent isolation;
- bounded resources;
- explicit uncertainty;
- no silent contradiction erasure;
- no silent semantic-context invention;
- LOD honesty;
- no consciousness/sentience overclaim.

#### B. Governed Adaptive Policy
These may adapt only through proposal, evidence, sandbox evaluation, arbitration, qualification, and rollback:
- attention policies;
- information-seeking thresholds;
- cognitive strategy selection;
- planning depth;
- learning-rate policies;
- memory retrieval/consolidation policy;
- emotion-regulation strategy selection;
- social-model depth;
- semantic-disambiguation strategy;
- goal-arbitration heuristics;
- LOD resource allocation.

#### C. Ordinary Agent State
Beliefs, active emotions, motives, memories, self-aspects, goals, plans, relationships, predictions, and learned practices evolve through ordinary lawful cognition.

### Core 5.0.0 Services

Introduce conceptual services:
- `MetaCognitiveController`
- `PolicyAmendmentManager`
- `CausalModelLearner`
- `InteroceptiveStateRuntime`
- `InquiryPlanner`
- `ExternalCognitionManager`
- `DevelopmentalTransitionManager`
- `CultureInstitutionEvolutionRuntime`
- `DeterministicConcurrencyCoordinator`
- `FormalInvariantOracle`
- `ScenarioCoverageEngine`
- `LongHorizonStabilitySupervisor`

None of these services owns WORLD truth.
