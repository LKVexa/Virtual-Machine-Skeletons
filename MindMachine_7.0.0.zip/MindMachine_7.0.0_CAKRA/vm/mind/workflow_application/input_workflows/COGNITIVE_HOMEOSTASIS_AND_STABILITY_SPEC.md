# Cognitive Homeostasis and Stability — 3.0.0

Track:
- cognitive load;
- contradiction load;
- uncertainty burden;
- goal congestion;
- social conflict load;
- memory pressure;
- planning debt;
- semantic ambiguity load;
- recovery need.

Require bounded loops, hysteresis, queue limits, backpressure, recursion ceilings, deterministic degraded modes, and explicit recovery.

The runtime must never force fabricated certainty merely to reduce computational load.
