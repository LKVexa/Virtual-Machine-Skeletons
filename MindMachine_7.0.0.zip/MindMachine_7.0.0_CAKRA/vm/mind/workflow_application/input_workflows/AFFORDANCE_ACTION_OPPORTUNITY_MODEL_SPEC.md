# Affordance and Action-Opportunity Model — 6.0.0

## QUORUM 6.0.0 Affordance and Action-Opportunity Model

Agents should reason about what the WORLD appears to allow from their local perspective.

An `AffordanceRecord` may contain:
- perceived opportunity;
- relevant object/place/agent;
- required capability;
- required resource;
- expected cost;
- expected benefit;
- risk;
- social/norm constraints;
- uncertainty;
- time window;
- evidence.

Affordances are beliefs about possible action, not guaranteed WORLD permissions.

### Dynamic Affordance Update
WORLD changes, learning, fatigue, role changes, tools, relationships, institutions, and semantic understanding can change perceived affordances.

This directly connects PERCEPTION and BELIEF to GOALS, DELIBERATION, and ACTION.
