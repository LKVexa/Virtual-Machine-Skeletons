# Cross-Stage Dynamic Orchestration — QUORUM 2.0.0

## Objective

Coordinate all twelve workflows as one living cognitive system rather than twelve isolated modules.

## Canonical loop

**WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING**

## Orchestrator responsibilities

1. Maintain causal tick, cognitive sub-tick, and slow-development epoch.
2. Schedule nodes by cadence and event relevance.
3. Accept interrupt requests but re-enter only at lawful nodes.
4. Enforce resource budgets.
5. Detect circular runaway feedback.
6. Maintain transaction boundaries between ACTION and WORLD.
7. Route committed outcomes to LEARNING.
8. Coordinate cross-stage state migrations.
9. Preserve semantic context and provenance across module boundaries.
10. Emit causal checksums and replay evidence.

## Required cross-stage feedback edges

- PERCEPTION ⇄ ATTENTION through lawful re-sampling/search.
- BELIEF ← MEMORY evidence retrieval.
- APPRAISAL ← SELF, BELIEF, GOALS, social context.
- EMOTION → ATTENTION, MEMORY accessibility, DELIBERATION depth.
- MOTIVATION → goal spawning and active-perception priorities.
- MEMORY → SELF continuity and GOAL commitment.
- SELF → value/role constraints on APPRAISAL and GOALS.
- GOALS → ATTENTION and DELIBERATION.
- DELIBERATION → MEMORY query and counterfactual simulation.
- DECISION → ACTION intent.
- WORLD → outcome receipt.
- LEARNING → belief, habit, semantic competence, trust, strategy, and future attention policy.

## Dynamic stability rules

- Every recurrent loop has a maximum recursion/iteration budget per causal tick.
- Confidence updates are bounded.
- Goal reprioritization uses hysteresis.
- Mode changes use hysteresis/debounce.
- Memory consolidation is rate-limited.
- Semantic drift requires repeated use evidence or recognized correction.
- Identity changes require sustained evidence or high-impact events with explicit provenance.
- Hinge revision is slow unless a configured catastrophic contradiction occurs.

## Cross-stage gate

The integrated system is not OPERATIONAL until a single replay trace demonstrates all 16 nodes of the canonical loop, at least three lawful feedback edges, one ambiguity, one contradiction, one WORLD-rejected action, one learning update, and a changed next-cycle decision.
