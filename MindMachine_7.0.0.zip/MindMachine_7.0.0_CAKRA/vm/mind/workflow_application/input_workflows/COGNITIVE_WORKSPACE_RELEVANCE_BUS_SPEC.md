# Cognitive Workspace and Relevance Bus — 6.0.0

## QUORUM 6.0.0 Cognitive Workspace and Relevance Bus

Introduce a `CognitiveWorkspaceBus` as an agent-local coordination mechanism.

### Purpose
The bus lets subsystems publish **candidate items for relevance**, not canonical truth.

Candidate workspace items may include:
- percepts;
- belief conflicts;
- emotionally salient events;
- urgent needs;
- memories;
- self/role activations;
- goal deadlines;
- plan failures;
- social signals;
- semantic ambiguities;
- invariant violations;
- prediction errors;
- inquiry results.

### Workspace Entry
Every item carries:
- `workspace_item_id`;
- source subsystem;
- proposition/source type;
- causal tick/epoch;
- salience;
- urgency;
- confidence;
- goal relevance;
- social relevance;
- semantic context;
- resource cost;
- persistence TTL;
- evidence refs;
- privacy/visibility class.

### Competition and Broadcast
Selection is deterministic under the same state/seed.
The workspace may:
- select;
- defer;
- suppress;
- merge;
- request clarification;
- retain conflict.

Broadcast means "made available to eligible mind subsystems", not "made true".

### Anti-Dominance
Prevent one subsystem from monopolizing the workspace through:
- salience caps;
- fairness windows;
- starvation detection;
- duplicate suppression;
- novelty decay;
- emergency override only through constitutional policy.

### Qualification
Test that:
- relevant items reach dependent subsystems;
- irrelevant noise does not dominate;
- hidden WORLD truth never appears;
- workspace competition remains bounded;
- workspace selection changes downstream cognition in causal-ablation tests.
