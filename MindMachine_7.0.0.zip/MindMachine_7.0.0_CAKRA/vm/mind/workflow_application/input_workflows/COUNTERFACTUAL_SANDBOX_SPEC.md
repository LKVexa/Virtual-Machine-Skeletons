# Counterfactual Sandbox — 4.0.0

## QUORUM 4.0.0 Counterfactual and Prospective Simulation Sandbox

Create a bounded `CounterfactualSandbox` for deliberation.

It may simulate:
- alternative actions;
- alternative interpretations/aspect frames;
- possible social responses;
- plan branches;
- possible future WORLD states;
- possible semantic misunderstandings;
- consequences of rule application;
- consequences of inaction.

Every sandbox artifact carries:
- `simulation_id`;
- parent causal tick;
- assumptions;
- source beliefs;
- confidence;
- branch depth;
- horizon;
- resource cost;
- semantic context;
- simulated observations;
- simulated outcomes;
- termination reason.

Strict rule:
`SIMULATED ≠ OBSERVED ≠ REMEMBERED_AS_EXPERIENCED`.

Counterfactual content may be remembered only as `imagined/rehearsed/thought`, never as an experienced event.

### Robustness
- bounded branching factor;
- bounded horizon;
- deterministic pruning;
- no recursive sandbox creation beyond configured depth;
- no direct WORLD mutation;
- explicit uncertainty accumulation;
- cancellation on stale causal epoch.
