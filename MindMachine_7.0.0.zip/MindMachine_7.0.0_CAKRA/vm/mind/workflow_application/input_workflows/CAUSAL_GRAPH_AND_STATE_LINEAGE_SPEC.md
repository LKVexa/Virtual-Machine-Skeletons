# Causal Graph and State Lineage Specification — 3.0.0

For each high-impact state:
- declare incoming causes;
- moderators;
- mediators;
- outgoing consequences;
- feedback edges;
- uncertainty;
- timescale;
- semantic context;
- resource cost;
- persistence;
- LOD conservation;
- evidence references.

Every mutation must be reconstructable as:
`prior → trigger/evidence → rule → new state → downstream effects`.

Qualification requires controlled intervention or ablation for primary mechanisms.
