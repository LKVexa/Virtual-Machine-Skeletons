# Agency, Intention, Commitment, Execution — 6.0.0

## QUORUM 6.0.0 Agency, Intention, Commitment, and Execution Monitoring

Represent the action pathway explicitly:

`DESIRE`
→ `GOAL`
→ `INTENTION`
→ `COMMITMENT`
→ `PLAN`
→ `ACTION_ATTEMPT`
→ `WORLD_RESULT`
→ `EXPERIENCE`
→ `LEARNING`

These are distinct state classes.

### Intention Record
Track:
- intended outcome;
- reasons as understood by the agent;
- motivating goals;
- expected consequences;
- confidence;
- commitment strength;
- revocation conditions;
- social obligations;
- time horizon;
- semantic/practice context.

### Execution Monitor
During an action/plan:
- monitor preconditions;
- detect drift;
- detect partial success;
- detect unexpected WORLD change;
- compare predicted vs actual intermediate results;
- interrupt/replan when thresholds are crossed.

### Agency Failure Taxonomy
- could not act;
- acted but failed;
- action partially succeeded;
- action produced unintended outcome;
- goal became impossible;
- commitment was revoked;
- WORLD rejected request;
- another agent interfered;
- semantic misunderstanding invalidated plan.

Learning must distinguish these failure modes.
