# Cognitive Constitution — 4.0.0

## QUORUM 4.0.0 Cognitive Constitutional Layer

Version 4.0.0 adds a **cognitive constitution** above the 3.0.0 adaptive cognitive ecology. The constitution does not dictate what an agent believes or wants. It governs how cognitive subsystems may alter one another, how authority is preserved, how conflicts are arbitrated, how failures degrade, and what evidence is required before a state transition becomes durable.

The immutable causal spine remains:

**WORLD → PERCEPTION → ATTENTION → BELIEF → APPRAISAL → EMOTION → MOTIVATION → MEMORY → SELF → GOALS → DELIBERATION → DECISION → ACTION → WORLD → LEARNING**

### Constitutional Invariants

Every implementation must enforce:

1. **WORLD sovereignty** — only WORLD authority commits canonical facts and effects.
2. **Epistemic locality** — an agent can reason only from lawfully acquired evidence, memory, public state, and explicitly modeled inference.
3. **Provenance conservation** — high-impact belief, memory, self, goal, relationship, rule, and semantic mutations retain causal lineage.
4. **Counterfactual separation** — imagined, predicted, rehearsed, dreamed, simulated, and hypothetical content never becomes experienced WORLD history without an explicit source transition.
5. **Uncertainty preservation** — computation pressure may simplify uncertainty but may not convert it into false certainty.
6. **Slow-state protection** — transient affect, noise, one-off testimony, or a single failed prediction cannot silently rewrite long-timescale identity, values, competence, or hinge commitments.
7. **Conflict visibility** — contradictions are represented, ranked, deferred, investigated, or resolved; never silently overwritten.
8. **Contextual semantics** — semantic interpretation carries language-game, form-of-life, community, role, use-history, and confidence where material.
9. **Finite cognition** — attention, planning, memory retrieval, social recursion, semantic disambiguation, and predictive depth consume bounded resources.
10. **Action transactionality** — intention is not outcome; WORLD acceptance/rejection/partial realization is explicit.
11. **Learning accountability** — learning changes future processing through recorded update mechanisms; it does not revise canonical past events.
12. **Replay accountability** — every consequential state transition is reconstructable to the declared determinism level.
13. **LOD honesty** — compressed/reconstructed state cannot masquerade as exact retained state.
14. **Semantic non-totalization** — no global lexicon may erase legitimate community/practice variation.
15. **Model pluralism** — no single psychological theory is silently elevated to universal truth. Mechanisms declare assumptions, domain, limitations, and evidence class.
16. **No consciousness overclaim** — successful cognitive simulation is not evidence of literal consciousness or sentience.

### Invariant Monitor

Introduce a conceptual `CognitiveInvariantMonitor` that checks:
- unauthorized WORLD writes;
- inaccessible evidence reads;
- provenance gaps;
- counterfactual contamination;
- confidence saturation;
- slow-state mutation without threshold evidence;
- contradiction erasure;
- semantic context loss;
- budget overruns;
- replay divergence;
- LOD provenance violations;
- stale causal epochs;
- cross-agent state leakage.

Severity levels:
`INFO`, `WARN`, `DEGRADE`, `BLOCK_COMMIT`, `ROLLBACK`, `QUARANTINE`.

A severe invariant failure must block or roll back the implicated cognitive transaction rather than corrupt state.
