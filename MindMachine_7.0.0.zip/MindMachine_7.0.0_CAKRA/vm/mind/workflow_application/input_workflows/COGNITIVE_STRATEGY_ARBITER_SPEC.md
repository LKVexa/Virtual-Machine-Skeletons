# Cognitive Strategy Arbiter Specification — 3.0.0

The arbiter selects/blends:
- reflex;
- habit;
- heuristic;
- analogy;
- memory case;
- rule practice;
- social imitation;
- model-based planning;
- information seeking;
- reflection.

Inputs include stakes, uncertainty, novelty, time pressure, fatigue, expertise, affect, conflict, semantic ambiguity, social consequence, resource budget, and prior strategy success.

Selection must be seedable/replayable and may itself learn from outcomes.
