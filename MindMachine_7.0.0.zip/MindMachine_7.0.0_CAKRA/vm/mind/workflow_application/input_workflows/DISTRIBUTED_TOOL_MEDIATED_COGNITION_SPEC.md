# Distributed and Tool-Mediated Cognition — 5.0.0

## QUORUM 5.0.0 Distributed and Tool-Mediated Cognition

Later-Wittgenstein's emphasis on practice and forms of life requires cognition to include tools and shared practices, not only internal representations.

Support lawful use of:
- written notes;
- maps;
- instruments;
- records;
- calculators;
- ledgers;
- signs;
- public documents;
- institutional archives;
- shared task artifacts;
- communication protocols.

### External Memory
External artifacts may serve as memory aids, but:
- artifact contents remain WORLD/public/object state;
- an agent must perceive/read them to use them;
- access may be partial or role-restricted;
- external records can be wrong, stale, forged, or misunderstood;
- internal memory stores what the agent learned from the artifact, not automatic synchronized truth.

### Practice Coupling
Tool competence is represented as learned rule-practice:
`demonstration → guided use → correction → independent use → transfer`.

This supports realistic forms of life in which thinking is partly scaffolded by practices and artifacts.
