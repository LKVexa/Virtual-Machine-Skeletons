# Cross-Stage Contract Matrix — 6.0.0

Every pair of adjacent and recurrently coupled stages must declare:
- producer;
- consumer;
- data contract;
- proposition type;
- semantic context;
- authority owner;
- read/write permissions;
- timescale;
- persistence;
- LOD behavior;
- uncertainty;
- replay fields;
- failure policy;
- remediation dependency.

Required recurrent contracts include:
EMOTION→ATTENTION,
GOALS→ATTENTION,
MEMORY→BELIEF,
SELF→APPRAISAL,
DELIBERATION→MEMORY,
LEARNING→POLICY,
WORLD_RESULT→APPRAISAL/LEARNING,
SEMANTIC_REPAIR→BELIEF/DELIBERATION.
