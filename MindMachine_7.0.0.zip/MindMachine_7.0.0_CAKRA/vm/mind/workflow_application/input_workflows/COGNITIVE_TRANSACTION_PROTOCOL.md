# Cognitive Transaction Protocol — 4.0.0

## Transaction
`BEGIN`
→ capture causal epoch
→ collect typed subsystem proposals
→ validate constitutional invariants
→ arbitrate conflicts
→ stage mind-state updates
→ produce ACTION intent if any
→ WORLD precondition validation
→ WORLD commit/reject/partial result
→ build experience envelope
→ apply LEARNING proposals
→ validate postconditions
→ `COMMIT`

On invariant failure:
`ROLLBACK` or `QUARANTINE`.

## Required receipt chain
- transaction_id
- causal_epoch
- input state digest
- proposal digests
- arbitration receipt
- action intent receipt
- WORLD receipt
- learning receipt
- final state digest
- invariant-monitor result
- causal checksum
