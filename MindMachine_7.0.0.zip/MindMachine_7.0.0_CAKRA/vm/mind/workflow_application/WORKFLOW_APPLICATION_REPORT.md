# MindMachine Workflow Application Report

The 12-stage QUORUM Cognitive-Psychological + Later-Wittgenstein Workflow Series 6.0.0 has been mapped into the VM as a hosted-reference `vm/mind/` subsystem.

Applied integration surfaces:

- durable MindRuntime tied to persistent WORLD entities;
- QVM Mind ABI SVC 48–63;
- WORLD/MIND authority separation;
- full cognitive-loop host API;
- bounded workspace and coherence debt;
- counterfactual separation;
- semantic language-game bridge;
- actor-specific psychological LOD profiles;
- save/load and hash-chained mind ledger;
- regression, qualification, and guest demo evidence.

`APPLIED_HOSTED_REFERENCE` means the workflow requirement has an implementation target in this package. It does not automatically mean every production/empirical gate described by the workflow is fully qualified. See `../evidence/QUALIFICATION_REPORT.md`.
