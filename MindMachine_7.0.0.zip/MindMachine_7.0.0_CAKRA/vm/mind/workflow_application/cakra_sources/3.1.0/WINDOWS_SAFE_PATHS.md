# Windows-Safe Paths

Package paths are kept compact. Extract near a drive root, for example `C:\Q31\`.

Recommended command:

```cmd
mkdir C:\Q31
```

Then extract the ZIP into that directory.
