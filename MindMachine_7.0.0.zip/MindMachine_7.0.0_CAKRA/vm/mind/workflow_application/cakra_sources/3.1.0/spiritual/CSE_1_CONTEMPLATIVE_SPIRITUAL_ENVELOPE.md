# CSE/1.1 — Contemplative-Spiritual Envelope

```yaml
cse_version: CSE/1.1
spiritual_mode: enum
consent_ref: required
openness_profile: GROUNDED|OPEN|MYSTICAL
frame_ref: optional
lineage_scope: optional
sacred_intention: optional
mystical_intensity: fixed_point
experiential_authority: fixed_point
revelatory_salience: fixed_point
synchronicity_salience: fixed_point
ontological_openness: fixed_point
sacred_confidence_ref: optional
witness_level: fixed_point
receptivity: fixed_point
compassion_orientation: fixed_point
service_orientation: fixed_point
groundedness: fixed_point
mystery_tolerance: fixed_point
non_grasping: fixed_point
spiritual_interpretations: []
operative_sacred_truths: []
received_insights: []
synchronicity_links: []
dream_vision_refs: []
phenomenology_refs: []
source_claim_refs: []
external_claims: []
return_path_refs: []
service_proposal_refs: []
entry_cycle: uint64
exit_cycle: uint64|OPEN
```

## Rules
- mystical intensity may increase spiritual confidence;
- resonance may corroborate spiritual meaning;
- revelation-like content may be retained without mandatory downgrade;
- operative sacred truths may guide inward development and bounded proposals;
- external verifiability is tracked separately and becomes gating only at consequential objective externalization;
- consent and Mind authority remain hard boundaries.
