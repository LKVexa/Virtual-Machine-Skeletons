# Spiritual Epistemics & Guardrails — 3.1 Compatibility Note

The 3.0.0 firewall-style model is **deprecated** for this package.

Use `SPIRITUAL_EPISTEMIC_MEMBRANE.md` instead.

3.1.0 allows mystical intensity, vision, synchronicity, intuitive certainty, resonance, lineage consonance, received insight and crown integration to increase **spiritual confidence** and to support **operative sacred truths**.

A proposition is not downgraded merely because it is metaphysical or mystical.

The remaining boundary is narrow: when the system exports an independently testable proposition as objective external fact and materially consequential action depends upon objective accuracy, run the light-touch membrane.
