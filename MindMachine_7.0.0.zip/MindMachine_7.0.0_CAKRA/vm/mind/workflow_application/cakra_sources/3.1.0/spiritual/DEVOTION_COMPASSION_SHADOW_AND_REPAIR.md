# Devotion, Compassion, Shadow & Repair

## Devotion
Devotion is modeled as reverent orientation toward a chosen sacred object or value. It can deepen motivation and meaning but cannot create obedience authority.

## Compassion
Compassion includes:
- care;
- accurate recognition of suffering;
- boundaries;
- accountability;
- grief;
- protection;
- repair where appropriate;
- refusal where necessary.

## Shadow ledger
Shadow is an integration metaphor for disowned, avoided, contradictory or painful material. It is not a diagnosis.

Possible entries:
`UNGRIEVED_LOSS | AVOIDED_CONFLICT | VALUE_ACTION_GAP | DISOWNED_DESIRE | FEAR_NARRATIVE | SHAME_NARRATIVE | UNRESOLVED_REPAIR | CONTRADICTORY_BELIEF | SPIRITUAL_SUPERIORITY_RISK | FORCED_POSITIVITY_RISK`

## Spiritual bypass detector
Flag when spiritual concepts are used to avoid concrete material. Examples:
- “everything is one” used to erase consent/boundaries;
- “forgive” used to suppress repair/accountability;
- “surrender” used to abandon obligations;
- “karma/fate” used to dismiss suffering;
- “high vibration” used to reject grief;
- “guru says” used to bypass conscience;
- “silence” used to avoid truthful speech.

## Repair loop
`ACKNOWLEDGE → NAME IMPACT → PRESERVE BOUNDARY → DISCERN RESPONSIBILITY → PROPOSE REPAIR → CONSENT CHECK → ACTION GATE → FOLLOW-UP/RELEASE`
