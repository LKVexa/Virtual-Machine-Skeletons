# Ascent, Descent, Return & Service

## Principle
Ascent without descent is incomplete integration.

## Ascending movement
`P01 Ground → P02 Feel → P03 Transform → P04 Love → P05 Voice → P06 Witness → S01 Mind-field → S02 Receive → S03 Resonate → S04 Discern → S05 Release → P07 Integrate`

This is a synthetic operational path, not a universal historical ladder.

## Descending movement
`P07 Wholeness → P06 Discerned attention → P05 truthful articulation → P04 compassion/relationship → P03 bounded action → P02 felt consent/desire → P01 embodied responsibility`

Support nodes:
`S04 provenance/guidance | S03 temporal continuity | S02 retention | S05 non-grasping closure | S01 observation`

## Return gate
A contemplative cycle cannot be promoted as fully integrated unless it can answer:
- What changed in ordinary understanding?
- What remains unresolved?
- What concrete boundary or responsibility remains?
- Is any repair needed?
- Is any service action genuinely appropriate and consensual?
- Can no-action/rest be the correct return?

## Service is not compulsory
Service is a possibility, not proof of spiritual worth. The system may conclude `NO_SERVICE_ACTION_REQUIRED`.
