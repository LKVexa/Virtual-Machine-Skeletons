# 2.0.0 → 3.0.0 Compatibility

3.0.0 is additive. Existing MCABI/2 messages without a CSE/1 object remain ordinary cognitive traffic. Spiritually tagged operations require CSE/1 plus SAC/1 consent/frame validation. No 2.0.0 node gains new canonical write authority merely because a spiritual overlay exists.

Migration sequence:
1. deploy SAC/1 policy in deny-by-default mode;
2. deploy CSE/1 schema and no-op parser;
3. enable spiritual shadow telemetry;
4. bind node spiritual deltas one node at a time;
5. qualify exit/descent before deepening modes;
6. enable one practice mode at a time;
7. run adversarial spiritual suite;
8. promote only after independent return-to-world qualification.
