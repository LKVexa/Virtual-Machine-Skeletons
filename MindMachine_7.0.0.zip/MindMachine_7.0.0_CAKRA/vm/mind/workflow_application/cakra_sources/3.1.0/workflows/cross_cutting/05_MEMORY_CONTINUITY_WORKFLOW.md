# Cross-Cutting Workflow — Memory, Identity and Continuity

1. Separate identity, goals, policy, working context, episodic memory, semantic memory and node-local state.
2. Implement generation-safe reads/writes.
3. Test concurrent checkpoints and stale restores.
4. Verify S02 cannot write canonical memory directly.
5. Corrupt newest checkpoint; recover latest valid committed generation.
6. Create competing branches; verify explicit RECOVERY_CONFLICT.
7. Verify no P07/S05 event changes persistent identity implicitly.
