# Cross-Cutting Workflow — Causal Ledger and Replay

1. Define receipt schema and hash-domain separation.
2. Record root inputs, memory generations, proposals, conflicts, checks and commits.
3. Replay golden cycles in clean process.
4. Reorder one event and verify tamper/divergence detection.
5. Forge one causal parent and verify rejection.
6. Execute one-node counterfactual replay; verify canonical history unchanged.
7. Produce why/why-not reports from receipts, not prose reconstruction.
