# Cross-Cutting Workflow — Authority and Mind Commit Barrier

1. Enumerate every mutable field and canonical writer.
2. Enumerate every node capability.
3. Generate forbidden write tests automatically from the ownership table.
4. Implement MCB precondition sequence.
5. Crash-cut before/at/after commit.
6. Retry identical transaction and verify idempotent receipt.
7. Rotate node lease, policy generation and topology generation; verify stale proposals fail.
8. Attempt direct external action from every node.
9. Prove hard safety always has reserved resources and precedence.
