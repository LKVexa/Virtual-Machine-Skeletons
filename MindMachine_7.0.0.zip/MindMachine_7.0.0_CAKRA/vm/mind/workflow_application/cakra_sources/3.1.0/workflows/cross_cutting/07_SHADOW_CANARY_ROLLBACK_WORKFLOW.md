# Cross-Cutting Workflow — Shadow, Canary and Rollback

Execute every stage in `qualification/PROMOTION_LADDER.md`. At each stage: record entry generation, enable only declared capability set, run mixed workloads, classify deltas, execute rollback under load, compare state/receipt digests, and prohibit stage skipping.
