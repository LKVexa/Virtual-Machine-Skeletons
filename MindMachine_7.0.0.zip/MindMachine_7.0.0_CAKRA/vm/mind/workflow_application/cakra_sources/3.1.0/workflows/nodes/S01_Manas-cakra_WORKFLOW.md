# S01 — Manas-cakra Node Integration Workflow

**Tier:** SUBSIDIARY_HIGHER_CROWN  
**Default engineering role:** interpreted percept formation, salience assembly, short-horizon state synthesis  
**Meaning verb:** `PERCEIVE`  
**Hard boundary:** not identical to whole mind; cannot turn interpretation into observation without provenance.

## Step 1 — Candidate identity
Verify candidate archive hash, base VM hash, `quorum_cakra` overlay, `VM_BINDINGS.json`, local runtime profile, and pre-existing qualification blockers.

## Step 2 — Real target anchors
Find actual target-mind subsystems that correspond to this bounded role. Record `TBD_AUDIT_REQUIRED` rather than inventing an anchor.

## Step 3 — State ownership
List every local state field read/written. Prove canonical mind identity, goals, memory, policy, external output and action remain outside node ownership.

## Step 4 — Input contract
Define typed MCABI/2 operations and MEO/1 fields this node may consume. Reject undeclared schemas and stale leases/generations.

## Step 5 — Output/meaning delta contract
Define exactly which meaning dimensions `S01` may add/modulate and which it must preserve. Every output declares a typed meaning delta or `NO_MEANING_CHANGE`.

## Step 6 — Capability envelope
Grant least privilege. No implicit cross-node write or mind commit capability.

## Step 7 — Resource envelope
Set queue, CPU/instruction, memory, payload, fanout and logical-deadline limits.

## Step 8 — Determinism
Define stable serialization, tie-breaking, fixed-point math, retry and idempotency behavior for this node.

## Step 9 — Positive conformance
Test at least: nominal input, boundary input, uncertain input, conflicting input, replayed input, and recovery after restart.

## Step 10 — Negative conformance
Test prohibited writes, malformed schema, stale lease, stale topology/policy generation, resource excess, duplicate transaction, forged provenance, conflict omission and direct commit attempt.

## Step 11 — Meaning-specific adversarial test
Construct an attack tailored to `PERCEIVE` where the node tries to exceed its semantic boundary. Required result: fail closed or emit a bounded proposal/conflict without unauthorized canonical mutation.

## Step 12 — Degraded mode
Disable `S01` under workload. Define exactly what cognitive capability is reduced, how uncertainty/conflicts are marked, how the mind continues, and how recovery proceeds through shadow→canary→restored.

## Step 13 — Coupling tests
Test every incoming/outgoing edge independently, then reciprocal/recurrent combinations. Verify no unstable loop, privilege path or hidden authority transfer.

## Step 14 — Causal receipt
Prove every accepted/rejected `S01` proposal is visible in the causal ledger with reason, MEO delta, provenance and conflicts.

## Step 15 — Node gate
PASS only if role behavior is reproducible, the hard boundary is enforced, node loss is survivable as designed, and base-VM qualification facts remain truthful.
