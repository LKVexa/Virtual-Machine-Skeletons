# Cross-Cutting Workflow — Meaning Lifecycle

1. Freeze MEO/1 schema and score scales.
2. Define input grounding/provenance requirements.
3. Trace one golden object through all applicable node deltas.
4. Verify uncertainty does not decrease without a reason/evidence delta.
5. Verify conflicting interpretations stay attached.
6. Verify language preserves intent and epistemic status.
7. Verify P07 integration preserves dissent.
8. Verify descending reintegration yields concrete constraints/actions.
9. Verify rejected deltas are reversible.
10. Emit meaning-quality evidence report.
