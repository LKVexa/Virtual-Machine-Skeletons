# Cross-Cutting Workflow — Final Qualification

1. Resolve requirement→test→evidence→gate DAG.
2. Mark missing evidence as BLOCKED/PARTIAL automatically.
3. Re-run all critical tests from clean state.
4. Verify source/candidate hashes and base-VM regression.
5. Run actual-duration soak and label truthfully.
6. Reproduce in clean environment.
7. Run rollback/disaster drill.
8. Issue OPERATIONAL only when no critical blocker remains.
