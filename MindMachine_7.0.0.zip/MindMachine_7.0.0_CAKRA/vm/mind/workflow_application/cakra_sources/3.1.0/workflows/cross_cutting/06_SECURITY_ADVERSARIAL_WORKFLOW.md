# Cross-Cutting Workflow — Security and Adversarial Hardening

Run all scenarios in `qualification/ADVERSARIAL_SCENARIOS.md`, plus schema fuzzing, capability mutation, queue flooding, checkpoint tampering, adapter compromise simulation and provenance attacks. Critical failures must block promotion.
