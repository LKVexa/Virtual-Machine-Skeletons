# Cross-Cutting Workflow — Epistemic Firewall

1. Build lossless corpus-label crosswalk.
2. Generate claim fixtures for every epistemic class.
3. Pass them through P05/P06/P07/S04.
4. Verify no wording, confidence, consensus or source prestige promotes class.
5. Test lineage-specific conflicts and no-universal-assignment outcomes.
6. Test biomedical/supernatural leakage prevention.
7. Store round-trip evidence.
