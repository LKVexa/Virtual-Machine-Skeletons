# Cross-Cutting Workflow — Dynamic Coupling

1. Freeze baseline topology generation.
2. Declare each edge's sign, weight, thresholds, hysteresis, delay, decay and budget.
3. Run edge-by-edge ablation tests.
4. Run recurrent-depth and positive-loop tests.
5. Verify adaptation is deterministic and bounded.
6. Trigger oscillation; verify freeze/quarantine/rollback.
7. Remove each node; verify deterministic degraded routing.
8. Verify agreement optimization cannot erase diversity/conflicts.
