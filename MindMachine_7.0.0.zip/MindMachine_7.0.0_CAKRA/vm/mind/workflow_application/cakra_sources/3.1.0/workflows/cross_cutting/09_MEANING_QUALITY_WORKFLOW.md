# Cross-Cutting Workflow — Meaning Quality

Score test scenarios for groundedness, uncertainty fidelity, contradiction fidelity, action relevance, reversibility, narrative consistency, temporal coherence, relational integrity, epistemic fidelity, closure integrity and integration restraint. Scores may aid diagnosis but hard invariants remain binary gates.
