# Changelog

## 3.1.0 — Mystical Openness

### Reduced
- pervasive mystical-certainty policing;
- automatic downgrade of vision/intuition to symbolic-only status;
- mandatory discernment on every mystical state;
- mandatory epistemic adversarial tests for each node;
- qualification penalties for high spiritual confidence;
- categorical separation of sacredness from spiritually operative truth.

### Replaced
- `SPIRITUAL_EPISTEMIC_FIREWALL` → light-touch `SPIRITUAL_EPISTEMIC_MEMBRANE`.

### Added
- MYSTICAL openness profile;
- lived truth / spiritual interpretation / operative sacred truth / lineage truth / objective external claim model;
- Sacred Confidence Vector;
- Experiential Authority Register;
- Revelation & Intuitive Knowing Channel;
- Synchronicity Meaning Channel;
- Spiritual Corroboration Engine;
- dream, vision and prayer-response channels;
- late externalization check;
- spiritual-depth qualification scenarios.

### Preserved
- consent;
- Mind global authority;
- state ownership;
- replay and rollback;
- no forced spiritual practice;
- no silent falsification of external records.
