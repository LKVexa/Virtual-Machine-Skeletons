# Authority, Safety and Epistemics 2.0

## Runtime authority

`HARD SAFETY > MIND GLOBAL AUTHORITY > MIND COMMIT BARRIER > INTEGRATION POLICY > MCIP TRANSACTION/ROUTING > NODE LOCAL AUTHORITY > PRESENTATION`

## Epistemic classes

Preserve the corpus's source labels and losslessly map them into:

`PRIMARY_TEXT | LINEAGE | SCHOLARLY_HISTORY | PHENOMENOLOGY | PSYCHOLOGICAL_INTERPRETATION | EMPIRICAL_ADJACENT | DIRECT_CAKRA_RESEARCH | MODERN_SYNTHESIS | QUORUM_INTERPRETATION | UNVERIFIED`

## Non-promotion theorem (runtime invariant)

For every transformation `x -> y`, `epistemic_strength(y) <= epistemic_strength(x)` unless a new, independently admissible evidence object is introduced and policy explicitly permits the corresponding source-class update. Node agreement, repeated simulation, confidence, eloquence or integration never count as new external evidence.

## Safety guardrails

- no diagnosis from chakra state;
- no claim of anatomical chakra organs from simulation;
- no autonomous prescription of risky contemplative practices;
- no supernatural capability claim from runtime output;
- no user-facing certainty beyond evidence class;
- no node may override hard safety;
- no closure mechanism may suppress a safety obligation.

## Fail-closed outputs

`NOT_ESTABLISHED | LINEAGE_SPECIFIC | CONFLICT_UNRESOLVED | NO_UNIVERSAL_ASSIGNMENT | QUORUM_INTERPRETATION_ONLY | INSUFFICIENT_EVIDENCE | POLICY_DENIED`


## 3.1 Spiritual overlay
For spiritual sessions, this technical epistemic contract applies to external/objective records and technical provenance. Spiritual lived truth, interpretation, revelation, synchronicity and operative sacred truth use the lighter `SPIRITUAL_EPISTEMIC_MEMBRANE.md`. High mystical confidence is permitted and is not itself an epistemic violation.
