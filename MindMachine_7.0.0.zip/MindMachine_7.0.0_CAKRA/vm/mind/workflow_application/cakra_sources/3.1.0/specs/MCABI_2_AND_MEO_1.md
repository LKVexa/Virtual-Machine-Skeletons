# MCABI/2 and MEO/1

## MCABI/2 goals

MCABI/2 makes authority, causality, replay, conflict, topology generation and meaning deltas first-class. A message that cannot establish its source lease, policy generation, causal parents, schema and capability is rejected before semantic execution.

## Canonical envelope

```yaml
abi_version: MCABI/2
message_id: logical-128+
transaction_id: logical-128+|NONE
cycle_id: uint64
sequence_no: uint64
causal_parent_ids: []
source: mind|P01..P07|S01..S05|adapter-id
target: mind|node-id|service-id
source_epoch: uint64
source_lease_id: logical-id
topology_generation: uint64
policy_generation: uint64
channel: enum
operation: enum
service_class: READ|PROPOSE|MUTATE_INTERNAL|ADMIN|EVIDENCE
capability: enum
state_digest_before: sha256
payload_schema: schema-id
payload_digest: sha256
meaning_object_ids: []
meaning_delta_kind: enum
epistemic_class: enum
provenance_refs: []
conflict_set_ids: []
information_class: PUBLIC|INTERNAL|SENSITIVE_MODEL|RESTRICTED
resource_budget: deterministic descriptor
logical_deadline: uint64
retry_count: uint16
idempotency_key: logical-id
result_code: enum|NONE
state_digest_after: sha256|PROPOSAL_ONLY
receipt_digest: sha256|NONE
```

## Stable error families

- `E_ABI_*` schema/version/canonicalization
- `E_AUTH_*` capability/lease/epoch/impersonation
- `E_STATE_*` precondition/stale generation/ownership
- `E_POLICY_*` policy generation or prohibited operation
- `E_TOPO_*` topology generation/edge/cycle violation
- `E_EPI_*` provenance or epistemic promotion
- `E_MEAN_*` invalid meaning delta/conflict erasure/uncertainty laundering
- `E_RES_*` quota/backpressure/deadline
- `E_TXN_*` duplicate/atomicity/reconciliation
- `E_REPLAY_*` digest/order/divergence
- `E_SAFE_*` hard-safety denial

## MEO/1 canonical rules

- all score fields use declared fixed-point scale;
- UNKNOWN is distinct from zero;
- absent is distinct from intentionally empty;
- maps are canonically key-sorted;
- provenance and causal parents are digest-stable ordered sets;
- no free-text field changes authority by wording;
- a MEO is immutable after receipt; updates create a new version with parent reference.

## Compatibility

MCABI/1 must never be silently accepted as MCABI/2. If supported, an adapter must synthesize no unavailable semantics. Missing fields become explicit `UNKNOWN/LEGACY_UNAVAILABLE` and may cause an operation to be ineligible for mutation.
