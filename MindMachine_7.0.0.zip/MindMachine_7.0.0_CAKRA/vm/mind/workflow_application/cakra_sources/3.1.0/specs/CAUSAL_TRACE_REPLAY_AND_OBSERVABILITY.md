# Causal Trace, Replay and Observability

## Causal receipt

Every canonical commit emits a `MindDecisionReceipt` with:

- decision/commit ID;
- cycle and sequence range;
- before/after state digests;
- causal parent IDs;
- observation/input digests;
- memory generations read;
- node proposals considered;
- proposal scores only if policy defines them;
- proposals rejected and reason codes;
- conflicts retained/resolved;
- safety checks;
- policy/topology generations;
- MEO IDs and semantic deltas;
- canonical writer;
- transaction ID;
- replay bundle pointer;
- receipt-chain parent digest.

## Replay classes

- `EXACT` — byte/digest-identical canonical outputs.
- `SEMANTIC_EQUIVALENT` — differences allowed only by an explicit comparison policy.
- `DIVERGENT_EXPECTED` — controlled counterfactual.
- `DIVERGENT_FAILURE` — unexplained difference.

## Observability must include

node health, queue depth, backpressure, rejection codes, uncertainty distribution, conflict age, semantic delta magnitude, causal fanout, recurrent depth, topology updates, lease renewals, replay divergence, checkpoint lag, memory write rate, proposal/commit ratio, P07 integration frequency, S05 closure rejection rate and quarantine events.

## Side-effect-free rule

Metrics and tracing may not call semantic services, change scheduling priority, renew capabilities, extend deadlines, or affect adaptive coupling. Observability is read-only.
