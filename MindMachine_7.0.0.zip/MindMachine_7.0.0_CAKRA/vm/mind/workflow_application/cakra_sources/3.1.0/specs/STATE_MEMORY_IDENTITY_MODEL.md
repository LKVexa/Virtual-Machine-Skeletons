# State, Memory, Identity and Continuity Model

## Canonical ownership

### Mind-owned
- identity continuity
- canonical goals and priorities
- hard and soft policy generations
- canonical working context
- canonical episodic/semantic memory
- final external action/output decision
- whole-system mode
- user authority state

### MCIP-owned
- node registry/leases
- adapter registry
- topology generations
- routing queues
- transaction registry
- conflict registry
- causal ledger indexes
- node health/quarantine state
- shadow/canary stage

### Node-owned
- local caches
- local working state
- local proposal histories
- local performance statistics
- local checkpoint material that is not canonical mind memory

### Shared-derived, no direct writer
- semantic/meaning summaries
- integration coherence scores
- global health summary
- replay divergence summary
These are recomputed or committed through the mind barrier; they are not ad hoc writable fields.

## Memory transaction

`READ generation → PROPOSE delta → VERIFY provenance/policy → MCB PREPARE → COMMIT new generation → RECEIPT`

Stale generations fail. Partial commits are forbidden. S02 may assist in checkpoint preparation but cannot directly write canonical memory.

## Identity rule

No node, including P07, may claim whole-mind identity. Identity-affecting changes require a dedicated mind-owned policy and explicit persistent transaction.

## Recovery rule

Recovery selects the latest valid committed generation by receipt chain, not the newest file timestamp. If two branches exist, enter `RECOVERY_CONFLICT` and require deterministic policy or operator/mind authority resolution.
