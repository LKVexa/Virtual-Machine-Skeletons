# Dynamic Coupling Contract

## Objective

Allow the federation to behave dynamically without becoming nondeterministic, self-authorizing, or unstable.

## Edge classes

- `OBSERVATIONAL` — may read/annotate only.
- `EXCITATORY` — raises priority/salience within bounded range.
- `INHIBITORY` — lowers/suppresses proposal priority, never deletes evidence.
- `MODULATORY` — changes how a target interprets an input within declared schema.
- `RECIPROCAL_PAIR` — two separately receipted directed edges.

## Required edge fields

`edge_id, source, target, operation_set, sign, weight, activation_threshold, deactivation_threshold, hysteresis, logical_delay, decay, max_fanout, max_rate, resource_budget, epistemic_scope, required_capability, conflict_policy, topology_generation, adaptation_policy_id`

## Stability controls

- weight min/max;
- per-epoch delta cap;
- hysteresis to prevent chattering;
- decay toward policy baseline where appropriate;
- cycle detector and maximum recurrent depth;
- maximum positive-loop gain;
- queue/backpressure limit;
- oscillation counter;
- quarantine/freeze trigger;
- rollback to previous topology generation.

## Long-range couplings to test

Examples from the supplied synthetic crosswalk are permitted only as QUORUM_INTERPRETATION engineering edges, including root↔brow, desire↔expression, agency↔relation, brow↔manas, relation↔guidance, and global-integration broadcast. Each must be independently disableable and tested for necessity, side effects and failure behavior.

## Anti-monoculture rule

Do not adapt edges solely to maximize agreement among nodes. Preserve a diversity floor so that independent disagreement can survive long enough to be evaluated.
