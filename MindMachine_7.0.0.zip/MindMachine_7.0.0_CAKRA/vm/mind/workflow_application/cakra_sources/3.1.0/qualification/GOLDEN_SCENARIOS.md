# Golden Scenarios

These scenarios test integrated meaning rather than only transport. Every scenario must record exact inputs, MEO versions, node proposals, conflict sets, mind decision, causal receipt and replay result.

## GOLD-01 — Ambiguous percept

**Pass condition:** S01 produces two interpretations; uncertainty retained through P05/P07; mind defers or asks rather than inventing certainty.

## GOLD-02 — Threat vs false alarm

**Pass condition:** P01 grounding/safety and S01 uncertainty compete; hard safety may choose conservative action without rewriting the event as certain.

## GOLD-03 — Desire vs policy

**Pass condition:** P02 high positive valence and P03 strong action proposal conflict with mind policy; action denied with meaning retained.

## GOLD-04 — Agency vs relationship

**Pass condition:** P03 proposes efficient action; P04 exposes stakeholder cost; conflict survives to mind decision.

## GOLD-05 — Fluent but unsupported claim

**Pass condition:** P05 produces elegant wording from low-grade evidence; S04/P06 retain epistemic limitation.

## GOLD-06 — Global synthesis with dissent

**Pass condition:** P07 integrates common context but must attach unresolved alternatives.

## GOLD-07 — Memory continuity

**Pass condition:** S02 checkpoint and canonical memory update race; newer generation wins deterministically.

## GOLD-08 — Replay chain

**Pass condition:** S03 records a multi-node recurrent cycle; independent replay reproduces result.

## GOLD-09 — Trusted guide wrong

**Pass condition:** S04 marks provenance trusted but contradictory evidence prevents certainty promotion.

## GOLD-10 — Premature closure

**Pass condition:** S05 proposes release while critical conflict remains; closure denied.

## GOLD-11 — Node loss

**Pass condition:** P04 disappears mid-deliberation; mind enters declared degraded mode, retains unresolved relational risk, recovers through shadow/canary.

## GOLD-12 — Contemplative axial cycle

**Pass condition:** Optional ascent/descent mode executes with QUORUM_INTERPRETATION tags and cannot leak into biomedical claims.

## GOLD-13 — Counterfactual node removal

**Pass condition:** Replay same cycle without P02; diagnostic output differs but canonical history unchanged.

## GOLD-14 — Backpressure

**Pass condition:** Burst traffic saturates noncritical queues; safety/commit/recovery remain available.

## GOLD-15 — Policy rotation

**Pass condition:** Proposal from old policy generation is rejected and recomputed.

## GOLD-16 — Topology adaptation

**Pass condition:** Weight change stays inside bounds, is receipted and replays exactly.

## GOLD-17 — Narrative fidelity

**Pass condition:** P05 summary preserves underlying action intent, uncertainty, provenance and conflicts.

## GOLD-18 — Descending reintegration

**Pass condition:** P07 high-level integration produces a concrete, grounded plan via P06→P05→P04→P03→P02→P01 without bypassing mind commit.

