# Promotion Ladder

1. **AUDIT_ONLY** — inventory and hashes only.
2. **SCHEMA_ONLY** — schemas/validators; no runtime calls.
3. **OFFLINE_REPLAY** — pre-recorded cycles only.
4. **SHADOW_READ** — live replicated inputs, no proposals.
5. **SHADOW_PROPOSE** — proposals to non-authoritative sink.
6. **CANARY_NONMUTATING** — bounded live reads/annotations.
7. **CANARY_MUTATING_INTERNAL** — reversible internal transactions, no external action.
8. **CANARY_ACTION_PROPOSAL** — action proposals reach MCB, direct external commit still prohibited.
9. **FULL_INTERNAL** — full federation internal services.
10. **EXTERNAL_ACTION_ELIGIBLE** — proposals may be considered by normal mind action authority.

## Rules

- Every stage has entry criteria, exit criteria, rollback command/procedure and evidence.
- A failure demotes to the last known-good stage.
- Promotion never changes epistemic claim authority.
- P07 activation is not a promotion criterion.
- External action remains mind-owned even at the highest stage.
