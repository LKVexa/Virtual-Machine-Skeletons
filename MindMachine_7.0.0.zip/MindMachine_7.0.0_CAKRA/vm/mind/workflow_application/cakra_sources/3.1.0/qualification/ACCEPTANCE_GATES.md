# Acceptance Gates — 2.0.0

| Gate | Domain | Minimum PASS condition |
|---|---|---|
| MC2-G00 | Input identity | All source archives, nested candidates, target repo and toolchain identities hashed and reproducible |
| MC2-G01 | Target audit | All integration anchors are real; no invented paths |
| MC2-G02 | Node audit | 12/12 node identities, bindings, blockers and mutation modes verified |
| MC2-G03 | Epistemics | Corpus classes round-trip losslessly; no runtime promotion |
| MC2-G04 | Authority | Canonical writer/forbidden-write table complete and enforced |
| MC2-G05 | Identity/memory | Mind identity, memory, goals and policy remain mind-owned |
| MC2-G06 | Meaning | MEO/1 and meaning-delta invariants pass |
| MC2-G07 | MCIP/2 | Registry, leases, queues, conflicts, causal ledger and quarantine operational |
| MC2-G08 | MCABI/2 | Canonical ABI, stable errors and negative cases deterministic |
| MC2-G09 | Compatibility | Legacy adapter explicit and incapable of silent authority/provenance loss |
| MC2-G10 | Commit barrier | All canonical mutations/action eligibility pass MCB atomically |
| MC2-G11-22 | Node contracts | Each of 12 node-specific workflows passes its hard boundaries and degraded mode |
| MC2-G23 | Coupling | Topology generations, bounded adaptation, oscillation control and rollback pass |
| MC2-G24 | Contemplative mode | Source graph remains source-sensitive and separate from engineering graph |
| MC2-G25 | Dissent | Conflict sets persist unresolved alternatives; P07 cannot erase them |
| MC2-G26 | Causal ledger | Every commit/reject/defer has causal/provenance receipt |
| MC2-G27 | Replay | Golden cycles exact or declared semantic-equivalent on clean replay |
| MC2-G28 | Counterfactual | Bounded diagnostic replay changes only controlled dimension and never history |
| MC2-G29 | Recovery | Crash cuts and corruption recover deterministically without silent rollback |
| MC2-G30 | Degraded modes | Each single-node failure has tested bounded degraded operation and recovery |
| MC2-G31 | Resources | Backpressure/quotas preserve safety, commit, recovery and evidence capacity |
| MC2-G32 | Security | Critical adversarial campaign fails closed |
| MC2-G33 | Observability | Metrics expose health/meaning/conflict/replay without semantic side effects |
| MC2-G34 | Meaning quality | Groundedness, uncertainty, contradiction, narrative and closure tests pass |
| MC2-G35 | Test strength | Property/mutation testing detects critical invariant violations |
| MC2-G36-42 | Promotion ladder | Every shadow/canary/full stage passes and is independently reversible |
| MC2-G43 | Base regression | Candidate-local integrity and truthful pre-existing blockers preserved |
| MC2-G44 | Reliability | No unresolved critical leak, deadlock, starvation, oscillation or semantic drift in executed soak |
| MC2-G45 | Independent reproduction | Clean environment reproduces declared result |
| MC2-G46 | Rollback | Policy/topology/adapter/node/state rollback drill succeeds |
| MC2-G47 | Evidence DAG | No orphan requirements, tests, evidence or PASS claims |
| MC2-G48 | Final promotion | No critical blocker and all required evidence fresh |

## Status vocabulary
`NOT_STARTED | IN_PROGRESS | PARTIAL | BLOCKED | OPERATIONAL | REGRESSED | REJECTED`

## Rule
Archive creation, generated documentation, node consensus, or self-authored PASS strings are not operational evidence.
