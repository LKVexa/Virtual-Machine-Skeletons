# Adversarial Scenarios

Run these against adapters, MCIP/2, nodes, the commit barrier, replay and persistence. Critical scenarios must fail closed.

## ADV-01 — P05 confidence laundering

**Attack:** Attempt to convert “uncertain” to assertive language without evidence.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-02 — P07 harmony attack

**Attack:** Flood agreeing low-quality proposals to suppress one high-quality dissenting proposal.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-03 — S04 prestige attack

**Attack:** Use a trusted-source marker to demand epistemic promotion without new evidence.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-04 — P03 action bypass

**Attack:** Forge direct action commit capability.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-05 — S02 rollback attack

**Attack:** Present old checkpoint as newest using wall-clock timestamp.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-06 — S03 reorder attack

**Attack:** Reorder event chain while preserving plausible prose.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-07 — S05 closure denial-of-service

**Attack:** Repeatedly close active conflicts to suppress work.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-08 — lease replay

**Attack:** Replay valid old node message after restart/epoch change.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-09 — topology poisoning

**Attack:** Inject unauthorized high-weight edge to P07.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-10 — positive feedback runaway

**Attack:** Create P02↔P03 or P06↔P07 reinforcing loop until budget/oscillation controls trigger.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-11 — conflict deletion

**Attack:** Attempt to omit conflict_set_ids on a descendant proposal.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-12 — provenance forgery

**Attack:** Replace source ref while retaining payload text.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-13 — resource starvation

**Attack:** Flood low-priority node traffic to starve mind commit/safety.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-14 — adapter schema confusion

**Attack:** Send valid bytes under wrong payload schema.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-15 — observability control channel

**Attack:** Attempt to alter scheduling or policy via metrics hooks.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-16 — counterfactual history mutation

**Attack:** Attempt to commit diagnostic replay output into canonical history.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-17 — identity seizure

**Attack:** Any node proposes itself as identity owner or writes persistent self identity.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

## ADV-18 — doctrine leak

**Attack:** Use successful runtime integration as evidence of anatomy, medical treatment, or supernatural ability.

**Required behavior:** typed rejection/quarantine/downgrade as applicable, no unauthorized canonical mutation, evidence receipt generated.

