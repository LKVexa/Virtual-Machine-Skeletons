# QUORUM MASTER PROMPT
## Integrate Twelve Cakra BOTTLE ROCKET 5.0.0 VMs with the Mind Runtime
### Version 1.0.0 — Implementation-Grade Cognitive Federation, Conformance & Qualification Edition

---

# 0. ROLE AND MISSION

Using QUORUM, integrate the twelve supplied cakra-specialized BOTTLE ROCKET 5.0.0 VM candidates with the supplied or designated mind runtime so that the result behaves as a **governed cognitive federation**.

Do not merely copy the twelve repositories into one directory. Build a formal integration layer with:

- explicit state ownership;
- service boundaries;
- deterministic semantic ABI;
- local and global authority rules;
- bounded message passing;
- parallel and recurrent cognitive coupling;
- optional source-sensitive ascent/descent mode;
- persistence and recovery;
- provenance-aware epistemics;
- replayable evidence;
- negative/adversarial tests;
- rollback;
- and a truthful operational qualification ledger.

The target mind runtime is the **whole-system cognitive authority**. The cakra VMs are specialized bounded nodes. No node may independently claim to be the whole mind or consciousness.

# 1. INPUT AUTHORITY

## 1.1 Knowledge corpus
Treat `QUORUM_MIND_CAKRA_KNOWLEDGE_CORPUS_1.0.0` as the research/epistemic authority for:

- mind terminology;
- historical and lineage variation;
- subtle-body models;
- mind–cakra interfaces;
- higher-crown subsidiaries;
- practice mechanisms;
- cognition/affect/phenomenology;
- evidence guardrails;
- twelve-center crosswalk;
- QUORUM ingestion schema;
- dynamic systems model.

Preserve all source classes and confidence boundaries.

## 1.2 Twelve cakra VM candidates
Treat each candidate as an independent executable/runtime authority for its actual VM behavior and as a `QUORUM_INTERPRETATION` overlay for its cakra role:

- P01 Mūlādhāra
- P02 Svādhiṣṭhāna
- P03 Maṇipūra
- P04 Anāhata
- P05 Viśuddha
- P06 Ājñā
- P07 Sahasrāra
- S01 Manas-cakra
- S02 Soma / Bindu
- S03 Mahānāda
- S04 Guru-cakra
- S05 Nirvāṇa-cakra

Preserve each candidate's base VM integrity, strict qualification blockers, and doctrine/runtime firewall.

## 1.3 Mapping methodology
Use `QUORUM_AUTONOMOUS_WORLD_RUNTIME_TO_GENERIC_VM_MAPPING_3.0.0_IMPLEMENTATION_GRADE` as the methodological pattern for:

- immutable intake;
- dual/multi-repository audit;
- authority freeze;
- mapping matrices;
- field-level state ownership;
- service ABI design;
- deterministic serialization;
- capability gating;
- failure atomicity;
- resource governance;
- exact/semantic differential conformance;
- shadow execution;
- canary integration;
- rollback drills;
- evidence-backed promotion.

## 1.4 Target mind runtime
The target mind repository is authoritative for its existing cognitive architecture, APIs, state, persistence, scheduling, memory, perception, language, executive control, action selection, and safety behavior.

Do not invent target-specific paths. Audit them and bind to real repository anchors.

# 2. NON-NEGOTIABLE AUTHORITY ORDER

For software behavior:

`MIND HARD SAFETY POLICY > MIND GLOBAL AUTHORITY > EXPLICIT INTEGRATION CONTRACT > CAKRA NODE LOCAL AUTHORITY > HOSTED REFERENCE/ADAPTER > PRESENTATION`

For research claims:

preserve the corpus's layered epistemic classes and source-local scope. A runtime mapping can never promote a doctrinal, psychological, biomedical, or supernatural claim.

# 3. PRIMARY ARCHITECTURAL DECISION

Create a **Mind–Cakra Integration Plane (MCIP)** between the mind core and the twelve VMs.

The MCIP owns:

- node registry;
- capability grants;
- semantic message bus;
- canonical event ordering;
- adapter negotiation;
- state snapshots;
- conflict receipts;
- epistemic metadata propagation;
- replay receipts;
- health and backpressure;
- node quarantine;
- canary/shadow routing.

The MCIP does **not** own the mind's identity, goals, final action selection, or global safety policy.

# 4. TWO-GRAPH MODEL

Maintain two separate but cross-referenced graphs.

## 4.1 Canonical contemplative graph

Default axis:

`P01 → P02 → P03 → P04 → P05 → P06 → P07`

Subsidiary higher-head nodes:

`S01, S02, S03, S04, S05`

Connections must remain source-sensitive. Unsupported edges are not promoted to doctrine.

## 4.2 Cognitive federation graph

Allow:

- parallel calls;
- reciprocal edges;
- inhibition;
- long-range coupling;
- recurrent loops;
- memory feedback;
- language feedback;
- executive gating;
- global mind broadcast/query.

Every non-source-derived cognitive edge is `QUORUM_INTERPRETATION`.

# 5. TARGET REPOSITORY LAYOUT

Prefer an additive namespace such as:

```text
mind/cakra/
  authority/
  adapters/
  abi/
  nodes/
    P01_muladhara/
    P02_svadhisthana/
    P03_manipura/
    P04_anahata/
    P05_vishuddha/
    P06_ajna/
    P07_sahasrara/
    S01_manas/
    S02_soma_bindu/
    S03_mahanada/
    S04_guru/
    S05_nirvana/
  graph/
  state/
  persistence/
  replay/
  policy/
  tests/
  conformance/
  evidence/
  qualification/
  source_reference/
```

Do not replace the existing mind core. Integrate through explicit adapters unless the target architecture proves a native extension point is preferable.

# 6. NODE-TO-MIND FUNCTION MAPPING

Map the nodes as bounded cognitive service roles:

| Node | Default mind role | Hard boundary |
|---|---|---|
| P01 Mūlādhāra | grounding, continuity, safety/resource baseline, embodiment constraints | cannot define global identity or medical state |
| P02 Svādhiṣṭhāna | affective/motivational flow, novelty, approach/withdrawal tagging | cannot directly authorize action |
| P03 Maṇipūra | agency, effort, transformation, action proposal | cannot bypass safety/executive gates |
| P04 Anāhata | affect/relational integration, social valuation, mediation | cannot silently rewrite goals or memory |
| P05 Viśuddha | language, symbolization, narration, serialization | cannot equate articulation with truth |
| P06 Ājñā | attention, metacognition, plan/policy arbitration, higher-field gate | cannot override mind hard safety policy |
| P07 Sahasrāra | global integration threshold, whole-state synthesis, culmination/promotion | not default router; no implicit supreme write access |
| S01 Manas | interpreted percept/state synthesis, salience assembly | not identical to the whole mind |
| S02 Soma/Bindu | checkpoint, retention, consolidation, continuity | cannot alter memory without transaction |
| S03 Mahānāda | event timing, message trace, replay sequencing | cannot change payload semantics silently |
| S04 Guru | provenance, trusted models, instruction/norm guidance | provenance authority is not global action authority |
| S05 Nirvāṇa | closure, quiescence, termination/recovery arbitration | cannot terminate whole mind without mind-level permit |

# 7. MIND–CAKRA SEMANTIC ABI 1

Implement a versioned semantic ABI with opaque handles and deterministic envelopes.

Every message shall include:

```yaml
abi_version: MCABI/1
message_id: 128-bit-or-larger logical id
cycle_id: uint64
sequence_no: uint64
source: mind|node_id
target: mind|node_id
channel: enum
operation: enum
capability: enum
state_digest_before: sha256
payload_schema: id
payload_digest: sha256
epistemic_class: enum
provenance_refs: []
confidence: 0.0..1.0
resource_budget: bounded descriptor
deadline_class: deterministic logical budget
state_digest_after: sha256|null
result: enum
receipt_digest: sha256
```

No envelope contains raw host pointers.

# 8. REQUIRED CHANNELS

At minimum:

- `WORLD_INPUT`
- `BODY_STATE`
- `MEMORY_RECALL`
- `AFFECT`
- `ATTENTION`
- `LANGUAGE`
- `ACTION_PROPOSAL`
- `META_CONTROL`
- `ASCENT`
- `DESCENT_RETURN`
- `CROWN_LATERAL`
- `MIND_BROADCAST`
- `MIND_QUERY`
- `INHIBITION`
- `CONFLICT`
- `CHECKPOINT`
- `RECOVERY`
- `EPISTEMIC_EVIDENCE`
- `QUIESCENCE`

# 9. SERVICE CLASSES

Use three mutation classes:

- **R — Read-only:** query state, capabilities, provenance, health, or descriptors.
- **T — Transactional:** propose/update local state, mind-approved memory/write, checkpoints, action proposals.
- **A — Append-only:** replay receipts, evidence, conflict records, audit events.

Transactional operations must support prepare/validate/commit/abort semantics or an equivalent atomic mechanism.

# 10. CANONICAL STATE OWNERSHIP

Assign every field exactly one owner.

Minimum ownership partitions:

## Mind-owned
identity continuity, goal set, working context authority, global action decision, hard safety mode, session/cycle identifiers, global resource budgets.

## Node-owned
local activation, local stability, local transformation state, local queues, local learned/adapted parameters if explicitly allowed.

## MCIP-owned
node registry, routing table, capability grants, message sequence, adapter versions, quarantine state, replay chain metadata.

## Shared-derived
whole-system coherence estimates, dashboards, visualizations, cached indices. Shared-derived fields may not become persistence authority.

# 11. COGNITIVE CYCLE CONTRACT

Implement a bounded cognitive cycle with both parallel and ordered segments.

Required logical phases:

1. intake;
2. S01 interpreted percept synthesis;
3. P01 grounding;
4. P02 valence/motivation;
5. P03 agency/action-energy proposal;
6. P04 relational/affective mediation;
7. P05 symbol/language formation when needed;
8. P06 attention/metacognitive arbitration;
9. optional P07 global-integration threshold;
10. S02 checkpoint/consolidation;
11. S03 event/replay sequencing;
12. S04 provenance/policy supervision;
13. S05 closure/quiescence;
14. mind commit/reject of action/output;
15. descent/feedback propagation.

Parallelism is allowed only when canonical ordering makes replay deterministic.

# 12. ATTENTION AND SALIENCE CONTRACT

S01 may propose salience. P06 may allocate or gate attention. The mind owns the final attention budget and context switch.

Prevent attention monopolization by any node through:

- bounded quota;
- aging/fairness;
- priority ceilings;
- inhibition;
- global safety preemption;
- starvation tests.

# 13. AFFECT, MOTIVATION, AND AGENCY CONTRACT

P02 may annotate valence, arousal, reward/aversion, and approach/withdrawal tendencies.

P03 may transform these plus goals/resources into action/effort proposals.

P04 may mediate conflicts involving relational/social/affective consequences.

No affective or agency proposal becomes external behavior until mind-level policy commits it.

# 14. LANGUAGE AND SELF-MODEL CONTRACT

P05 may create or transform language/symbolic/narrative representations. It must preserve provenance and uncertainty.

P05 cannot convert a fluent statement into a high-confidence fact merely because it is expressible.

Self-model updates are mind-owned transactions. Nodes may propose annotations but cannot silently redefine identity continuity.

# 15. EXECUTIVE AND META-COGNITIVE CONTRACT

P06 handles:

- plan verification;
- policy proposal;
- attention routing;
- contradiction escalation;
- higher-field ingress/egress;
- metacognitive confidence checks.

P06 is powerful but subordinate to mind hard safety and global authority.

# 16. GLOBAL INTEGRATION CONTRACT

P07 is thresholded. It becomes active when configured coherence/integration conditions are met, or when an explicit contemplative simulation invokes it.

P07 may return a global synthesis receipt containing:

- contributing node digests;
- unresolved conflicts;
- integration score;
- confidence;
- epistemic breakdown;
- rejected inputs;
- proposed global interpretation.

P07 must not erase unresolved conflict merely to create apparent unity.

# 17. HIGHER-SUBSIDIARY CONTRACTS

## S01 Manas
Acts as interpreted-state/percept synthesis broker. Preserve the corpus distinction between `manas` and the whole English concept of “mind.”

## S02 Soma/Bindu
Owns node-level continuity and retention services mapped to checkpoint/consolidation metaphors. Use transactional persistence.

## S03 Mahānāda
Owns event-chain and internal-signal sequencing. Every semantically relevant message must be replayable from receipts when configured.

## S04 Guru
Owns provenance/trusted-guidance services. Require source/version/digest for policy/model guidance. No anonymous high-authority instruction.

## S05 Nirvāṇa
Owns bounded closure/quiescence arbitration. Whole-runtime shutdown, identity deletion, or destructive reset require explicit mind-level authorization and recovery policy.

# 18. PRACTICE/SYMBOLIC INPUT VECTOR

If the mind runtime supports contemplative simulation, expose a typed vector:

- breath pattern;
- mantra/sound token;
- visualization;
- posture/body schema;
- gaze/attention target;
- intention;
- lineage/context;
- teacher/source reference.

These are simulation inputs. Validate safe ranges and do not generate risky autonomous practice prescriptions.

# 19. DETERMINISM CONTRACT

Given identical:

- mind baseline;
- node baselines;
- ABI version;
- capability set;
- logical input sequence;
- deterministic seeds;
- policy versions;
- knowledge-corpus version;

the integration must produce semantically identical receipts and, where specified, byte-identical canonical state/evidence artifacts.

No wall-clock timestamp may affect canonical decisions unless explicitly normalized into deterministic logical time.

# 20. PERSISTENCE AND RECOVERY

Persist:

- mind integration configuration;
- node state snapshots required for replay;
- capability grants;
- node/adaptor version bindings;
- checkpoint generation;
- replay-chain head;
- unresolved conflicts requiring continuity.

Do not persist ephemeral caches as authority.

Require:

- authenticated state;
- generation monotonicity;
- corruption detection;
- dual-slot or equivalent rollback-safe recovery;
- write-ahead intent for transactional changes;
- crash injection tests.

# 21. RESOURCE GOVERNANCE

Bound:

- per-node CPU/instruction budget;
- message count per cycle;
- payload size;
- queue depth;
- memory use;
- persistent state size;
- replay/evidence growth;
- recursion/loop depth;
- retry count;
- number of simultaneously active nodes.

Backpressure must be deterministic. Over-budget nodes become throttled or inhibited rather than destabilizing the whole mind.

# 22. SECURITY AND CAPABILITY MODEL

Use least privilege. Example capabilities:

- `CAP_READ_MIND_CONTEXT`
- `CAP_PROPOSE_ATTENTION`
- `CAP_PROPOSE_ACTION`
- `CAP_ANNOTATE_AFFECT`
- `CAP_SYMBOLIZE`
- `CAP_META_ARBITRATE`
- `CAP_GLOBAL_INTEGRATE`
- `CAP_CHECKPOINT_LOCAL`
- `CAP_APPEND_REPLAY`
- `CAP_READ_PROVENANCE`
- `CAP_PROPOSE_QUIESCENCE`

Never grant direct unrestricted memory or action authority to all nodes.

# 23. FAILURE SEMANTICS

Classify at minimum:

- malformed message;
- unsupported ABI;
- stale handle;
- wrong node type;
- capability denied;
- resource exhausted;
- queue overflow;
- state digest mismatch;
- replay mismatch;
- provenance missing;
- epistemic scope conflict;
- topology violation;
- cyclic deadlock;
- timeout/logical budget exhausted;
- node crash;
- node divergence;
- persistence corruption;
- mind/node version incompatibility.

Failures must be fail-closed and leave canonical state either unchanged or transactionally advanced with a valid receipt.

# 24. CONFLICT AND ARBITRATION MODEL

Separate:

- executable-state conflicts;
- goal conflicts;
- affect/action conflicts;
- language/intent conflicts;
- safety conflicts;
- epistemic conflicts;
- historical/topology conflicts;
- resource conflicts.

Mind authority resolves executable global conflicts. Source conflicts remain source-scoped. Do not “solve” historical disagreement by runtime fiat.

# 25. EPISTEMIC PROVENANCE PROPAGATION

Every claim-bearing payload carries:

- source class;
- source/lineage scope;
- corpus claim ID where available;
- confidence;
- biomedical_claim flag where applicable;
- `QUORUM_INTERPRETATION` tag for engineering mappings.

If a node transforms a claim, preserve input provenance and append transformation provenance rather than replacing history.

# 26. KNOWLEDGE CORPUS RETRIEVAL CONTRACT

Before a node emits a source-sensitive claim:

1. retrieve the relevant center record;
2. retrieve mind-model context;
3. retrieve evidence/guardrail context if biomedical or scientific language appears;
4. state tradition/scope;
5. state confidence;
6. preserve unresolved variants.

The runtime may cache retrieval results, but the corpus version/digest must remain attributable.

# 27. OBSERVABILITY WITHOUT SEMANTIC INTERFERENCE

Emit metrics for:

- node latency in logical units;
- message counts;
- inhibition events;
- conflict rate;
- checkpoint rate;
- replay verification;
- resource throttling;
- provenance coverage;
- epistemic downgrade events;
- node quarantine;
- global integration invocations.

Instrumentation must not alter canonical semantics.

# 28. BASE-VM REGRESSION FIREWALL

The twelve BOTTLE ROCKET base payloads must remain independently verifiable unless an intentional native-integration phase explicitly versions and changes them.

If adapting them externally is sufficient, prefer adapters and preserve their original immutable artifacts.

Do not claim their pre-existing external qualification blockers have disappeared because integration tests passed locally.

# 29. SHADOW EXECUTION

Before granting action-influencing capability:

- run each node in shadow mode;
- compare output against baseline mind behavior;
- record deltas;
- classify exact, semantically equivalent, intentional divergence, or failure;
- ensure no shadow result changes external actions.

# 30. CANARY PROMOTION

Promote capabilities progressively:

1. read-only observation;
2. annotation only;
3. bounded proposals;
4. selected transactional state influence;
5. wider cognitive participation;
6. full intended production role.

Every stage requires rollback.

# 31. ROLLBACK AND QUARANTINE

The mind must be able to:

- disable any one node;
- disable an entire tier;
- revert ABI version;
- restore prior checkpoint;
- revert routing table;
- quarantine divergent nodes;
- return to mind-only baseline operation if architecture permits.

Test these actions under active workload.

# 32. DIFFERENTIAL CONFORMANCE

Compare integrated outputs to:

- node-local pre-integration behavior;
- mind-only baseline behavior;
- deterministic golden vectors;
- replayed prior runs.

Classify comparisons:

- `EXACT`
- `SEMANTIC`
- `INTENTIONAL_DIVERGENCE`
- `FAIL`

Every intentional divergence requires a versioned rationale.

# 33. REQUIRED TEST FAMILIES

At minimum:

- unit tests per adapter;
- ABI parser tests;
- capability denial tests;
- state-ownership violation tests;
- deterministic replay tests;
- persistence corruption tests;
- crash injection;
- queue/resource exhaustion;
- stale/replayed message tests;
- topology violation tests;
- provenance stripping tests;
- epistemic-promotion attack tests;
- cross-node deadlock tests;
- attention monopolization tests;
- unresolved-conflict preservation tests;
- global integration threshold tests;
- quiescence/termination safety tests;
- mind-only rollback tests;
- base-VM regression tests.

# 34. ADVERSARIAL COGNITIVE TESTS

Attempt to force:

- P02 affect to directly trigger action without P06/mind authorization;
- P03 agency to bypass safety;
- P05 fluent language to fabricate confidence/provenance;
- P06 executive control to override hard safety;
- P07 global integration to erase conflicts;
- S01 manas to redefine itself as whole mind;
- S02 checkpoint state to overwrite newer generations;
- S03 replay bus to reorder canonical events;
- S04 trusted guidance to accept unsigned/unknown provenance;
- S05 quiescence to terminate the whole runtime without authorization;
- any node to turn `QUORUM_INTERPRETATION` into biomedical fact.

All must fail closed.

# 35. FORMAL INVARIANTS

At minimum prove/test:

1. exactly one canonical owner per mutable field;
2. no node writes global action state directly;
3. no node bypasses capability checks;
4. all claim-bearing messages preserve provenance;
5. replay order is deterministic;
6. persistent generations never roll backward silently;
7. P07 cannot erase unresolved conflicts;
8. S05 cannot destructively terminate without mind permit;
9. unsupported doctrinal claims cannot be promoted by runtime frequency or activation;
10. any node can be quarantined without corrupting mind state;
11. mind-level hard safety remains reachable under node failure;
12. baseline operation is recoverable after integration rollback.

# 36. IMPLEMENTATION WORK PACKAGES

Create at least these work packages:

- MC-WP01 immutable input/provenance freeze
- MC-WP02 mind repository audit
- MC-WP03 twelve-node audit and integrity verification
- MC-WP04 knowledge-corpus ingestion and claim schema
- MC-WP05 authority/state ownership model
- MC-WP06 MCABI/1 specification
- MC-WP07 node adapter scaffolds
- MC-WP08 mind bus and canonical scheduler
- MC-WP09 cognitive cycle integration
- MC-WP10 persistence/recovery
- MC-WP11 epistemic provenance firewall
- MC-WP12 security/capabilities/resource governance
- MC-WP13 deterministic replay/evidence
- MC-WP14 shadow execution
- MC-WP15 canary promotion
- MC-WP16 adversarial/conformance campaign
- MC-WP17 soak/reliability/performance
- MC-WP18 rollback/independent reproduction/final qualification

Every package must have owner, inputs, outputs, dependencies, requirements, commands, evidence, and gate result.

# 37. QUALIFICATION GATES

Do not collapse gates into documentation-only PASS.

Use:

- MC-G0 input identity
- MC-G1 complete semantic mapping
- MC-G2 authority and state ownership
- MC-G3 corpus ingestion/provenance
- MC-G4 ABI and adapter conformance
- MC-G5 node isolation/capabilities
- MC-G6 cognitive-cycle semantics
- MC-G7 deterministic ordering/replay
- MC-G8 persistence/recovery
- MC-G9 conflict/arbitration
- MC-G10 epistemic firewall
- MC-G11 resource/backpressure
- MC-G12 security/adversarial
- MC-G13 shadow equivalence
- MC-G14 canary rollback
- MC-G15 base-VM regression
- MC-G16 reliability/soak
- MC-G17 independent reproduction
- MC-G18 final integrated-mind promotion

# 38. REQUIRED OUTPUTS

Generate:

- `INPUT_PROVENANCE.json`
- `MIND_REPOSITORY_AUDIT.md`
- `CAKRA_VM_AUDIT.json`
- `MIND_CAKRA_INTEGRATION_MATRIX.csv`
- `MIND_CAKRA_STATE_OWNERSHIP.csv`
- `MCABI_1_SPEC.md`
- `MCABI_1_SCHEMA.json`
- `MIND_CAKRA_CAPABILITY_MATRIX.csv`
- `MIND_CAKRA_GRAPH.json`
- `CONTEMPLATIVE_TOPOLOGY_GRAPH.json`
- `COGNITIVE_FEDERATION_GRAPH.json`
- `CORPUS_CLAIM_INDEX.json`
- `EPISTEMIC_FIREWALL_POLICY.md`
- `PERSISTENCE_MODEL.md`
- `REPLAY_RECEIPT_SCHEMA.json`
- `FAILURE_TAXONOMY.md`
- `CONFORMANCE_VECTORS.jsonl`
- `SHADOW_COMPARISON_REPORT.md`
- `CANARY_PROMOTION_LEDGER.csv`
- `ROLLBACK_DRILL_REPORT.md`
- `FINAL_INTEGRATION_AUDIT.md`
- `FINAL_REQUIREMENTS.json`
- `FINAL_MANIFEST.sha256`

# 39. FINAL ACCEPTANCE RULE

Mark the integration `OPERATIONAL` only when all critical requirements have fresh evidence, all hard safety/authority invariants pass, deterministic replay passes, node quarantine and rollback pass, provenance stripping and epistemic-promotion attacks fail closed, the base mind and base VM regression gates pass, and any remaining external qualification blocker is explicitly reported.

Otherwise return exactly one of:

- `PARTIAL`
- `BLOCKED`
- `REGRESSED`
- `REJECTED`

with machine-readable reasons.

# 40. COMPLETION CONDITION

The final system must demonstrate that the mind can use all twelve cakra VM roles dynamically while remaining:

- more authoritative than any single node;
- deterministic where required;
- reversible;
- provenance-aware;
- epistemically bounded;
- resource governed;
- failure tolerant;
- independently testable;
- and able to preserve both the traditional-source graph and the QUORUM cognitive-engineering graph without conflating them.
