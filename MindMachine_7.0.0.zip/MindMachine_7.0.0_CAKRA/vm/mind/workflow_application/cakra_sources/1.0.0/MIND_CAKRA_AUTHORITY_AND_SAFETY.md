# Mind–Cakra Authority and Safety Contract

## 1. Authority layers

Every knowledge-bearing or runtime-bearing assertion must carry one authority class:

- `PRIMARY_TEXT`
- `LINEAGE`
- `SCHOLARLY_HISTORY`
- `PHENOMENOLOGY`
- `PSYCHOLOGICAL_INTERPRETATION`
- `EMPIRICAL_ADJACENT`
- `DIRECT_CAKRA_RESEARCH`
- `MODERN_SYNTHESIS`
- `QUORUM_INTERPRETATION`
- `UNVERIFIED`

Runtime state may never promote a lower epistemic class into a stronger one.

## 2. Source authority order

Within a single claim scope, source-specific doctrine outranks a QUORUM engineering metaphor. Across incompatible scopes, preserve parallel variants rather than force a winner.

The VM's executable behavior is authoritative for what the VM does; it is not authoritative for what religious texts historically taught or what biology demonstrates.

## 3. Mind authority boundary

The target mind runtime owns:

- global cognitive cycle;
- final action authorization;
- whole-system resource scheduling;
- identity continuity;
- working context/session state;
- global conflict resolution policy;
- integration of world/body/memory inputs;
- external output selection;
- safety policy;
- whole-system checkpoint and recovery coordination.

A cakra VM may propose, transform, annotate, inhibit, or score state within its declared domain. It may not silently seize global authority.

## 4. Cakra node boundaries

Each cakra VM owns only its local service state and its declared transformations. Cross-node writes occur through the semantic ABI. No node writes another node's canonical memory directly.

## 5. Doctrine/runtime firewall

A runtime event such as `P06.THRESHOLD` or `P07.INTEGRATING` is not evidence of a literal subtle-body event in a human being.

No output may claim that:

- cakras are proven anatomical organs;
- cakra activation diagnoses disease;
- manipulating a cakra cures a medical or psychiatric condition;
- simulation states prove supernatural powers;
- a modern cognitive mapping is identical to a premodern tantric mapping.

## 6. Practice safety

The integration may represent practices as data or simulation inputs. It must not turn intense contemplative, breath-retention, fasting, sleep-deprivation, or other potentially risky practices into autonomous prescriptions for a user.

## 7. Fail-closed epistemics

If provenance is absent or scope conflicts, emit one of:

- `NOT_ESTABLISHED`
- `LINEAGE_SPECIFIC`
- `CONFLICT_UNRESOLVED`
- `NO_UNIVERSAL_ASSIGNMENT`
- `QUORUM_INTERPRETATION_ONLY`

## 8. Non-self-certification

The integrated system may generate evidence about its own software behavior, but release qualification requires independently reproducible commands and machine-readable results. A self-authored PASS label is not proof.
