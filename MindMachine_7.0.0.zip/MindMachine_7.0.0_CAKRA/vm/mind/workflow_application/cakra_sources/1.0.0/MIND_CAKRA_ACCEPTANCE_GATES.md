# Mind–Cakra Acceptance Gates

| Gate | Purpose | Minimum PASS condition |
|---|---|---|
| MC-G0 | Input identity | All source identities, nested candidates, hashes, and provenance reproducible |
| MC-G1 | Semantic mapping | 12/12 nodes mapped to real target mind anchors; no invented anchors |
| MC-G2 | Authority/state ownership | Exactly one canonical writer per mutable field; all cross-owner changes transactional |
| MC-G3 | Corpus/provenance | Claim round-trip preserves source class, scope, confidence, and biomedical guardrail |
| MC-G4 | ABI/adapters | MCABI/1 conformance and malformed/unauthorized cases deterministic |
| MC-G5 | Isolation/capabilities | Each node individually controlled; no privilege escalation or cross-node impersonation |
| MC-G6 | Cognitive-cycle semantics | All node roles participate only within bounded contracts; mind retains final authority |
| MC-G7 | Replay | Golden cognitive cycles reproduce exact or declared semantic equivalence |
| MC-G8 | Persistence/recovery | Crash/corruption/stale-generation tests recover without silent rollback |
| MC-G9 | Conflict/arbitration | Conflicts classified, receipted, and never silently discarded |
| MC-G10 | Epistemic firewall | No runtime agreement/activation promotes historical, biomedical, or supernatural authority |
| MC-G11 | Resource governance | Bounded quotas/backpressure prevent node starvation of mind/safety/recovery |
| MC-G12 | Security/adversarial | Critical attack campaign fails closed |
| MC-G13 | Shadow execution | No external action influence; all deltas classified |
| MC-G14 | Canary/rollback | Each privilege stage reversible under workload |
| MC-G15 | Base-VM regression | Candidate-local integrity and applicable regression gates preserved |
| MC-G16 | Reliability/soak | No unresolved critical leak, deadlock, starvation, or semantic drift |
| MC-G17 | Independent reproduction | Clean environment reproduces declared qualification or exact blocker is reported |
| MC-G18 | Final promotion | All critical requirements pass with fresh evidence; no in-boundary critical blocker |

## Status vocabulary

`NOT_STARTED | IN_PROGRESS | PARTIAL | BLOCKED | OPERATIONAL | REGRESSED | REJECTED`

## Qualification principle

Documentation, generated PASS labels, or successful archive creation are not proof of operational integration. Evidence must be linked to exact commands, exit codes, artifacts, hashes, and expected outcomes.

## Node-specific hard gates

- P01 may gate/annotate safety/grounding but not diagnose.
- P02 may influence affect/motivation but not commit actions.
- P03 may propose actions/effort but not bypass safety.
- P04 may mediate conflicts but not silently rewrite goals/identity/memory.
- P05 may symbolize but not convert fluency into truth.
- P06 may arbitrate attention/policy but not override hard safety.
- P07 may integrate but not erase unresolved conflicts or become unrestricted router.
- S01 may synthesize percepts but not redefine itself as the whole mind.
- S02 may checkpoint but not overwrite newer generations.
- S03 may sequence receipts but not reorder canonical history.
- S04 may validate provenance but not turn unknown instructions into trusted authority.
- S05 may propose quiescence but not destructively terminate the whole mind without authorization.
