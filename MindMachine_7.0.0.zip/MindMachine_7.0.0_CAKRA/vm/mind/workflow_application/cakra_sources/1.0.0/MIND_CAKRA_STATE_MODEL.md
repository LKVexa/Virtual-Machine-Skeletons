# Mind–Cakra Canonical State Model

## 1. Design objective

Represent mind–cakra interaction as a dynamic, recurrent system rather than a fixed ladder.

Let the whole-mind state be `M(t)` and the local state of node `i` be `C_i(t)`.

```text
C_i(t+1) = F_i(C_i(t), M(t), U(t), N_i(t), P_i(t), E_i(t))
M(t+1)   = G(M(t), {C_i(t+1)}, W(t), B(t), R(t), policy)
```

Where:

- `U(t)` = current world/body/sensory inputs;
- `N_i(t)` = messages from permitted neighboring or long-range nodes;
- `P_i(t)` = practice/symbolic input vector when enabled;
- `E_i(t)` = evidence/provenance context;
- `W(t)` = working-context state;
- `B(t)` = body/interoceptive model state;
- `R(t)` = retrieved memory;
- `policy` = mind-level safety and arbitration policy.

These equations are engineering abstractions.

## 2. Shared local state vector

Every node exposes the following bounded fields:

```yaml
node_state:
  activation: 0.0..1.0
  stability: 0.0..1.0
  attentional_gain: 0.0..1.0
  interoceptive_precision: 0.0..1.0
  affective_valence: -1.0..1.0
  arousal: 0.0..1.0
  symbolic_coherence: 0.0..1.0
  self_model_weight: 0.0..1.0
  transition_readiness: 0.0..1.0
  inhibition: 0.0..1.0
  confidence: 0.0..1.0
  epistemic_class: enum
  provenance_refs: []
  sequence_no: uint64
  state_digest: sha256
```

Traditional-model-only variables, such as prāṇa/wind state, may be carried separately with `interpretive_status: TRADITIONAL_MODEL_VARIABLE`; they must never masquerade as measured physiology.

## 3. Mind-owned state

```yaml
mind_state:
  cycle_id: uint64
  session_id: opaque_id
  current_goal_set: []
  working_context_digest: sha256
  identity_continuity_digest: sha256
  attention_budget: bounded_int
  action_budget: bounded_int
  conflict_set: []
  active_node_handles: []
  global_arousal_estimate: 0.0..1.0
  global_coherence_estimate: 0.0..1.0
  safety_mode: NORMAL|CONSERVATIVE|QUIESCENT|RECOVERY
  checkpoint_generation: uint64
  replay_chain_head: sha256
```

## 4. Node lifecycle

Every node may occupy:

`QUIESCENT, RECEIVING, INTEGRATING, TRANSMITTING, MODULATING, THRESHOLD, RETURNING, INHIBITED, CONFLICT`

Research lifecycle remains separate:

`UNRESOLVED, ATTESTED, VARIANT_MAPPED, TOPOLOGY_BOUND, INTERACTION_BOUND, VERIFIED, LOCKED, PARTIAL, BLOCKED`

## 5. Coupling classes

- `AXIAL_ASCENT`
- `DESCENT_RETURN`
- `RECIPROCAL`
- `INHIBITORY`
- `LONG_RANGE`
- `CROWN_LATERAL`
- `MIND_BROADCAST`
- `MIND_QUERY`
- `MEMORY_COUPLING`
- `LANGUAGE_COUPLING`
- `ACTION_COUPLING`

No coupling grants implicit write authority.

## 6. Default cognitive federation roles

### P01 Mūlādhāra
Embodiment baseline, continuity, threat/safety gating, grounding, resource floor, and state-validity constraints.

### P02 Svādhiṣṭhāna
Affective/motivational flow, reward-aversion dynamics, novelty, flexible transition, desire/approach-withdrawal tagging.

### P03 Maṇipūra
Agency, effort allocation, action preparation, transformation, execution-energy budgeting, goal pursuit.

### P04 Anāhata
Affect integration, relational/social valuation, conflict mediation, empathy/attachment modeling, bidirectional coordination.

### P05 Viśuddha
Language, narration, symbol formation, semantic serialization, communication, expression gating.

### P06 Ājñā
Attentional command, metacognitive supervision, policy gating, executive arbitration, plan verification, higher-field access control.

### P07 Sahasrāra
Whole-system integrative threshold, global synthesis, high-level coherence assessment, culmination state, and promotion boundary. It is not the routine message router.

### S01 Manas-cakra
Interpreted percept formation, sensory/state synthesis, salience assembly, environment awareness, short-horizon cognitive representation.

### S02 Soma / Bindu
Continuity, retention, checkpointing, consolidation, recovery substrate, low-volatility state preservation.

### S03 Mahānāda
Internal event signaling, temporal sequencing, instruction resonance, deterministic message trace, replay chain propagation.

### S04 Guru-cakra
Epistemic provenance, trusted models/instructions, norm and policy references, learning guidance, model-selection trust chain.

### S05 Nirvāṇa-cakra
Quiescence, closure, termination arbitration, obsolete-cycle release, recovery/exit boundary, clean completion.

All roles above are `QUORUM_INTERPRETATION` unless separately source-backed.

## 7. Cognitive cycle

A default bounded cycle is:

1. **Intake:** world/body/memory inputs enter the mind boundary.
2. **Percept synthesis:** S01 proposes an interpreted state.
3. **Grounding:** P01 validates continuity, safety, and resource floor.
4. **Valence/drive:** P02 tags affective and motivational implications.
5. **Agency:** P03 proposes effort/action potentials.
6. **Relational integration:** P04 mediates social, affective, and cross-node conflicts.
7. **Symbolization:** P05 forms language/symbolic representations when required.
8. **Executive arbitration:** P06 chooses attention, plan, and permitted higher-field routes.
9. **Global integration:** P07 may integrate when threshold conditions are met; otherwise remain quiescent.
10. **Memory continuity:** S02 checkpoints qualified state.
11. **Temporal/evidence trace:** S03 appends the replayable event chain.
12. **Epistemic supervision:** S04 checks provenance/policy on claims or learned guidance.
13. **Closure:** S05 suppresses completed/obsolete loops and coordinates quiescence.
14. **Mind decision:** mind authority commits or rejects external action/output.
15. **Return:** selected state is propagated through descent/feedback channels as needed.

Steps 2–13 may run partially in parallel subject to deterministic ordering rules.

## 8. Ascending and descending contemplative modes

The runtime may additionally execute a source-sensitive axial mode:

`P01 → P02 → P03 → P04 → P05 → P06 → P07`

and a reintegration mode:

`P07 → P06 → P05 → P04 → P03 → P02 → P01`

The higher subsidiaries are accessed only through source-supported or explicitly declared QUORUM policies, with P06 as default axial/higher-head gatekeeper.

## 9. Conflict arbitration

Conflicts are classified as:

- `STATE_CONFLICT`
- `GOAL_CONFLICT`
- `AFFECT_ACTION_CONFLICT`
- `LANGUAGE_INTENT_CONFLICT`
- `SAFETY_CONFLICT`
- `EPISTEMIC_CONFLICT`
- `TOPOLOGY_CONFLICT`
- `RESOURCE_CONFLICT`

Mind authority resolves executable conflicts. S04 resolves provenance priority only within its epistemic contract. P06 may recommend policy gating but may not override mind-level hard safety policy.
