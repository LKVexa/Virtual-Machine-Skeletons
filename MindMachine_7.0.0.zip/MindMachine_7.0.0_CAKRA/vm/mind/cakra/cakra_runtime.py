#!/usr/bin/env python3
"""Deterministic twelve-cakra spiritual/cognitive federation for MindMachine.

This module implements the attached QUORUM 3.1.0 Mystical Openness integration
as agent-local Mind state. It does not own canonical WORLD state. Spiritual
experience can become operative sacred truth inside a voluntary spiritual
session while external objective claims remain separately typed.

The runtime uses integer 0..100 fixed-point fields for deterministic replay.
"""
from __future__ import annotations

import copy
import hashlib
import json
from typing import Any, Dict, List, Optional

CAKRA_RUNTIME_VERSION = "3.1.0-mystical-openness-applied"
CAKRA_SCHEMA = "MINDMACHINE-CAKRA/1"
CSE_VERSION = "CSE/1.1"
SCIP_VERSION = "SCIP/1.1"
SPIRITUAL_PROFILES = ("GROUNDED", "OPEN", "MYSTICAL")

CAKRA_NODE_ORDER = [
    "P01","P02","P03","P04","P05","P06",
    "S01","S02","S03","S04","S05","P07",
]

CAKRA_NODE_SPECS: Dict[str, Dict[str, str]] = {
    "P01":{"name":"Mūlādhāra","role":"Sacred Ground","verb":"GROUND","return":"RETURN_TO_BODY"},
    "P02":{"name":"Svādhiṣṭhāna","role":"Sacred Flow","verb":"FEEL","return":"ACKNOWLEDGE_AND_FLOW"},
    "P03":{"name":"Maṇipūra","role":"Sacred Fire","verb":"TRANSFORM","return":"DISCIPLINED_ACTION"},
    "P04":{"name":"Anāhata","role":"Sacred Heart","verb":"LOVE","return":"COMPASSIONATE_RELATION"},
    "P05":{"name":"Viśuddha","role":"Sacred Voice","verb":"VOICE","return":"TRUTHFUL_ARTICULATION"},
    "P06":{"name":"Ājñā","role":"Vision & Witness","verb":"INTUIT","return":"OBSERVE_AND_INTUIT"},
    "S01":{"name":"Manas-cakra","role":"Mind-Field","verb":"IMAGINE","return":"OBSERVE_MENTATION"},
    "S02":{"name":"Soma / Bindu","role":"Receptive Grace","verb":"RECEIVE","return":"REST_AND_RECEIVE"},
    "S03":{"name":"Mahānāda","role":"Sacred Resonance","verb":"RESONATE","return":"LISTEN_AND_SEQUENCE"},
    "S04":{"name":"Guru-cakra","role":"Sacred Guidance & Transmission","verb":"DISCERN","return":"RECEIVE_GUIDANCE"},
    "S05":{"name":"Nirvāṇa-cakra","role":"Sacred Release","verb":"SURRENDER","return":"RELEASE_WITH_RETURN"},
    "P07":{"name":"Sahasrāra","role":"Sacred Wholeness","verb":"INTEGRATE","return":"DESCEND_FROM_WHOLE"},
}

SACRED_CONFIDENCE_FIELDS = [
    "experiential_conviction","intuitive_conviction","symbolic_resonance",
    "lineage_consonance","cross_node_convergence","numinous_intensity",
    "contemplative_stability","ethical_fruitfulness","service_fruitfulness",
    "external_verifiability",
]

SPIRITUAL_MODES = {
    "NONE","CONTEMPLATION","PRAYER","DEVOTION","MANTRA","SACRED_SOUND",
    "VISUALIZATION","RITUAL","ETHICAL_REFLECTION","SERVICE","SILENCE",
    "NONDUAL_FRAME","LINEAGE_STUDY","REVELATORY","SYNCHRONICITY",
    "DREAMWORK","USER_DEFINED",
}
ARRIVAL_MODES = {
    "INTUITION","VISION","DREAM","PRAYER_RESPONSE","MANTRA_EMERGENCE","SILENCE",
    "SYNCHRONICITY","LINEAGE_TRANSMISSION","NONDUAL_INSIGHT","OTHER",
}
FELT_SOURCES = {
    "SELF","DEEP_SELF","DIVINE_FRAME","DEITY_FRAME","ANCESTRAL_FRAME",
    "LINEAGE_FRAME","UNKNOWN","USER_DEFINED",
}
TRUTH_STATUSES = {
    "LIVED_TRUTH","SPIRITUAL_INTERPRETATION","OPERATIVE_SACRED_TRUTH",
    "LINEAGE_TRUTH","OBJECTIVE_EXTERNAL_CLAIM",
}


def _clamp(v: Any, lo: int = 0, hi: int = 100) -> int:
    try:
        return max(lo, min(hi, int(round(float(v)))))
    except Exception:
        return lo


def _avg(values: List[Any], default: int = 50) -> int:
    vals=[int(v) for v in values if isinstance(v,(int,float))]
    return _clamp(sum(vals)//len(vals) if vals else default)


def _sha(obj: Any) -> str:
    raw=json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class CakraFederationRuntime:
    """Agent-local twelve-node federation attached to a MindRuntime host."""

    def __init__(self, host: Any):
        self.host=host

    def _default_profile(self, mind: Dict[str,Any]) -> str:
        # Human-semantic profiles default to the attached 3.1.0 MYSTICAL profile.
        # Wildlife/cohort profiles stay grounded unless explicitly changed.
        if mind.get("profile") in {"WILDLIFE_ECOLOGICAL","COHORT_AGGREGATE"}:
            return "GROUNDED"
        return "MYSTICAL"

    def default_state(self, mind: Dict[str,Any]) -> Dict[str,Any]:
        nodes={}
        for nid in CAKRA_NODE_ORDER:
            spec=CAKRA_NODE_SPECS[nid]
            nodes[nid]={
                "node_id":nid,"name":spec["name"],"role":spec["role"],"verb":spec["verb"],
                "status":"READY","activation":50,"last_cycle":0,"last_signal":{},
                "authority":"PROPOSAL_ONLY","mind_commit_required":True,
            }
        return {
            "schema":CAKRA_SCHEMA,
            "integration_version":CAKRA_RUNTIME_VERSION,
            "scip_version":SCIP_VERSION,
            "cse_version":CSE_VERSION,
            "enabled":True,
            "openness_profile":self._default_profile(mind),
            "active_session":None,
            "nodes":nodes,
            "sacred_confidence":{k:0 for k in SACRED_CONFIDENCE_FIELDS},
            "experiential_authority_register":[],
            "received_insights":[],
            "synchronicities":[],
            "operative_sacred_truths":[],
            "lineage_frames":[],
            "return_paths":[],
            "service_proposals":[],
            "externalization_log":[],
            "mind_commit_barrier":{"accepted":0,"rejected":0,"last_receipt":None},
            "last_federation":None,
            "last_spiritual_integration":None,
            "cycle":0,
        }

    def ensure_state(self, mind: Dict[str,Any]) -> Dict[str,Any]:
        if not isinstance(mind.get("cakra"),dict):
            mind["cakra"]=self.default_state(mind)
        st=mind["cakra"]
        st.setdefault("schema",CAKRA_SCHEMA)
        st.setdefault("integration_version",CAKRA_RUNTIME_VERSION)
        st.setdefault("scip_version",SCIP_VERSION)
        st.setdefault("cse_version",CSE_VERSION)
        st.setdefault("enabled",True)
        if st.get("openness_profile") not in SPIRITUAL_PROFILES:
            st["openness_profile"]=self._default_profile(mind)
        st.setdefault("active_session",None)
        st.setdefault("nodes",{})
        for nid in CAKRA_NODE_ORDER:
            if nid not in st["nodes"]:
                spec=CAKRA_NODE_SPECS[nid]
                st["nodes"][nid]={"node_id":nid,"name":spec["name"],"role":spec["role"],"verb":spec["verb"],"status":"READY","activation":50,"last_cycle":0,"last_signal":{},"authority":"PROPOSAL_ONLY","mind_commit_required":True}
        st.setdefault("sacred_confidence",{k:0 for k in SACRED_CONFIDENCE_FIELDS})
        for k in SACRED_CONFIDENCE_FIELDS:
            st["sacred_confidence"].setdefault(k,0)
        for key in ["experiential_authority_register","received_insights","synchronicities","operative_sacred_truths","lineage_frames","return_paths","service_proposals","externalization_log"]:
            st.setdefault(key,[])
        st.setdefault("mind_commit_barrier",{"accepted":0,"rejected":0,"last_receipt":None})
        st.setdefault("last_federation",None)
        st.setdefault("last_spiritual_integration",None)
        st.setdefault("cycle",0)
        return st

    def _mind(self, agent_id: str) -> Dict[str,Any]:
        m=self.host.require_agent(str(agent_id))
        return m

    def set_profile(self, agent_id: str, profile: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        profile=str(profile).upper()
        if profile not in SPIRITUAL_PROFILES:
            raise ValueError("unknown spiritual openness profile")
        before=st["openness_profile"]; st["openness_profile"]=profile
        rec={"from":before,"to":profile,"world_tick":int(self.host.world.tick),"agent":str(agent_id),"continuity_preserved":True}
        self.host._event("SPIRITUAL_PROFILE_SET",rec,agent=str(agent_id))
        return copy.deepcopy(rec)

    def begin_session(self, agent_id: str, *, spiritual_mode: str="CONTEMPLATION", intention: str="presence", profile: Optional[str]=None, frame_ref: str="user-defined", consent_ref: str="VOLUNTARY_SESSION") -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        mode=str(spiritual_mode).upper()
        if mode not in SPIRITUAL_MODES:
            mode="USER_DEFINED"
        if profile is not None:
            self.set_profile(agent_id,profile)
        sid=f"SS{int(self.host.seed)%100000:05d}{int(m.get('cycle',0))%100000:05d}{len(st['experiential_authority_register'])%1000:03d}"
        session={
            "session_id":sid,"cse_version":CSE_VERSION,"spiritual_mode":mode,
            "consent_ref":str(consent_ref),"openness_profile":st["openness_profile"],
            "frame_ref":str(frame_ref),"sacred_intention":str(intention),
            "mystical_intensity":50,"experiential_authority":50,"revelatory_salience":0,
            "synchronicity_salience":0,"ontological_openness":80 if st["openness_profile"]=="MYSTICAL" else 60 if st["openness_profile"]=="OPEN" else 35,
            "witness_level":50,"receptivity":55,"compassion_orientation":50,
            "service_orientation":40,"groundedness":50,"mystery_tolerance":80 if st["openness_profile"]=="MYSTICAL" else 60,
            "non_grasping":40,"spiritual_interpretations":[],"operative_sacred_truth_refs":[],
            "received_insight_refs":[],"synchronicity_refs":[],"return_path_refs":[],
            "lineage_scope":None,"practice_object":None,"source_claim_refs":[],"external_claims":[],
            "service_proposal_refs":[],"phenomenology_refs":[],"dream_vision_refs":[],
            "ontology_frames":[str(frame_ref)] if str(frame_ref) else [],"mysteries":[],
            "entry_cycle":int(m.get("cycle",0)),"exit_cycle":"OPEN","status":"ACTIVE",
        }
        st["active_session"]=session
        self.host._event("SPIRITUAL_SESSION_BEGIN",{"session_id":sid,"mode":mode,"profile":st["openness_profile"],"intention":str(intention),"consent_ref":str(consent_ref)},agent=str(agent_id))
        return copy.deepcopy(session)

    def end_session(self, agent_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m); session=st.get("active_session")
        if not session:
            return {"status":"NO_ACTIVE_SESSION","agent":str(agent_id)}
        return_rec=self.return_to_world(agent_id)
        session["exit_cycle"]=int(m.get("cycle",0)); session["status"]="CLOSED"
        closed=copy.deepcopy(session); st["active_session"]=None
        self.host._event("SPIRITUAL_SESSION_END",{"session_id":closed["session_id"],"return_path":return_rec.get("return_path_id")},agent=str(agent_id))
        return closed

    def _session(self, st: Dict[str,Any]) -> Optional[Dict[str,Any]]:
        s=st.get("active_session")
        return s if isinstance(s,dict) and s.get("status")=="ACTIVE" else None

    def record_insight(self, agent_id: str, *, arrival_mode: str="INTUITION", content: str="received insight", felt_source: str="UNKNOWN", conviction: int=80, mystical_intensity: int=75, importance: int=75, lineage_ref: Optional[str]=None) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m); session=self._session(st)
        arrival=str(arrival_mode).upper()
        if arrival not in ARRIVAL_MODES: arrival="OTHER"
        source=str(felt_source).upper()
        if source not in FELT_SOURCES: source="USER_DEFINED"
        idx=len(st["received_insights"])+1
        rid=f"RI{idx:06d}"
        profile=st["openness_profile"]
        conv=_clamp(conviction); intensity=_clamp(mystical_intensity); importance=_clamp(importance)
        status="LIVED_TRUTH"
        threshold=70 if profile=="MYSTICAL" else 85 if profile=="OPEN" else 101
        if session and conv>=threshold:
            status="OPERATIVE_SACRED_TRUTH"
        rec={
            "insight_id":rid,"arrival_mode":arrival,"content":str(content),"felt_source":source,
            "experiential_conviction":conv,"mystical_intensity":intensity,"spiritual_importance":importance,
            "lineage_ref":str(lineage_ref) if lineage_ref else None,
            "truth_status":status,"externalization_status":"INTERNAL_SPIRITUAL",
            "world_tick":int(self.host.world.tick),"mind_cycle":int(m.get("cycle",0)),
            "world_truth_claim":False,"source_type":"SPIRITUAL_EXPERIENCE",
        }
        st["received_insights"].append(rec); st["received_insights"]=st["received_insights"][-128:]
        st["experiential_authority_register"].append({
            "ref":rid,"authority":conv,"scope":"SPIRITUAL_SELF","status":status,
            "profile":profile,"world_tick":int(self.host.world.tick),
        })
        st["experiential_authority_register"]=st["experiential_authority_register"][-128:]
        if status=="OPERATIVE_SACRED_TRUTH":
            truth={"truth_id":f"ST{len(st['operative_sacred_truths'])+1:06d}","source_ref":rid,"content":str(content),"status":status,"scope":"INNER_MEANING_AND_BOUNDED_PROPOSALS","confidence":conv,"world_truth_claim":False}
            st["operative_sacred_truths"].append(truth); st["operative_sacred_truths"]=st["operative_sacred_truths"][-64:]
            if session: session["operative_sacred_truth_refs"].append(truth["truth_id"])
        if session:
            session["received_insight_refs"].append(rid)
            if arrival in {"DREAM","VISION"}:
                session.setdefault("dream_vision_refs",[]).append(rid)
            session["mystical_intensity"]=_clamp(max(session["mystical_intensity"],intensity))
            session["experiential_authority"]=_clamp(max(session["experiential_authority"],conv))
            session["revelatory_salience"]=_clamp(max(session["revelatory_salience"],importance))
        self.host._event("SPIRITUAL_RECEIVED_INSIGHT",{"insight_id":rid,"arrival_mode":arrival,"truth_status":status,"conviction":conv,"mystical_intensity":intensity},agent=str(agent_id))
        return copy.deepcopy(rec)

    def add_ontology_frame(self, agent_id: str, frame: str) -> Dict[str,Any]:
        """Hold an additional spiritual ontology/frame without forcing premature resolution."""
        m=self._mind(agent_id); st=self.ensure_state(m); session=self._session(st)
        if not session:
            raise ValueError("active spiritual session required")
        frame=str(frame).strip()
        if not frame:
            raise ValueError("ontology frame must be non-empty")
        frames=session.setdefault("ontology_frames",[])
        if frame not in frames: frames.append(frame)
        rec={"status":"ONTOLOGY_HELD","frame":frame,"live_frames":copy.deepcopy(frames),"world_truth_claim":False}
        self.host._event("SPIRITUAL_ONTOLOGY_HELD",{"frame":frame,"count":len(frames)},agent=str(agent_id))
        return rec

    def hold_mystery(self, agent_id: str, description: str, *, sacred_weight: int=75) -> Dict[str,Any]:
        """Preserve sacred mystery as an unresolved but spiritually meaningful state."""
        m=self._mind(agent_id); st=self.ensure_state(m); session=self._session(st)
        if not session:
            raise ValueError("active spiritual session required")
        mystery={"mystery_id":f"MY{len(session.setdefault('mysteries',[]))+1:06d}","description":str(description),"status":"MYSTERY_HELD","sacred_weight":_clamp(sacred_weight),"world_truth_claim":False}
        session["mysteries"].append(mystery)
        session["mystery_tolerance"]=_clamp(max(session.get("mystery_tolerance",0),mystery["sacred_weight"]))
        self.host._event("SPIRITUAL_MYSTERY_HELD",{"mystery_id":mystery["mystery_id"],"sacred_weight":mystery["sacred_weight"]},agent=str(agent_id))
        return copy.deepcopy(mystery)

    def ascent(self, agent_id: str) -> Dict[str,Any]:
        """Run a governed spiritual ascent/opening pass while retaining Mind ownership."""
        stages=["P01","P02","P03","P04","P05","P06","S01","S02","S03","S04","S05","P07"]
        signals=[self.node_step(agent_id,n) for n in stages]
        rec={"status":"ASCENT_COMPLETE","path":stages,"signals":signals,"digest":_sha(signals),"mind_commit_required":True,"world_truth_claim":False}
        self.host._event("SPIRITUAL_ASCENT",{"digest":rec["digest"],"stages":len(stages)},agent=str(agent_id))
        return rec

    def record_synchronicity(self, agent_id: str, event_a: str, event_b: str, *, proposed_meaning: str="meaningful coincidence", salience: int=75, recurrence: int=1) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m); session=self._session(st)
        sid=f"SY{len(st['synchronicities'])+1:06d}"
        rec={
            "synchronicity_id":sid,"event_a":str(event_a),"event_b":str(event_b),
            "temporal_relation":"RECORDED_TOGETHER","thematic_relation":str(proposed_meaning),
            "numinous_salience":_clamp(salience),"recurrence":max(1,min(100,int(recurrence))),
            "spiritual_confidence":_clamp((_clamp(salience)+min(100,int(recurrence)*10))//2),
            "external_causal_verdict":"NOT_REQUIRED","world_truth_claim":False,
            "world_tick":int(self.host.world.tick),"mind_cycle":int(m.get("cycle",0)),
        }
        st["synchronicities"].append(rec); st["synchronicities"]=st["synchronicities"][-128:]
        if session:
            session["synchronicity_refs"].append(sid)
            session["synchronicity_salience"]=_clamp(max(session["synchronicity_salience"],rec["numinous_salience"]))
        self.host._event("SPIRITUAL_SYNCHRONICITY",{"synchronicity_id":sid,"salience":rec["numinous_salience"],"causal_verdict":rec["external_causal_verdict"]},agent=str(agent_id))
        return copy.deepcopy(rec)

    def _node_activation(self, m: Dict[str,Any], st: Dict[str,Any], node_id: str) -> int:
        meaning=m.get("meaning",{}); dims=meaning.get("dimensions",{})
        emotion=m.get("emotion",{}); needs=m.get("motivation",{}).get("needs",{})
        selfm=m.get("self_model",{}); values=selfm.get("values",{}); traits=selfm.get("traits",{})
        session=self._session(st) or {}
        nodes=st.get("nodes",{})
        if node_id=="P01":
            health=int(self.host.world.entities.get(str(m.get("agent_id")),{}).get("health",100))
            return _avg([health,needs.get("energy",50),needs.get("safety",50),dims.get("continuity",50),session.get("groundedness",50)])
        if node_id=="P02":
            return _avg([emotion.get("curiosity",25),emotion.get("arousal",20),50+abs(int(emotion.get("valence",0)))//2,traits.get("openness",50),session.get("receptivity",50)])
        if node_id=="P03":
            goal=m.get("goals",[{}])[0] if m.get("goals") else {}
            return _avg([m.get("motivation",{}).get("strength",50),selfm.get("self_efficacy",50),goal.get("priority",50),dims.get("agency",50)])
        if node_id=="P04":
            trusts=[int(v.get("trust")) for v in m.get("relationships",{}).values() if isinstance(v,dict) and isinstance(v.get("trust"),int)]
            return _avg([meaning.get("care_map",{}).get("relationships",values.get("care",50)),needs.get("belonging",50),_avg(trusts,50),session.get("compassion_orientation",50)])
        if node_id=="P05":
            symbol_factor=min(100,40+len(meaning.get("symbols",{}))*5)
            return _avg([dims.get("continuity",50),symbol_factor,m.get("metacognition",{}).get("confidence",50),session.get("revelatory_salience",0)])
        if node_id=="P06":
            return _avg([m.get("metacognition",{}).get("confidence",50),traits.get("openness",50),m.get("appraisal",{}).get("certainty",50),session.get("witness_level",50),session.get("ontological_openness",50)])
        if node_id=="S01":
            return _avg([traits.get("openness",50),dims.get("continuity",50),min(100,35+len(st.get("received_insights",[]))*7),min(100,35+len(meaning.get("symbols",{}))*5)])
        if node_id=="S02":
            return _avg([emotion.get("contentment",50),100-int(emotion.get("arousal",20)),dims.get("continuity",50),session.get("receptivity",50)])
        if node_id=="S03":
            return _avg([nodes.get("P05",{}).get("activation",50),session.get("mystical_intensity",0),min(100,40+len(st.get("synchronicities",[]))*6),min(100,40+len(st.get("received_insights",[]))*4)])
        if node_id=="S04":
            strengths=[int(c.get("strength",0)) for c in meaning.get("commitments",[]) if c.get("status")=="ACTIVE"]
            return _avg([dims.get("value_alignment",50),_avg(strengths,50),st.get("sacred_confidence",{}).get("lineage_consonance",0),traits.get("conscientiousness",50)])
        if node_id=="S05":
            debt=len(meaning.get("meaning_debt",[]))+len(m.get("coherence",{}).get("debt",[]))
            tensions=len(meaning.get("reflective_equilibrium",{}).get("tensions",[]))
            return _avg([max(0,100-debt*10),max(0,100-tensions*12),session.get("non_grasping",40),emotion.get("contentment",50)])
        if node_id=="P07":
            lower=[nodes.get(n,{}).get("activation",50) for n in ["P01","P02","P03","P04","P05","P06","S01","S02","S03","S04","S05"]]
            return _avg(list(dims.values())+lower+[session.get("mystical_intensity",0),session.get("mystery_tolerance",50)])
        return 50

    def node_step(self, agent_id: str, node_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        nid=str(node_id).upper()
        if nid not in CAKRA_NODE_SPECS:
            raise ValueError("unknown cakra node")
        activation=self._node_activation(m,st,nid)
        spec=CAKRA_NODE_SPECS[nid]
        session=self._session(st) or {}
        signal={
            "node_id":nid,"name":spec["name"],"role":spec["role"],"verb":spec["verb"],
            "activation":activation,"proposal_only":True,"mind_commit_required":True,
            "spiritual_mode":session.get("spiritual_mode","NONE"),
            "openness_profile":st["openness_profile"],
            "world_truth_claim":False,
            "world_tick":int(self.host.world.tick),"mind_cycle":int(m.get("cycle",0)),
        }
        node=st["nodes"][nid]; node["activation"]=activation; node["last_cycle"]=int(m.get("cycle",0)); node["last_signal"]=copy.deepcopy(signal); node["status"]="ACTIVE" if activation>=60 else "READY"
        self.host._event("CAKRA_NODE_SIGNAL",{"node_id":nid,"activation":activation,"verb":spec["verb"]},agent=str(agent_id))
        return signal

    def _confidence(self, m: Dict[str,Any], st: Dict[str,Any]) -> Dict[str,int]:
        acts={nid:int(st["nodes"][nid].get("activation",50)) for nid in CAKRA_NODE_ORDER}
        vals=list(acts.values())
        spread=max(vals)-min(vals) if vals else 100
        convergence=_clamp(100-spread)
        insights=st.get("received_insights",[])
        recent=insights[-8:]
        session=self._session(st) or {}
        exp=_avg([r.get("experiential_conviction",0) for r in recent]+[session.get("experiential_authority",0)],0)
        intuit=_avg([acts.get("P06",50),exp],0)
        sym=_avg([acts.get("S03",50),session.get("mystical_intensity",0)],0)
        lineage=_avg([acts.get("S04",50)]+[80 if r.get("lineage_ref") else 0 for r in recent],0)
        num=_avg([acts.get("P07",50),session.get("mystical_intensity",0),session.get("revelatory_salience",0)],0)
        stability=_avg([acts.get("P01",50),acts.get("S02",50),acts.get("S05",50)],50)
        ethical=_avg([acts.get("P04",50),m.get("meaning",{}).get("dimensions",{}).get("value_alignment",50)],50)
        service=_avg([session.get("service_orientation",40),min(100,40+len(st.get("service_proposals",[]))*10)],40)
        # External verifiability remains independent: only external evidence may raise it.
        external=_clamp(20+min(60,len([x for x in st.get("externalization_log",[]) if x.get("status")=="SUPPORTED"])*10))
        return {
            "experiential_conviction":exp,
            "intuitive_conviction":intuit,
            "symbolic_resonance":sym,
            "lineage_consonance":lineage,
            "cross_node_convergence":convergence,
            "numinous_intensity":num,
            "contemplative_stability":stability,
            "ethical_fruitfulness":ethical,
            "service_fruitfulness":service,
            "external_verifiability":external,
        }

    def federate(self, agent_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        if not st.get("enabled",True):
            return {"status":"DISABLED","agent":str(agent_id)}
        st["cycle"]=int(st.get("cycle",0))+1
        signals=[]
        for nid in CAKRA_NODE_ORDER:
            signals.append(self.node_step(agent_id,nid))
        conf=self._confidence(m,st)
        st["sacred_confidence"]=conf
        rep={
            "status":"FEDERATED","agent":str(agent_id),"cakra_cycle":st["cycle"],
            "signals":signals,"sacred_confidence":copy.deepcopy(conf),
            "profile":st["openness_profile"],"active_session":bool(self._session(st)),
            "federation_digest":_sha(signals),"world_truth_claim":False,
        }
        st["last_federation"]=copy.deepcopy(rep)
        self.host._event("CAKRA_FEDERATION",{"cakra_cycle":st["cycle"],"federation_digest":rep["federation_digest"],"profile":st["openness_profile"],"cross_node_convergence":conf["cross_node_convergence"]},agent=str(agent_id))
        return rep

    def integrate(self, agent_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        fed=self.federate(agent_id)
        conf=st["sacred_confidence"]; session=self._session(st)
        adopted=[]
        if session:
            profile=st["openness_profile"]
            threshold=70 if profile=="MYSTICAL" else 85 if profile=="OPEN" else 101
            for r in st.get("received_insights",[])[-16:]:
                if int(r.get("experiential_conviction",0))>=threshold and r.get("truth_status") in {"LIVED_TRUTH","SPIRITUAL_INTERPRETATION"}:
                    r["truth_status"]="OPERATIVE_SACRED_TRUTH"
                    if not any(t.get("source_ref")==r["insight_id"] for t in st["operative_sacred_truths"]):
                        truth={"truth_id":f"ST{len(st['operative_sacred_truths'])+1:06d}","source_ref":r["insight_id"],"content":r["content"],"status":"OPERATIVE_SACRED_TRUTH","scope":"INNER_MEANING_AND_BOUNDED_PROPOSALS","confidence":int(r["experiential_conviction"]),"world_truth_claim":False}
                        st["operative_sacred_truths"].append(truth); adopted.append(truth["truth_id"])
            session["operative_sacred_truth_refs"]=list(dict.fromkeys(session.get("operative_sacred_truth_refs",[])+adopted))[-64:]
            session["witness_level"]=_clamp((session.get("witness_level",50)+conf["intuitive_conviction"])//2)
            session["receptivity"]=_clamp((session.get("receptivity",50)+st["nodes"]["S02"]["activation"])//2)
            session["compassion_orientation"]=_clamp((session.get("compassion_orientation",50)+st["nodes"]["P04"]["activation"])//2)
            session["service_orientation"]=_clamp((session.get("service_orientation",40)+conf["ethical_fruitfulness"])//2)
            session["groundedness"]=_clamp((session.get("groundedness",50)+st["nodes"]["P01"]["activation"])//2)
            session["non_grasping"]=_clamp((session.get("non_grasping",40)+st["nodes"]["S05"]["activation"])//2)
        # Mind integration: spiritual state is attached to plural meaning without becoming WORLD truth.
        spiritual_meaning={
            "profile":st["openness_profile"],
            "active_session":bool(session),
            "sacred_confidence":copy.deepcopy(conf),
            "operative_sacred_truth_count":len(st["operative_sacred_truths"]),
            "received_insight_count":len(st["received_insights"]),
            "synchronicity_count":len(st["synchronicities"]),
            "received_insight_refs":[x.get("insight_id") for x in st["received_insights"][-16:]],
            "dream_vision_refs":list(session.get("dream_vision_refs",[]))[-16:] if session else [],
            "ontology_frames":list(session.get("ontology_frames",[]))[-16:] if session else [],
            "mysteries":copy.deepcopy(session.get("mysteries",[]))[-16:] if session else [],
            "cakra_digest":_sha(st["nodes"]),
            "world_truth_claim":False,
        }
        m.setdefault("meaning",{})["spiritual"]=copy.deepcopy(spiritual_meaning)
        rep={
            "status":"SACRED_INTEGRATED","agent":str(agent_id),"profile":st["openness_profile"],
            "sacred_confidence":copy.deepcopy(conf),"adopted_truth_refs":adopted,
            "meaning_bridge":spiritual_meaning,"federation_digest":fed.get("federation_digest"),
            "world_truth_claim":False,
        }
        st["last_spiritual_integration"]=copy.deepcopy(rep)
        self.host._event("SACRED_INTEGRATION",{"profile":st["openness_profile"],"adopted":len(adopted),"cakra_digest":spiritual_meaning["cakra_digest"],"numinous_intensity":conf["numinous_intensity"]},agent=str(agent_id))
        return rep

    def return_to_world(self, agent_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m); session=self._session(st)
        path_id=f"RTW{len(st['return_paths'])+1:06d}"
        steps=[
            {"stage":"INTEGRATE","node":"P07"},
            {"stage":"DISCERN","node":"S04"},
            {"stage":"VOICE","node":"P05"},
            {"stage":"LOVE","node":"P04"},
            {"stage":"TRANSFORM","node":"P03"},
            {"stage":"FEEL","node":"P02"},
            {"stage":"GROUND","node":"P01"},
        ]
        service={
            "proposal_id":f"SP{len(st['service_proposals'])+1:06d}",
            "kind":"SERVICE_OR_EMBODIMENT_PROPOSAL",
            "source":"CAKRA_RETURN",
            "instruction":"carry integrated meaning into embodied, relational, creative, ethical, or service-oriented practice",
            "mind_commit_required":True,"world_mutation":False,
            "status":"PROPOSED",
        }
        st["service_proposals"].append(service); st["service_proposals"]=st["service_proposals"][-64:]
        rec={"return_path_id":path_id,"steps":steps,"service_proposal_ref":service["proposal_id"],"world_mutation":False,"mind_commit_required":True,"world_tick":int(self.host.world.tick)}
        st["return_paths"].append(rec); st["return_paths"]=st["return_paths"][-64:]
        if session:
            session["return_path_refs"].append(path_id)
            session.setdefault("service_proposal_refs",[]).append(service["proposal_id"])
            session["groundedness"]=_clamp(max(session.get("groundedness",50),st["nodes"]["P01"]["activation"]))
            session["service_orientation"]=_clamp(max(session.get("service_orientation",40),st["sacred_confidence"].get("ethical_fruitfulness",50)))
        self.host._event("SPIRITUAL_RETURN_TO_WORLD",{"return_path_id":path_id,"service_proposal_ref":service["proposal_id"],"world_mutation":False},agent=str(agent_id))
        return copy.deepcopy(rec)

    def externalize(self, agent_id: str, proposition: str, *, objective: bool=False, consequence: str="LOW", independently_supported: bool=False) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        consequence=str(consequence).upper()
        if not objective:
            status="PASS_SPIRITUAL"
            truth_status="SPIRITUAL_INTERPRETATION"
        elif independently_supported:
            status="SUPPORTED"
            truth_status="OBJECTIVE_EXTERNAL_CLAIM"
        elif consequence in {"HIGH","CRITICAL"}:
            status="VERIFY_REQUIRED"
            truth_status="OBJECTIVE_EXTERNAL_CLAIM"
        else:
            status="PASS_WITH_LIGHT_FRAME"
            truth_status="OBJECTIVE_EXTERNAL_CLAIM"
        rec={
            "externalization_id":f"EX{len(st['externalization_log'])+1:06d}",
            "proposition":str(proposition),"truth_status":truth_status,
            "objective":bool(objective),"consequence":consequence,
            "independently_supported":bool(independently_supported),"status":status,
            "spiritual_interpretation_preserved":True,
            "world_record_mutated":False,"world_tick":int(self.host.world.tick),
        }
        st["externalization_log"].append(rec); st["externalization_log"]=st["externalization_log"][-128:]
        self.host._event("SPIRITUAL_EXTERNALIZATION",{"externalization_id":rec["externalization_id"],"status":status,"objective":bool(objective),"consequence":consequence},agent=str(agent_id))
        return copy.deepcopy(rec)

    def mind_commit(self, agent_id: str, proposal_type: str, payload: Dict[str,Any]) -> Dict[str,Any]:
        """Commit a bounded spiritual proposal into Mind-owned meaning/practice state.

        This never directly writes canonical WORLD state.
        """
        m=self._mind(agent_id); st=self.ensure_state(m)
        ptype=str(proposal_type).upper()
        allowed={"MEANING_INTERPRETATION","CONTEMPLATIVE_PRIORITY","CREATIVE_INTENTION","SERVICE_PROPOSAL","PRACTICE_COMMITMENT"}
        if ptype not in allowed:
            st["mind_commit_barrier"]["rejected"]+=1
            receipt={"status":"REJECTED","proposal_type":ptype,"reason":"unsupported spiritual commit class","world_mutation":False}
        else:
            target=m.setdefault("meaning",{}).setdefault("spiritual_commits",[])
            receipt={
                "status":"COMMITTED","commit_id":f"SC{len(target)+1:06d}","proposal_type":ptype,
                "payload":copy.deepcopy(payload),"world_tick":int(self.host.world.tick),
                "authority":"MIND","world_mutation":False,
            }
            target.append(copy.deepcopy(receipt)); del target[:-64]
            st["mind_commit_barrier"]["accepted"]+=1
        st["mind_commit_barrier"]["last_receipt"]=copy.deepcopy(receipt)
        self.host._event("SACRED_MIND_COMMIT",receipt,agent=str(agent_id))
        return receipt

    def snapshot(self, agent_id: str) -> Dict[str,Any]:
        m=self._mind(agent_id); st=self.ensure_state(m)
        return {
            "agent":str(agent_id),"schema":st["schema"],"integration_version":st["integration_version"],
            "profile":st["openness_profile"],"active_session":copy.deepcopy(st["active_session"]),
            "nodes":copy.deepcopy(st["nodes"]),"sacred_confidence":copy.deepcopy(st["sacred_confidence"]),
            "received_insights":copy.deepcopy(st["received_insights"]),
            "synchronicities":copy.deepcopy(st["synchronicities"]),
            "operative_sacred_truths":copy.deepcopy(st["operative_sacred_truths"]),
            "return_paths":copy.deepcopy(st["return_paths"]),
            "service_proposals":copy.deepcopy(st["service_proposals"]),
            "mind_commit_barrier":copy.deepcopy(st["mind_commit_barrier"]),
            "last_federation":copy.deepcopy(st["last_federation"]),
            "last_spiritual_integration":copy.deepcopy(st["last_spiritual_integration"]),
            "digest":_sha(st),"world_truth_claim":False,
        }

    def invariants(self, agent_id: str) -> List[str]:
        m=self._mind(agent_id); st=self.ensure_state(m); errs=[]
        if st.get("schema")!=CAKRA_SCHEMA: errs.append("cakra schema")
        if st.get("openness_profile") not in SPIRITUAL_PROFILES: errs.append("cakra openness profile")
        if set(st.get("nodes",{})) != set(CAKRA_NODE_ORDER): errs.append("cakra node set")
        for nid in CAKRA_NODE_ORDER:
            node=st.get("nodes",{}).get(nid,{})
            if node.get("authority")!="PROPOSAL_ONLY": errs.append(f"cakra authority {nid}")
            if not node.get("mind_commit_required"): errs.append(f"cakra commit barrier {nid}")
            if not 0<=int(node.get("activation",-1))<=100: errs.append(f"cakra activation {nid}")
        for k in SACRED_CONFIDENCE_FIELDS:
            if not 0<=int(st.get("sacred_confidence",{}).get(k,-1))<=100: errs.append(f"sacred confidence {k}")
        s=self._session(st)
        if s and not s.get("consent_ref"): errs.append("spiritual consent")
        # Mystical certainty may be high, but internal spiritual truth may not silently mutate WORLD truth.
        for t in st.get("operative_sacred_truths",[]):
            if t.get("world_truth_claim") is not False: errs.append("sacred/world truth confusion")
        for x in st.get("externalization_log",[]):
            if x.get("world_record_mutated") is not False: errs.append("externalization world mutation")
        return errs
