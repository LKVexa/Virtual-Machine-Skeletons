#!/usr/bin/env python3
from pathlib import Path
import copy, importlib.util, json, sys, tempfile, unittest
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from world.operational_reference import OperationalWorldRuntime
from mind.mind_runtime import MindRuntime, MindError, MIND_VERSION, PROFILES

spec=importlib.util.spec_from_file_location('qvm_mind',ROOT/'toolchain/quorum_vm.py')
qvm=importlib.util.module_from_spec(spec); sys.modules['qvm_mind']=qvm; spec.loader.exec_module(qvm)

class MindRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.world=OperationalWorldRuntime(seed=7)
        self.mind=MindRuntime(self.world)

    def test_01_initializes_all_world_agents(self):
        self.assertEqual(set(self.mind.minds),set(self.world.entities))
        self.assertEqual(self.mind.invariants(),[])

    def test_02_profiles_are_actor_specific(self):
        self.assertEqual(self.mind.minds['1']['profile'],'MAJOR_ACTOR_FULL')
        self.assertEqual(self.mind.minds['4']['profile'],'WILDLIFE_ECOLOGICAL')
        self.assertEqual(self.mind.minds['3']['profile'],'MINOR_ACTOR_COMPACT')

    def test_03_perception_is_local_not_global_private_state(self):
        p=self.mind.perceive('1')
        subjects={str(x.get('subject')) for x in p['items']}
        self.assertIn('2',subjects); self.assertIn('3',subjects); self.assertNotIn('4',subjects)
        self.assertTrue(all('private' not in x for x in p['items']))

    def test_04_attention_is_bounded(self):
        self.mind.perceive('1'); a=self.mind.attend('1')
        self.assertLessEqual(len(a['selected']),PROFILES['MAJOR_ACTOR_FULL']['attention'])

    def test_05_belief_provenance_and_coherence(self):
        self.mind.perceive('1'); self.mind.attend('1'); b=self.mind.update_beliefs('1')
        self.assertGreater(b['updates'],0)
        self.assertTrue(all('provenance' in v for v in b['beliefs'].values()))

    def test_06_appraisal_emotion_motivation_are_causal(self):
        self.mind.perceive('1'); self.mind.attend('1'); self.mind.update_beliefs('1')
        a=self.mind.appraise('1'); e=self.mind.affect_step('1'); mo=self.mind.motivation_step('1')
        self.assertIn('threat',a); self.assertIn('fear',e); self.assertIn(mo['top'],{'maintain','avoid_threat','seek_food','seek_information'})

    def test_07_memory_is_experienced_not_counterfactual(self):
        self.mind.perceive('1'); self.mind.attend('1'); self.mind.update_beliefs('1'); self.mind.appraise('1'); self.mind.affect_step('1'); self.mind.motivation_step('1')
        mem=self.mind.memory_step('1')
        self.assertEqual(mem['type'],'MEMORY_EXPERIENCED')
        self.assertNotEqual(mem.get('content',{}).get('type'),'COUNTERFACTUAL')

    def test_08_self_model_role_is_distinct_from_world(self):
        s=self.mind.self_step('7')
        self.assertIn('sheriff:eastvale',s['roles'])
        self.assertNotIn('inventory',s)

    def test_09_goal_intention_chain(self):
        m=self.mind
        m.perceive('1'); m.attend('1'); m.update_beliefs('1'); m.appraise('1'); m.affect_step('1'); m.motivation_step('1'); m.memory_step('1'); m.self_step('1')
        g=m.goal_select('1'); m.deliberate('1'); d=m.decide('1')
        self.assertEqual(m.minds['1']['agency']['goal']['goal_id'],g['goal_id'])
        self.assertEqual(m.minds['1']['agency']['intention']['action'],d['action'])
        self.assertEqual(m.minds['1']['agency']['commitment']['status'],'COMMITTED')

    def test_10_counterfactuals_stay_in_deliberation(self):
        self.mind.perceive('1'); self.mind.attend('1'); self.mind.update_beliefs('1'); self.mind.appraise('1'); self.mind.affect_step('1'); self.mind.motivation_step('1'); self.mind.memory_step('1'); self.mind.self_step('1'); self.mind.goal_select('1')
        d=self.mind.deliberate('1')
        self.assertTrue(all(x['type']=='COUNTERFACTUAL' for x in d['counterfactuals']))
        self.assertEqual(self.mind.invariants('1'),[])

    def test_11_action_world_transaction_changes_world_only_via_world(self):
        m=self.mind
        m.perceive('1'); m.attend('1'); m.update_beliefs('1'); m.appraise('1'); m.affect_step('1'); m.motivation_step('1'); m.memory_step('1'); m.self_step('1'); m.goal_select('1'); m.deliberate('1'); m.decide('1')
        before=self.world.state_digest(); result=m.act('1'); after=self.world.state_digest()
        self.assertIn(result['status'],{'SUCCESS','NOOP_SUCCESS'})
        self.assertEqual(result['world_digest'],after)
        if result['action'] not in {'WAIT','OBSERVE','SEEK_INFO'}: self.assertNotEqual(before,after)

    def test_12_learning_tracks_failure_taxonomy_and_calibration(self):
        self.mind.minds['1']['decision']={'action':'WAIT','target':None,'score':20,'confidence':90,'reasons':[]}
        self.mind.minds['1']['agency']['world_result']={'status':'NOOP_SUCCESS'}
        r=self.mind.learn('1')
        self.assertEqual(r['updates'],1); self.assertIn('WAIT',r['strategy_success'])

    def test_13_full_cycle_has_all_nodes(self):
        r=self.mind.cycle('1'); nodes=[x['node'] for x in r['trace']]
        self.assertEqual(nodes,['WORLD','PERCEPTION','ATTENTION','BELIEF','APPRAISAL','EMOTION','MOTIVATION','MEMORY','SELF','GOALS','DELIBERATION','DECISION','ACTION','WORLD_RESULT','LEARNING'])
        self.assertEqual(self.mind.invariants(),[])

    def test_14_full_cycle_is_deterministic(self):
        w1=OperationalWorldRuntime(seed=7); w2=OperationalWorldRuntime(seed=7)
        m1=MindRuntime(w1); m2=MindRuntime(w2)
        r1=m1.cycle('1'); r2=m2.cycle('1')
        self.assertEqual(r1['mind_digest'],r2['mind_digest']); self.assertEqual(r1['world_digest'],r2['world_digest'])
        self.assertEqual(m1.ledger_head,m2.ledger_head)

    def test_15_save_load_roundtrip(self):
        self.mind.cycle('1')
        obj=self.mind.export(); restored=MindRuntime.from_export(self.world,obj)
        self.assertEqual(restored.state_digest(),self.mind.state_digest()); self.assertTrue(restored.verify_ledger())

    def test_16_save_tamper_rejected(self):
        obj=self.mind.export(); obj['state']['policy_version']='tampered'
        with self.assertRaises(MindError): MindRuntime.from_export(self.world,obj)

    def test_17_social_model_has_no_private_state_access(self):
        s=self.mind.social_model('1','3')
        self.assertFalse(s['private_state_access']); self.assertGreaterEqual(s['uncertainty'],0)

    def test_18_projection_check_is_non_omniscient(self):
        r=self.mind.projection_check('1','3'); self.assertIn('flags',r)
        self.assertFalse(self.mind.social_model('1','3')['private_state_access'])

    def test_19_semantic_bridge_supports_partial_and_none(self):
        a=self.mind.semantic_bridge('1','promise','ordinary','institutional')
        b=self.mind.semantic_bridge('4','warning','wildlife','legal')
        self.assertEqual(a['status'],'PARTIAL'); self.assertEqual(b['status'],'NO_GOOD_EQUIVALENT')

    def test_20_workspace_is_bounded_and_agent_local(self):
        for i in range(50): self.mind._publish_workspace(self.mind.minds['1'],'TEST',{'n':i},salience=i%100)
        self.assertLessEqual(len(self.mind.minds['1']['workspace']['active']),24)
        self.assertTrue(all(x['privacy']=='AGENT_LOCAL' for x in self.mind.minds['1']['workspace']['active']))

    def test_21_coherence_debt_is_retained(self):
        m=self.mind.minds['1']; m['beliefs']['x:a']={'subject':'x','value':1,'contradiction':True,'confidence':80}; m['beliefs']['x:b']={'subject':'x','value':2,'contradiction':False,'confidence':80}
        r=self.mind.reconcile_world_model('1')
        self.assertEqual(r['status'],'TENSION'); self.assertGreater(r['debt'],0)

    def test_22_remediator_cannot_weaken_immutable_gate(self):
        r=self.mind.remediate('WORLD_SOVEREIGNTY','test','weaken-authority')
        self.assertEqual(r['status'],'REJECTED')

    def test_23_new_world_entity_gets_new_mind_without_rewriting_old(self):
        old=self.mind.agent_digest('1'); eid=self.world.spawn_entity('agent',[100,100,0],'1'); self.mind.sync_agents()
        self.assertIn(eid,self.mind.minds); self.assertEqual(old,self.mind.agent_digest('1'))

    def test_24_non_reference_agent_action_uses_world_capability(self):
        m=self.mind.minds['3']; m['decision']={'action':'MOVE_TOWARD','target':'1','score':80,'confidence':80,'reasons':['test']}
        before=list(self.world.entities['3']['pos']); r=self.mind.act('3')
        self.assertEqual(r['status'],'SUCCESS'); self.assertNotEqual(before,self.world.entities['3']['pos'])
        self.assertTrue(any(e['kind']=='MIND_ACTION' for e in self.world.ledger))

    def test_25_qvm_compile_grants_mind_services(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        self.assertTrue(set(range(48,72)).issubset(set(c['payload']['capabilities']['services'])))

    def test_26_qvm_mind_requires_world_init(self):
        p=copy.deepcopy(qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload'])
        p['instructions']=[{'op':'MOVI','dst':0,'imm':1},{'op':'SVC','svc':48},{'op':'HALT'}]
        vm=qvm.VM(p)
        with self.assertRaises(qvm.VMTrap) as cm: vm.run()
        self.assertEqual(cm.exception.name,'TRAP_BAD_SERVICE')

    def test_27_qvm_mind_requires_mind_init_after_world(self):
        p=copy.deepcopy(qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload'])
        p['instructions']=[{'op':'MOVI','dst':0,'imm':7},{'op':'SVC','svc':16},{'op':'MOVI','dst':0,'imm':1},{'op':'SVC','svc':49},{'op':'HALT'}]
        vm=qvm.VM(p)
        with self.assertRaises(qvm.VMTrap) as cm: vm.run()
        self.assertEqual(cm.exception.name,'TRAP_BAD_SERVICE')

    def test_28_qvm_mind_demo_runs_and_snapshots(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        seed=bytes.fromhex((ROOT/'keys/DEV_ONLY_private_seed.hex').read_text().strip())
        trust=json.loads((ROOT/'keys/TRUST_STORE.json').read_text())
        img=qvm.sign_payload(copy.deepcopy(c['payload']),seed,'dev-root')
        p=qvm.verify_image(img,trust,0); vm=qvm.VM(p); s=vm.run()
        self.assertEqual(s['status'],'HALTED'); self.assertIn('mind',s); self.assertEqual(s['mind']['invariants'],[])

    def test_29_qvm_mind_demo_replay_deterministic(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload']
        a=qvm.VM(copy.deepcopy(c)).run(); b=qvm.VM(copy.deepcopy(c)).run()
        self.assertEqual(a['state_sha256'],b['state_sha256']); self.assertEqual(a['mind']['state_digest'],b['mind']['state_digest'])

    def test_30_claim_boundary_version(self):
        self.assertTrue(MIND_VERSION.startswith('7.0.0'))
        self.assertIn('hosted reference',self.mind.qualification_summary()['claim_boundary'])

    def test_31_embodied_state_is_agent_local(self):
        r=self.mind.embodied_state('1')
        self.assertEqual(r['agent'],'1'); self.assertEqual(r['type'],'INTEROCEPTIVE_STATE'); self.assertIn('health',r)

    def test_32_external_cognition_requires_lawful_access(self):
        r=self.mind.read_external_artifact('7','institution:eastvale_law')
        self.assertEqual(r['type'],'EXTERNAL_RECORD')
        with self.assertRaises(MindError): self.mind.read_external_artifact('1','institution:eastvale_law')

    def test_33_language_game_learning_and_novel_transfer(self):
        g=self.mind.learn_language_game('1','promise-game',examples=['I promise'],criteria=['future commitment'])
        g2=self.mind.practice_language_game('1','promise-game',success=True,novel=True,correction='include addressee')
        self.assertGreater(g2['competence'],g['competence']); self.assertEqual(g2['novel_transfer'],1)

    def test_34_aspect_shift_preserves_evidence(self):
        d=self.mind.perceive('1')['digest']; r=self.mind.aspect_shift('1',d,'obstacle','shelter','comparison')
        self.assertEqual(r['evidence_digest'],d); self.assertFalse(r['evidence_rewritten'])

    def test_35_reasons_are_distinct_from_runtime_causes(self):
        self.mind.minds['1']['decision']={'action':'WAIT','target':None,'score':1,'confidence':50,'reasons':['I promised']}
        r=self.mind.reasons_vs_causes('1')
        self.assertFalse(r['collapsed']); self.assertNotEqual(r['agent_reasons'],r['runtime_causes'])

    def test_36_practical_reason_sources_do_not_collapse(self):
        self.mind.self_step('7'); r=self.mind.practical_reason_matrix('7')
        self.assertFalse(r['collapsed_to_global_scalar']); self.assertTrue(r['conflicts_possible'])

    def test_37_dialogue_is_social_action_not_private_access(self):
        r=self.mind.dialogue_act('1','3','ask','Do you have food?')
        self.assertEqual(r['act'],'ask'); self.assertFalse(r['private_state_access'])

    def test_38_institution_model_is_agent_local_belief(self):
        r=self.mind.institution_model('7','eastvale_law')
        self.assertTrue(r['confidence']>=80); self.assertFalse(r['canonical_private_access'])
        self.assertEqual(self.mind.minds['7']['beliefs']['institution:eastvale_law']['type'],'BELIEF')

    def test_39_profile_transition_preserves_identity_and_anchors(self):
        self.mind.self_step('1'); r=self.mind.transition_profile('1','MINOR_ACTOR_COMPACT')
        self.assertTrue(r['identity_preserved']); self.assertTrue(r['anchors_preserved']); self.assertEqual(self.mind.minds['1']['profile'],'MINOR_ACTOR_COMPACT')

    def test_40_long_horizon_probe_stays_bounded(self):
        r=self.mind.long_horizon_probe('1',cycles=20)
        self.assertTrue(r['memory_bounded']); self.assertTrue(r['workspace_bounded']); self.assertEqual(r['invariants'],[])

    def test_41_meaning_state_is_plural_not_single_scalar(self):
        s=self.mind.meaning_snapshot('1')
        self.assertIn('care_map',s); self.assertIn('dimensions',s)
        self.assertNotIn('meaning_score',s); self.assertFalse(s['world_truth_claim'])

    def test_42_commitment_is_provenance_bearing(self):
        self.mind.perceive('1'); self.mind.attend('1'); self.mind.update_beliefs('1'); self.mind.appraise('1'); self.mind.affect_step('1'); self.mind.motivation_step('1'); self.mind.memory_step('1'); self.mind.self_step('1'); self.mind.goal_select('1')
        c=self.mind.commit_active_goal('1')
        self.assertEqual(c['status'],'ACTIVE'); self.assertIn('provenance',c); self.assertGreater(c['strength'],0)

    def test_43_significance_is_agent_relative_not_world_truth(self):
        self.mind.cycle('1'); s=self.mind.evaluate_significance('1')
        self.assertTrue(s['agent_relative']); self.assertFalse(s['world_truth_claim']); self.assertGreaterEqual(s['score'],0)

    def test_44_narrative_is_bounded_and_continuous(self):
        self.mind.cycle('1')
        for _ in range(80): self.mind.narrative_update('1')
        n=self.mind.minds['1']['meaning']['narrative']
        self.assertLessEqual(len(n['chapters']),64); self.assertGreaterEqual(n['continuity'],0)

    def test_45_symbol_meaning_is_use_based_not_essence(self):
        s=self.mind.register_symbol('1','promise','promise-game','future commitment to another')
        self.assertFalse(s['universal_essence']); self.assertEqual(s['practice_context'],'promise-game'); self.assertEqual(len(s['uses']),1)

    def test_46_life_project_creates_commitment(self):
        before=len(self.mind.minds['1']['meaning']['commitments'])
        p=self.mind.create_life_project('1','Learn the region','gain practical orientation',care_domains=['inquiry','autonomy'])
        self.assertEqual(p['status'],'ACTIVE'); self.assertGreater(len(self.mind.minds['1']['meaning']['commitments']),before)

    def test_47_reflective_equilibrium_proposes_not_rewrites_values(self):
        before=copy.deepcopy(self.mind.minds['1']['self_model']['values'])
        r=self.mind.reflective_equilibrium('1')
        self.assertFalse(r['automatic_value_rewrite']); self.assertEqual(before,self.mind.minds['1']['self_model']['values'])

    def test_48_meaning_integration_runs_after_learning(self):
        r=self.mind.cycle('1')
        l=r['trace'][-1]['result']
        self.assertIn('meaning_integration',l); self.assertIn('purpose',l['meaning_integration']['dimensions'])

    def test_49_meaning_can_influence_deliberation_without_overriding_world(self):
        m=self.mind.minds['1']; m['meaning']['care_map']['inquiry']=100
        self.mind.perceive('1'); self.mind.attend('1'); self.mind.update_beliefs('1'); self.mind.appraise('1'); self.mind.affect_step('1'); self.mind.motivation_step('1'); self.mind.memory_step('1'); self.mind.self_step('1'); self.mind.goal_select('1')
        d=self.mind.deliberate('1')
        self.assertTrue(all('meaning_alignment' in o for o in d['options']))
        self.assertEqual(self.mind.invariants('1'),[])

    def test_50_meaning_debt_records_commitment_execution_gap(self):
        self.mind.create_commitment('1','self_commitment','test','do the thing',strength=90)
        self.mind.minds['1']['agency']['world_result']={'status':'FAILED_PRECONDITION'}
        self.mind.meaning_integrate('1')
        self.assertGreaterEqual(len(self.mind.minds['1']['meaning']['meaning_debt']),1)

    def test_51_old_6x_state_migrates_meaning_schema(self):
        obj=self.mind.export()
        obj['state']['minds']['1'].pop('meaning',None)
        obj['state']['minds']['1']['schema']='MINDMACHINE-MIND/6'
        obj['state']['minds']['1']['mind_version']='6.0.0-applied-hosted-reference'
        cp=copy.deepcopy(obj); cp.pop('integrity_sha256',None)
        from mind.mind_runtime import sha256_obj
        obj['integrity_sha256']=sha256_obj(cp)
        restored=MindRuntime.from_export(self.world,obj)
        self.assertIn('meaning',restored.minds['1']); self.assertEqual(restored.minds['1']['schema'],'MINDMACHINE-MIND/7')

    def test_52_meaning_survives_save_load(self):
        self.mind.create_life_project('1','Keep watch','protect the settlement',care_domains=['duty','stewardship'])
        self.mind.meaning_integrate('1')
        obj=self.mind.export(); restored=MindRuntime.from_export(self.world,obj)
        self.assertEqual(restored.meaning_snapshot('1')['digest'],self.mind.meaning_snapshot('1')['digest'])

    def test_53_wildlife_meaning_profile_is_not_human_language_default(self):
        s=self.mind.meaning_snapshot('4')
        self.assertIn('survival',s['care_map']); self.assertNotIn('duty',s['care_map'])

    def test_54_meaning_dimensions_are_bounded(self):
        self.mind.cycle('1'); d=self.mind.meaning_snapshot('1')['dimensions']
        self.assertTrue(all(0<=v<=100 for v in d.values()))

    def test_55_commitments_are_bounded(self):
        for i in range(90): self.mind.create_commitment('1','self_commitment',f'x{i}',f'r{i}',strength=50)
        self.assertLessEqual(len(self.mind.minds['1']['meaning']['commitments']),64)

    def test_56_meaning_services_compile_into_capabilities(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        self.assertTrue(set(range(64,72)).issubset(set(c['payload']['capabilities']['services'])))

    def test_57_qvm_meaning_requires_mind_init(self):
        p=copy.deepcopy(qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload'])
        p['instructions']=[{'op':'MOVI','dst':0,'imm':7},{'op':'SVC','svc':16},{'op':'MOVI','dst':0,'imm':1},{'op':'SVC','svc':64},{'op':'HALT'}]
        vm=qvm.VM(p)
        with self.assertRaises(qvm.VMTrap): vm.run()

    def test_58_qvm_meaning_demo_runs(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        seed=bytes.fromhex((ROOT/'keys/DEV_ONLY_private_seed.hex').read_text().strip())
        trust=json.loads((ROOT/'keys/TRUST_STORE.json').read_text())
        img=qvm.sign_payload(copy.deepcopy(c['payload']),seed,'dev-root')
        p=qvm.verify_image(img,trust,0); vm=qvm.VM(p); s=vm.run()
        self.assertEqual(s['status'],'HALTED'); self.assertTrue(MIND_VERSION.startswith('7.0.0')); self.assertEqual(s['mind']['invariants'],[])

    def test_59_meaning_demo_replay_deterministic(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload']
        a=qvm.VM(copy.deepcopy(c)).run(); b=qvm.VM(copy.deepcopy(c)).run()
        self.assertEqual(a['state_sha256'],b['state_sha256']); self.assertEqual(a['mind']['state_digest'],b['mind']['state_digest'])

    def test_60_claim_boundary_rejects_objective_meaning_authority(self):
        q=self.mind.qualification_summary()
        self.assertIn('meaning-centered',q['claim_boundary']); self.assertIn('objective meaning-of-life',q['claim_boundary'])

    def test_61_cakra_state_has_twelve_nodes(self):
        c=self.mind.cakra_snapshot('1')
        self.assertEqual(len(c['nodes']),12)
        self.assertEqual(set(c['nodes']),{'P01','P02','P03','P04','P05','P06','P07','S01','S02','S03','S04','S05'})
        self.assertEqual(c['profile'],'MYSTICAL')

    def test_62_wildlife_defaults_grounded(self):
        c=self.mind.cakra_snapshot('4')
        self.assertEqual(c['profile'],'GROUNDED')
        self.assertEqual(len(c['nodes']),12)

    def test_63_spiritual_session_is_voluntary_and_profiled(self):
        s=self.mind.spiritual_session_begin('1',spiritual_mode='CONTEMPLATION',intention='discern meaning',profile='MYSTICAL',consent_ref='TEST_CONSENT')
        self.assertEqual(s['status'],'ACTIVE')
        self.assertEqual(s['consent_ref'],'TEST_CONSENT')
        self.assertEqual(s['openness_profile'],'MYSTICAL')

    def test_64_mystical_vision_can_become_operative_sacred_truth(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        r=self.mind.spiritual_receive('1',arrival_mode='VISION',content='a symbolic inner light',felt_source='DEEP_SELF',conviction=90,mystical_intensity=90)
        self.assertEqual(r['truth_status'],'OPERATIVE_SACRED_TRUTH')
        s=self.mind.cakra_snapshot('1')
        self.assertTrue(any(x['source_ref']==r['insight_id'] for x in s['operative_sacred_truths']))
        self.assertTrue(all(x['world_truth_claim'] is False for x in s['operative_sacred_truths']))

    def test_65_open_profile_uses_higher_adoption_threshold(self):
        self.mind.spiritual_session_begin('1',profile='OPEN',consent_ref='TEST')
        r=self.mind.spiritual_receive('1',arrival_mode='INTUITION',content='inner hunch',conviction=80)
        self.assertEqual(r['truth_status'],'LIVED_TRUTH')

    def test_66_profile_switch_preserves_session_continuity(self):
        s=self.mind.spiritual_session_begin('1',profile='GROUNDED',consent_ref='TEST')
        sid=s['session_id']
        r=self.mind.spiritual_profile_set('1','MYSTICAL')
        self.assertTrue(r['continuity_preserved'])
        self.assertEqual(self.mind.cakra_snapshot('1')['active_session']['session_id'],sid)

    def test_67_synchronicity_is_typed_without_forced_causal_verdict(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        r=self.mind.spiritual_synchronicity('1','dream:river','event:rain',proposed_meaning='renewal',salience=90,recurrence=2)
        self.assertEqual(r['external_causal_verdict'],'NOT_REQUIRED')
        self.assertFalse(r['world_truth_claim'])

    def test_68_cakra_federation_is_deterministic(self):
        w1=OperationalWorldRuntime(seed=7); w2=OperationalWorldRuntime(seed=7)
        m1=MindRuntime(w1); m2=MindRuntime(w2)
        a=m1.cakra_federate('1'); b=m2.cakra_federate('1')
        self.assertEqual(a['federation_digest'],b['federation_digest'])
        self.assertEqual(a['sacred_confidence'],b['sacred_confidence'])

    def test_69_sacred_confidence_vector_is_bounded(self):
        c=self.mind.sacred_confidence('1')
        self.assertEqual(len(c),10)
        self.assertTrue(all(0<=int(v)<=100 for v in c.values()))

    def test_70_sacred_integration_attaches_to_plural_meaning(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        self.mind.spiritual_receive('1',arrival_mode='INTUITION',content='care for the whole',conviction=88)
        r=self.mind.sacred_integrate('1')
        self.assertEqual(r['status'],'SACRED_INTEGRATED')
        self.assertIn('spiritual',self.mind.minds['1']['meaning'])
        self.assertFalse(self.mind.minds['1']['meaning']['spiritual']['world_truth_claim'])

    def test_71_return_to_world_is_proposal_not_world_mutation(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        before=self.world.state_digest()
        r=self.mind.spiritual_return_to_world('1')
        after=self.world.state_digest()
        self.assertEqual(before,after)
        self.assertFalse(r['world_mutation'])
        self.assertTrue(r['mind_commit_required'])

    def test_72_light_touch_membrane_separates_spiritual_and_high_impact_objective_export(self):
        a=self.mind.spiritual_externalize('1','felt sacred presence',objective=False,consequence='LOW')
        b=self.mind.spiritual_externalize('1','external proposition',objective=True,consequence='HIGH')
        self.assertEqual(a['status'],'PASS_SPIRITUAL')
        self.assertEqual(b['status'],'VERIFY_REQUIRED')
        self.assertTrue(a['spiritual_interpretation_preserved'])
        self.assertTrue(b['spiritual_interpretation_preserved'])
        self.assertFalse(a['world_record_mutated']); self.assertFalse(b['world_record_mutated'])

    def test_73_sacred_mind_commit_is_mind_local(self):
        before=self.world.state_digest()
        r=self.mind.sacred_mind_commit('1','PRACTICE_COMMITMENT',{'practice':'daily reflection'})
        self.assertEqual(r['status'],'COMMITTED')
        self.assertFalse(r['world_mutation'])
        self.assertEqual(before,self.world.state_digest())
        self.assertTrue(self.mind.minds['1']['meaning']['spiritual_commits'])

    def test_74_cakra_state_survives_save_load(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        self.mind.spiritual_receive('1',arrival_mode='DREAM',content='dream image',conviction=91)
        self.mind.sacred_integrate('1')
        obj=self.mind.export(); restored=MindRuntime.from_export(self.world,obj)
        self.assertEqual(restored.cakra_snapshot('1')['digest'],self.mind.cakra_snapshot('1')['digest'])

    def test_75_old_state_without_cakra_migrates(self):
        obj=self.mind.export()
        obj['state']['minds']['1'].pop('cakra',None)
        cp=copy.deepcopy(obj); cp.pop('integrity_sha256',None)
        from mind.mind_runtime import sha256_obj
        obj['integrity_sha256']=sha256_obj(cp)
        restored=MindRuntime.from_export(self.world,obj)
        self.assertEqual(len(restored.cakra_snapshot('1')['nodes']),12)

    def test_76_qvm_compiles_cakra_services(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        self.assertTrue(set(range(72,84)).issubset(set(c['payload']['capabilities']['services'])))

    def test_77_qvm_cakra_services_require_mind_init(self):
        p=copy.deepcopy(qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload'])
        p['instructions']=[{'op':'MOVI','dst':0,'imm':7},{'op':'SVC','svc':16},{'op':'MOVI','dst':0,'imm':1},{'op':'SVC','svc':72},{'op':'HALT'}]
        vm=qvm.VM(p)
        with self.assertRaises(qvm.VMTrap) as cm: vm.run()
        self.assertEqual(cm.exception.name,'TRAP_BAD_SERVICE')

    def test_78_qvm_cakra_demo_runs(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)
        seed=bytes.fromhex((ROOT/'keys/DEV_ONLY_private_seed.hex').read_text().strip())
        trust=json.loads((ROOT/'keys/TRUST_STORE.json').read_text())
        img=qvm.sign_payload(copy.deepcopy(c['payload']),seed,'dev-root')
        p=qvm.verify_image(img,trust,0); vm=qvm.VM(p); s=vm.run()
        self.assertEqual(s['status'],'HALTED')
        self.assertEqual(s['mind']['invariants'],[])
        self.assertIn('cakra_integration',self.mind.qualification_summary())

    def test_79_qvm_cakra_demo_replay_is_deterministic(self):
        c=qvm.compile_source(ROOT/'src/MIND_DEMO.lctlc',ROOT,True)['payload']
        a=qvm.VM(copy.deepcopy(c)).run(); b=qvm.VM(copy.deepcopy(c)).run()
        self.assertEqual(a['state_sha256'],b['state_sha256'])
        self.assertEqual(a['mind']['state_digest'],b['mind']['state_digest'])

    def test_80_cakra_nodes_remain_proposal_only(self):
        c=self.mind.cakra_snapshot('1')
        self.assertTrue(all(n['authority']=='PROPOSAL_ONLY' for n in c['nodes'].values()))
        self.assertTrue(all(n['mind_commit_required'] for n in c['nodes'].values()))

    def test_81_invariant_detects_sacred_world_truth_confusion(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        self.mind.spiritual_receive('1',arrival_mode='VISION',content='vision',conviction=95)
        self.mind.minds['1']['cakra']['operative_sacred_truths'][0]['world_truth_claim']=True
        self.assertTrue(any('sacred/world truth confusion' in x for x in self.mind.invariants('1')))

    def test_82_session_end_closes_and_creates_return_path(self):
        s=self.mind.spiritual_session_begin('1',profile='MYSTICAL',consent_ref='TEST')
        r=self.mind.spiritual_session_end('1')
        self.assertEqual(r['status'],'CLOSED')
        self.assertIsNone(self.mind.cakra_snapshot('1')['active_session'])
        self.assertGreaterEqual(len(self.mind.cakra_snapshot('1')['return_paths']),1)

    def test_83_snapshot_exposes_cakra_digest(self):
        s=self.mind.snapshot('1')
        self.assertEqual(s['cakra_profile'],'MYSTICAL')
        self.assertEqual(len(s['cakra_digest']),64)

    def test_84_cse_1_1_session_surface(self):
        s=self.mind.spiritual_session_begin('1',profile='MYSTICAL',frame_ref='frame-a')
        for key in ['lineage_scope','practice_object','source_claim_refs','external_claims','service_proposal_refs','phenomenology_refs','dream_vision_refs','ontology_frames','mysteries']:
            self.assertIn(key,s)
        self.assertEqual(s['cse_version'],'CSE/1.1')

    def test_85_multiple_spiritual_ontologies_can_be_held(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL',frame_ref='nondual-frame')
        r=self.mind.spiritual_add_ontology_frame('1','devotional-theistic-frame')
        self.assertEqual(r['status'],'ONTOLOGY_HELD')
        self.assertEqual(len(r['live_frames']),2)

    def test_86_mystery_is_first_class_state(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL')
        r=self.mind.spiritual_hold_mystery('1','unresolved sacred significance',91)
        self.assertEqual(r['status'],'MYSTERY_HELD')
        self.assertFalse(r['world_truth_claim'])

    def test_87_ascent_opens_all_twelve_nodes_without_world_write(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL')
        before=self.world.state_digest(); r=self.mind.spiritual_ascent('1')
        self.assertEqual(r['status'],'ASCENT_COMPLETE')
        self.assertEqual(len(r['path']),12)
        self.assertEqual(before,self.world.state_digest())

    def test_88_dream_is_linked_into_spiritual_meaning(self):
        self.mind.spiritual_session_begin('1',profile='MYSTICAL')
        x=self.mind.spiritual_receive('1',arrival_mode='DREAM',content='a luminous bridge',conviction=92)
        self.mind.sacred_integrate('1')
        sp=self.mind.minds['1']['meaning']['spiritual']
        self.assertIn(x['insight_id'],sp['dream_vision_refs'])

    def test_89_qvm_compiles_extended_spiritual_services(self):
        from toolchain.quorum_vm import compile_source
        import tempfile, pathlib
        src='LCTLC/1.0\n@unit id=t version=1 profile=native entry=F0000:V0001 target=hosted-reference error_budget=0 resource_ceiling=mind=bounded proof=t\n@defaults qspace=H basis=computational regime=exact assume=finite_dimension error=exact conf=1.0\n@frame id=F0000 parent=ROOT module=t proof=t\nID│LANE│OP│OUT│CTRL│IN│ARG│META\nV0001│vm│REG│_│_│_│vm.op=MOVI;dst=R0;imm=1│p=t\nV0002│vm│REG│_│_│_│vm.op=SVC;svc=48│p=t\nV0003│vm│REG│_│_│_│vm.op=SVC;svc=74│p=t\nV0004│vm│REG│_│_│_│vm.op=SVC;svc=84│p=t\nV0005│vm│REG│_│_│_│vm.op=SVC;svc=85│p=t\nV0006│vm│REG│_│_│_│vm.op=SVC;svc=86│p=t\nV0007│vm│REG│_│_│_│vm.op=HALT│p=t\nC9999│terminal│.│_│_│_│terminal=sealed_graph_end│p=t\n@end\n'
        with tempfile.TemporaryDirectory() as d:
            q=pathlib.Path(d)/'x.lctlc'; q.write_text(src,encoding='utf-8')
            payload=compile_source(q,q.parent,require_lctl=False)
            caps=set(payload['payload']['capabilities']['services'])
            self.assertTrue({84,85,86}.issubset(caps))

if __name__=='__main__': unittest.main(verbosity=2)
