@echo off
call "%~dp0vm\RUN_MIND.cmd"
exit /b %errorlevel%
