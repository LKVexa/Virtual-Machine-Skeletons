# QUORUM VM extension changelog

## 5.0.0-candidate

- Added a deterministic hosted VM with 24-opcode ISA, 16 wide registers, 4 KiB guest memory, bounded stack, traps, and resource limits.
- Added canonical LCTL-C front-end verification and deterministic BRIR/BRIM lowering.
- Added signed-image verification, rollback floor, development trust store, deterministic virtual services, and authenticated A/B persistence.
- Added 20-test adversarial/conformance suite, all-opcode execution coverage, deterministic fuzzing, benchmarks, replay evidence, and base-repository regression.
- Applied 138 attached/overlay work packages into a 957-requirement evidence ledger.
- Preserved explicit PARTIAL/BLOCKED status for unearned native, self-hosted, production-crypto, cross-platform, soak, and independent-witness gates.
